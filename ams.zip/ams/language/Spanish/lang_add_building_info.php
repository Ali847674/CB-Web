<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Agregar nueva informaci�n de construcci�n";
$_data['text_2'] 		= "edificio";
$_data['text_3'] 		= "A�adir Edificio Info";
$_data['text_4'] 		= "Datos de la construcci�n";
$_data['text_5'] 		= "Nombre";
$_data['text_6'] 		= "Direcci�n";
$_data['text_7'] 		= "Guardia de seguridad m�vil";
$_data['text_8'] 		= "Secretario m�vil";
$_data['text_9'] 		= "moderador m�vil";
$_data['text_10'] 		= "Construcci�n Marca A�o";
$_data['text_11'] 		= "Informaci�n constructor";
$_data['text_12'] 		= "Tel�fono";
$_data['text_13'] 		= "Creaci�n de imagen";
$_data['text_14'] 		= "Seleccionar a�o";

?>