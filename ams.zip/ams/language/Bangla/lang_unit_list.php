<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['unit_list_title'] 							= "ইউনিট তালিকা";
$_data['add_new_unit_information_breadcam'] 		= "ইউনিট তথ্য";
$_data['delete_floor_information'] 					= "ইউনিট তথ্য সফলভাবে মুছে ফেলেছেন।";
$_data['floor_no'] 									= "ফ্লোর সংখ্যা";
$_data['unit_no'] 									= "ইউনিট সংখ্যা";
$_data['unit_details']								= "ইউনিট বিস্তারিত";
$_data['add_unit']									= "ইউনিট যোগ";
$_data['add_unit_successfully'] 					= "ইউনিট তথ্য সফলভাবে যুক্ত হয়েছে";
$_data['update_unit_successfully'] 					= "ইউনিট তথ্য সফলভাবে পরিবর্তন হয়েছে";
$_data['details_info'] 								= "বিস্তারিত তথ্য";
$_data['back_text']									= "ইউনিট তালিকা";


?>