<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "ভাড়া প্রতিবেদন";
$_data['text_2'] 		= "প্রতিবেদন";
$_data['text_3'] 		= "ভাড়া প্রতিবেদন ফরম";
$_data['text_4'] 		= "স্থিতি নির্বাচন";
$_data['text_5'] 		= "নির্বাচন করুন";

?>