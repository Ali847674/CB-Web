<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "মালিক সংগ্রহ তথ্য";
$_data['text_2'] 		= "ভাড়া সংগ্রহ তারিখ";
$_data['text_4'] 		= "মালিকের নাম";
$_data['text_5'] 		= "ফ্লোর";
$_data['text_6'] 		= "ইউনিট";
$_data['text_7'] 		= "মাস";
$_data['text_8'] 		= "ভাড়া";
$_data['text_9'] 		= "গ্যাস বিল";
$_data['text_10'] 		= "বিদ্যুৎ বিল";
$_data['text_11'] 		= "পানি বিল";
$_data['text_12'] 		= "নিরাপত্তা বিল";
$_data['text_13'] 		= "ইউটিলিটি বিল";
$_data['text_14'] 		= "অন্যান্য বিল";
$_data['text_15'] 		= "মোট";
$_data['text_16'] 		= "তথ্য মূদ্রণ";

?>