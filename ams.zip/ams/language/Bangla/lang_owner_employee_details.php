<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "কর্মচারী তালিকা";
$_data['text_2'] 		= "নাম";
$_data['text_3'] 		= "ই-মেইল";
$_data['text_4'] 		= "যোগাযোগ";
$_data['text_5'] 		= "বর্তমান ঠিকানা";
$_data['text_6'] 		= "উপাধি";
$_data['text_7'] 		= "যোগদান তারিখ";
$_data['text_8'] 		= "কর্মচারী বিবরণ";
$_data['text_9'] 		= "স্থায়ী ঠিকানা";

?>