<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['add_new_owner_list_utility_title'] 			= "Owner Utility List";
$_data['owner_utility'] 							= "Owner Utility";
$_data['owner_utility_details'] 					= "Owner Utility Details";
$_data['add_owner_utility'] 						= "Add Owner Utility";
$_data['add_owner_utility_entry_form'] 				= "Owner Utility Entry Form";
$_data['add_new_form_field_text_1'] 				= "Floor No";
$_data['add_new_form_field_text_2'] 				= "Select Floor";
$_data['add_new_form_field_text_3'] 				= "Unit No";
$_data['add_new_form_field_text_4'] 				= "Select Unit";
$_data['add_new_form_field_text_5'] 				= "Select Month";
$_data['add_new_form_field_text_6'] 				= "Owner Name";
$_data['add_new_form_field_text_8'] 				= "Water Bill";
$_data['add_new_form_field_text_9'] 				= "Electric Bill";
$_data['add_new_form_field_text_10'] 				= "Gas Bill";
$_data['add_new_form_field_text_11'] 				= "Security Bill";
$_data['add_new_form_field_text_12'] 				= "Utility Bill";
$_data['add_new_form_field_text_13'] 				= "Other Bill";
$_data['add_new_form_field_text_14'] 				= "Total Rent ";
$_data['add_new_form_field_text_15'] 				= "Issue Date";
$_data['add_new_form_field_text_16'] 				= "Month Name";
$_data['add_new_form_field_text_17'] 				= "Year Name";
$_data['add_new_form_field_text_18'] 				= "Rent";
$_data['added_owner_utility_successfully'] 			= "Added Owner Utility Information Successfully";
$_data['update_owner_utility_successfully'] 		= "Updated Owner Utility Information Successfully";
$_data['delete_owner_utility_information'] 			= "Deleted Owner Utility Information Successfully.";

?>