<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Add New Complain";
$_data['text_1_1'] 		= "Update Complain";
$_data['text_2'] 		= "Complain";
$_data['text_3'] 		= "Add Complain";
$_data['text_4'] 		= "Complain Entry Form";
$_data['text_5'] 		= "Tittle";
$_data['text_6'] 		= "Description";
$_data['text_7'] 		= "Date";
$_data['text_8'] 		= "Added Complain Successfully";
$_data['text_9'] 		= "Updated Complain Successfully";
$_data['text_10'] 		= "Deleted Complain Successfully";

?>