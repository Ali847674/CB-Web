<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Rented Details";
$_data['text_2'] 		= "Month Name";
$_data['text_3'] 		= "Total Amount";
$_data['text_4'] 		= "Issue Date";
$_data['text_5'] 		= "Rented Name";
$_data['text_6'] 		= "Email";
$_data['text_7'] 		= "Contact";
$_data['text_8'] 		= "Address";
$_data['text_9'] 		= "Floor No";
$_data['text_10'] 		= "Unit No";
$_data['text_11'] 		= "Rent";
$_data['text_12'] 		= "Water Bill";
$_data['text_13'] 		= "Electric Bill";
$_data['text_14'] 		= "Gas Bill";
$_data['text_15'] 		= "Security Bill";
$_data['text_16'] 		= "Utility Bill";
$_data['text_17'] 		= "Other Bill";
$_data['text_18'] 		= "Tatal Rent";
$_data['text_19'] 		= "Tanant Dashboard";


?>