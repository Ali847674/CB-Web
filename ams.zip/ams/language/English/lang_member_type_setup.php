<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Member Type Setup";
$_data['text_2'] 		= "Member Type Entry Form";
$_data['text_3'] 		= "Member Type";
$_data['text_4'] 		= "Member Type List";
$_data['text_5'] 		= "Added Management Member Type Information Successfully";
$_data['text_6'] 		= "Updated Management Member Type Information Successfully";
$_data['text_7'] 		= "Deleted Management Member Type Information Successfully";
$_data['text_8'] 		= "Member Type Details";


?>