<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Complain Report";
$_data['text_2'] 		= "Report";
$_data['text_3'] 		= "Complain Report Form";
$_data['text_4'] 		= "Select Date";
$_data['text_5'] 		= "Select Month";
$_data['text_6'] 		= "Select Year";

?>