<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['unit_list_title'] 						= "Unit List";
$_data['add_new_unit_information_breadcam'] 	= "Unit Information";
$_data['delete_unit_information'] 				= "Deleted Unit Information Successfully.";
$_data['floor_no'] 								= "Floor No";
$_data['unit_no'] 								= "Unit No";
$_data['unit_details']							= "Unit Details";
$_data['add_unit']								= "Add Unit";
$_data['add_unit_successfully'] 				= "Added Unit Information Successfully";
$_data['update_unit_successfully'] 				= "Updated Unit Information Successfully";
$_data['details_info'] 							= "Details Infromation";
?>