<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Visitors Report";
$_data['text_2'] 		= "Date";
$_data['text_3'] 		= "Name";
$_data['text_4'] 		= "Mobile";
$_data['text_5'] 		= "Address";
$_data['text_6'] 		= "floor_no";
$_data['text_7'] 		= "Unit_no";
$_data['text_8'] 		= "In Time";
$_data['text_9'] 		= "Out Time";
$_data['text_10'] 		= "Month";
$_data['text_11'] 		= "Year";


?>