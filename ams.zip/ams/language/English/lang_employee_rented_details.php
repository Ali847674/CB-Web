<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Rented Details";
$_data['text_2'] 		= "Rented Name";
$_data['text_3'] 		= "Contact";
$_data['text_4'] 		= "Unit No";
$_data['text_5'] 		= "Advance Rent";
$_data['text_6'] 		= "Rent Per Month";
$_data['text_7'] 		= "Status";
$_data['text_8'] 		= "Email";
$_data['text_9'] 		= "Password";
$_data['text_10'] 		= "Address";
$_data['text_11'] 		= "NID(National ID)";
$_data['text_12'] 		= "Rent Start Date";
$_data['dashboard'] 	= "Dashboard";
$_data['active'] 		= "Active";
$_data['expired'] 		= "Expired";

?>