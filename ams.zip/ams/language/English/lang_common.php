<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['save_button_text'] 					= "Save Information";
$_data['update_button_text'] 				= "Update Information";
$_data['home_breadcam'] 					= "Home";
$_data['delete_text']						= "Delete";
$_data['action_text']						= "Action";
$_data['details_information']				= "Details Infromation";
$_data['view_text'] 						= "View Details";
$_data['edit_text'] 						= "Edit";
$_data['back_text']							= "Back";
$_data['success'] 							= "Success";
$_data['upload_image'] 						= "Upload Image";
$_data['image'] 							= "Image";
$_data['submit'] 							= "Submit";
$_data['reset'] 							= "Reset";
$_data['setting'] 							= "Setting";
$_data['reset_text'] 						= "Please Reset First Before Insert";
$_data['owner_dashboard'] 					= "Owner Dashboard";
$_data['dashboard'] 						= "Dashboard";
$_data['print'] 							= "Print Information";

?>