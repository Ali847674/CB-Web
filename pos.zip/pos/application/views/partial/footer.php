<div id="footer" class="col-md-12 hidden-print">
	<?php echo lang('common_please_visit_my'); ?> 
		<a href="http://www.optimumlinkup.com.ng" target="_blank">
			<?php echo lang('common_website'); ?>
		</a> 
	<?php echo lang('common_learn_about_project'); ?>.
		<span class="text-info"><?php echo lang('POS Software')?> <span class="label label-info"> <?php echo APPLICATION_VERSION; ?></span></span>
</div>

</div><!--end #content-->
</div><!--end #wrapper-->
</body>
</html>