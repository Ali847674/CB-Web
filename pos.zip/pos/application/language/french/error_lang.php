<?php
$lang['error_no_permission_module']='Vous n\'avez pas les permissions requises pour accÈder ‡ ce module';//The good translation
$lang['error_unknown']='inconnue';
?>