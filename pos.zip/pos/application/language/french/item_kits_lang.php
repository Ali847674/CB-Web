<?php
$lang['item_kits_name'] = 'Nom du kit';//The good translation
$lang['item_kits_description'] = 'Description du kit';//The good translation
$lang['item_kits_no_item_kits_to_display'] = 'Aucun kit à afficher';//The good translation
$lang['item_kits_update'] = 'mise à jour du kit';//The good translation
$lang['item_kits_new'] = 'Nouveau kit';//The good translation
$lang['item_kits_none_selected'] = "Vous n'\avez pas sélectionné de kit d\'articles";//The good translation
$lang['item_kits_info'] = 'information sur le kit';//The good translation
$lang['item_kits_successful_adding'] = 'Vous avez ajouté la trousse avec succès';//The good translation
$lang['item_kits_successful_updating'] = 'L\'ajout du kit à échoué';//The good translation
$lang['item_kits_error_adding_updating'] = 'Erreur d\'ajout / mise à jour du kit';//The good translation
$lang['item_kits_successful_deleted'] = 'Vous avez supprimé le kit avec succès';//The good translation
$lang['item_kits_confirm_delete'] = 'Etes-vous sûr de vouloir supprimer le kit sélectionné?';//The good translation
$lang['item_kits_one_or_multiple'] = 'Kit d\'Article(s)';//The good translation
$lang['item_kits_cannot_be_deleted'] = 'Impossible de supprimer le(s) kit(s)';//The good translation
$lang['item_kits_add_item'] = 'Ajouter l\'Article';
$lang['item_kits_items'] = 'Articles';
$lang['item_kits_item'] = 'Article';
$lang['item_kits_quantity'] = 'Quantité';//The good translations
$lang['item_kits_desc'] = 'Kits des ouvrages sont constitués de 1 ou plusieurs éléments à considérer comme un groupe. Ajouter votre premier article en utilisant le champ ci-dessous.';
$lang['item_kits_items_added'] = 'Les éléments ajoutés';
?>