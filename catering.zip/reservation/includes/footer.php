<footer>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
            <!-- Copyright info -->
            <p class="copy">Copyright &copy; 2017 | <a href="#">Chimney Catering</a> </p>
      </div>
    </div>
  </div>
</footer> 