
@include('header')
    <!-- banner-text -->
    <!-- ab -->
    @yield('headerlinks')
    @yield('headernavigations')
    <!-- /breadcrumb -->
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="/">Home</a>
        </li>
        <li class="breadcrumb-item active">Tracking</li>
    </ol>
    <section class="banner-bottom-w3ls py-lg-5 py-md-5 py-3">
    <div class="container" align="center">
        <div class="row">
            <div class="col-md-12">
                    @if(count($order))
                    <fieldset>
                        <legend>Order ID</legend>
                        Order Id: {{ $order[0]->alpha_id }}<br><br>
                    </fieldset>
            </div>
            <div class="col-md-6">      
                    <fieldset>
                        <legend>Sender Details</legend>
                        <div class="form-group">
                            <label class="control-label">Sender Name: {{ $order[0]->sender_name }}</label>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Sender Cell: 0{{ $order[0]->sender_cell }}</label>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Sender Company: {{ $order[0]->sender_company }}</label>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Sender Address: {{ $order[0]->sender_address }}</label>
                        </div>
                    </fieldset>
            </div>
            <div class="col-md-6">      
                    <fieldset>
                        <legend>Receiver Details</legend>
                        <div class="form-group">
                            <label class="control-label">Receiver Name: {{ $order[0]->receiver_name }}</label>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Receiver Cell: {{ $order[0]->receiver_cell }}</label>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Receiver Company: {{ $order[0]->receiver_company }}</label>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Receiver Address: {{ $order[0]->receiver_address }}</label>
                        </div>
                    </fieldset>
            </div>

            <div class="col-md-12">
                    <fieldset>
                        <legend>Track Details</legend>
                        <div class="form-group">
                            <label class="control-label">BOOKED Time: {{ $order[0]->booked_date ? \Carbon\Carbon::parse($order[0]->booked_date)->format('l d F Y h:i A ') : 'Not Process Yet'  }}</label>
                        </div>
                        <div class="form-group">
                            <label class="control-label">RECEIVED At DSL: {{ $order[0]->dsl_date ? \Carbon\Carbon::parse($order[0]->dsl_date)->format('l d F Y h:i A ') : 'Not Process Yet'  }}</label>
                        </div>
                        <div class="form-group">
                            <label class="control-label">In TRANSIT: {{ $order[0]->out_date ? \Carbon\Carbon::parse($order[0]->out_date)->format('l d F Y h:i A ') : 'Not Process Yet'  }}</label>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Out For DELIVERY: {{ $order[0]->transit_date ? \Carbon\Carbon::parse($order[0]->transit_date)->format('l d F Y h:i A ') : 'Not Process Yet'  }}</label>
                        </div>
                        <div class="form-group">
                            <label class="control-label">DELIVERED: {{ $order[0]->deliever_date ? \Carbon\Carbon::parse($order[0]->deliever_date)->format('l d F Y h:i A ') : 'Not Process Yet'  }}</label>
                        </div>
                    </fieldset>
                @else
                    <h2>No Data Found</h2>
                @endif
            </div>
        </div>
    </div>
    </section>
    

@include('footer')
