<!--
	Author: W3layouts
	Author URL: http://w3layouts.com
	License: Creative Commons Attribution 3.0 Unported
	License URL: http://creativecommons.org/licenses/by/3.0/
-->

<!DOCTYPE html>
<html>
<head>
	<title>Transload a Corporate Category Bootstrap responsive WebTemplate | Home :: w3layouts</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	<meta name="keywords" content="Transload a Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />

	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<link rel="stylesheet" href="./mainweb/css/bootstrap.css"> <!-- Bootstrap-Core-CSS -->
	<link href="./mainweb/css/style.css" rel='stylesheet' type='text/css' />
	<link href="./mainweb/css/simpleLightbox.css" rel='stylesheet' type='text/css' />
	<link href="./mainweb/css/popup-box.css" rel="stylesheet" type="text/css" media="all" />
	<link href="./mainweb/css/fontawesome-all.css" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />

     <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.3.1/semantic.min.css">
 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.semanticui.min.css">
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
            <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
            <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.semanticui.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.3.1/semantic.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.8.1/parsley.js"></script>
<link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>



<script src="{{ URL::asset('assets') }}/global/plugins/icheck/icheck.min.js" type="text/javascript"></script>
<script src="{{ URL::asset('assets') }}/global/plugins/icheck/icheck.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<script type="text/javascript" src="jquery-3.3.1.min.js"></script>



@yield('script')

</head>

<body>
<header>
	<div class="header">
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
 <a class="navbar-brand" href="index.html">Transl<span><i class="fab fa-empire"></i></span>ad</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarText">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link scroll" href="#about">About</a>
      </li>
      <li class="nav-item">
        <a class="nav-link scroll" href="#services">Services</a>
      </li>
	   <li class="nav-item">
        <a class="nav-link scroll" href="#works">Our Works</a>
      </li>
	   <li class="nav-item">
        <a class="nav-link scroll" href="#pricing">Pricing</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link scroll" href="#contact">Contact</a>
      </li>
       <li class="nav-item">
        <a class="nav-link scroll" href="{{url('/getcn')}}">CN</a>
      </li>
    </ul>
    <div class="navbar-text">
     <p class="right-p"><i class="fas fa-phone" aria-hidden="true"></i>098-765-4321</p>
    </div>
  </div>
</nav>
		</div>
</header>
<!--/banner-->
	

@yield('mainbody')


<footer>
	<div class="container py-3 py-md-4">
		<div class="footer">
				<p class="text-center">© 2018 Transload. All Rights Reserved | Design by <a href="http://www.W3Layouts.com" target="_blank">W3Layouts</a></p>
			</div>
	</div>
</footer>
<!-- footer -->

<!-- //Newsletter -->
<!-- /modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-uppercase" id="exampleModalLongTitle">Transload</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
		<img src="mainweb/images/modal.jpg" class="img-fluid mb-4" alt="Modal Image" />
        Vivamus eget est in odio tempor interdum. Mauris maximus fermentum arcu, ac finibus ante. Sed mattis risus at ipsum elementum, ut auctor turpis cursus. Sed sed odio pharetra, aliquet velit cursus, vehicula enim. Mauris porta aliquet magna, eget laoreet ligula.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
<!-- //modal -->
<!-- Modal2 -->
<div class="modal fade" id="myModal3" tabindex="-1" role="dialog">
	<div class="modal-dialog">
	<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				
				<div class="signin-form profile">
				<h3 class="agileinfo_sign">Sign Up</h3>	
						<div class="login-form">
							<form action="#" method="post">
							   <input type="text" name="name" placeholder="Username" required="">
								<input type="email" name="email" placeholder="Email" required="">
								<input type="password" name="password" placeholder="Password" required="">
								<input type="password" name="password" placeholder="Confirm Password" required="">
								<input type="submit" value="Sign Up">
							</form>
						</div>
						<p><a href="#"> By clicking register, I agree to your terms</a></p>
					</div>
			</div>
		</div>
	</div>
</div>
<!-- //Modal2 -->	

<!-- /magnific-popup -->
<div class="pop-up"> 
				<div id="small-dialog" class="mfp-hide book-form">
					<h3 class="sub-head-w3-agileits subscribe_us text-center py-3 head_size_con">Contact us </h3>
						<!-- banner --> 
	<div class="video" data-vide-bg="video/ship"> 
	<div class="center-container">
		 <div class="bg-agile">
			<h3>Order Contact</h3>
			<div class="login-form">			
							<form action="#" method="post">
								<input type="text"  name="Name" placeholder="Full name" required="" />
								<input type="text"  name="Number" placeholder="Phone number" required="" />
								<input type="email"  name="Email" placeholder="Email" required="" />
								<h3>Shipping address</h3>
								<div class="left-w3-agile">
									<select class="form-control form2-color">
										<option>Choose your country</option>
										<option>Argentina</option>
										<option>Georgia</option>
										<option> Dominica</option>
										<option>Lithuania</option>
										<option> Monaco</option>
									</select>
									<input type="text"  name="Region" placeholder="State/province/region" required="" />
								</div>
								<div class="right-agileits">
								<input type="text"  name="City" placeholder="City" required="" />
								<input type="text"  name="Zip/postal code" placeholder="Zip/postal code" required="" />
								</div>
								<textarea name="message" value="Address" placeholder="Street address" ></textarea>
								<input type="submit" value="Submit">
							</form>	
						</div>	
		</div>
	<!-- //banner --> 

				</div>
			</div>
</div>
</div>
<!-- //magnific-popup -->

<!-- js -->
	<script type="text/javascript" src="mainweb/js/jquery-2.2.3.min.js"></script>
	<script type="text/javascript" src="mainweb/js/bootstrap.js"></script> <!-- Necessary-JavaScript-File-For-Bootstrap --> 
	<!-- //js -->


<!-- stats -->
	<script src="mainweb/js/jquery.waypoints.min.js"></script>
	<script src="mainweb/js/jquery.countup.js"></script>
	<script>
		$('.counter').countUp();
	</script>
	<!-- //stats -->
<!-- bars.js -->   
	<script src="mainweb/js/bars.js"></script>
	<!-- //bars.js -->

	<!-- flexSlider (for testimonials) -->
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
	<script defer src="mainweb/js/jquery.flexslider.js"></script>
	<script>
		$(window).load(function () {
			$('.flexslider').flexslider({
				animation: "slide",
				start: function (slider) {
					$('body').removeClass('loading');
				}
			});
		});
	</script>
	<!-- //flexSlider (for testimonials) -->
	<!-- simpleLightbox -->
	<script src="mainweb/js/simpleLightbox.js"></script>
	<script>
		$('.proj_gallery_grid a').simpleLightbox();
	</script>
	<!-- //simpleLightbox -->
<!--popup-js-->
<script src="mainweb/js/jquery.magnific-popup.js" type="text/javascript"></script>
 <script>
						$(document).ready(function() {
						$('.popup-with-zoom-anim').magnificPopup({
							type: 'inline',
							fixedContentPos: false,
							fixedBgPos: true,
							overflowY: 'auto',
							closeBtnInside: true,
							preloader: false,
							midClick: true,
							removalDelay: 300,
							mainClass: 'my-mfp-zoom-in'
						});
																						
						});
</script>
<!--//popup-js-->
<!-- start-smooth-scrolling -->
	<script src="mainweb/js/move-top.js"></script>
	<script src="mainweb/js/easing.js"></script>
	<script>
		jQuery(document).ready(function ($) {
			$(".scroll").click(function (event) {
				event.preventDefault();

				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	<!-- //end-smooth-scrolling -->
	
	<!-- smooth-scrolling-of-move-up -->
	<script>
		$(document).ready(function () {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/

			$().UItoTop({
				easingType: 'easeOutQuart'
			});

		});
	</script>
	<!-- //smooth-scrolling-of-move-up -->
	
	
	<!-- smooth scrolling js -->
	<script src="mainweb/js/SmoothScroll.min.js"></script>
	<!-- //smooth scrolling js -->
 </body>
</html>
