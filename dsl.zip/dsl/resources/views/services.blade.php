
@include('header')
    <!-- banner-text -->
    <!-- ab -->
    @yield('headerlinks')
    @yield('headernavigations')
    <!-- /breadcrumb -->
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="/">Home</a>
        </li>
        <li class="breadcrumb-item active">Services</li>
    </ol>
    <!-- //breadcrumb -->
    <!-- / -->
    <section class="banner-bottom-w3ls py-lg-5 py-md-5 py-3">

        <div class="container">
            <div class="inner-sec-w3layouts py-lg-5 py-3">
<!--                 <div class="intro text-left">
                    <h3 class="main mb-md-5 mb-3">Lorem ipsum dolor sit amet consectetur adipisicing elit sedc dnmo eiusmod tempor incididunt ut labore et dolore.</h3>
                    <p>Adipisicing elit sedc eiusmod tempor incididunt ut labore et dolore.</p>
                </div> -->
                <div class="row mt-lg-5 mt-md-4 mt-4">
                    <div class="col-lg-4 about-in text-left">
                        <div class="card">
                            <div class="card-body">
                                <i class="fas fa-anchor mb-2"></i>
<!--                                 <h6 class="my-3">Consectetur elit</h6> -->
                                <h5 class="card-title">LOGISTICS</h5>
                                <p class="card-text">OVERLAND SERVICE</p>
                                <p class="card-text">CARGO SERVICE</p>
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-4 about-in text-left">
                        <div class="card">
                            <div class="card-body">

                                <i class="fas fa-fighter-jet mb-2"></i>
                                <!-- <h6 class="my-3">Consectetur elit</h6> -->
                                <h5 class="card-title">COURIERS</h5>
                                <p class="card-text">DOMESTIC SERVICE</p>
                                <p class="card-text">INTERNATIONAL SERVICE</p>
                            </div>
                        </div>

                    </div>

                    <div class="col-lg-4 about-in text-left">
                        <div class="card">
                            <div class="card-body">
                                <i class="fas fa-truck mb-2"></i>
                                <!-- <h6 class="my-3">Consectetur elit</h6> -->
                                <h5 class="card-title">COD</h5>
                                <p class="card-text">KARACHI</p>
                                <p class="card-text">DMESTIC</p>
                            </div>
                        </div>
                    </div>


                </div>

            </div>
        </div>
    </section>
    <!--services-->
        <!-- /services -->
    <section class="banner-bottom-w3ls bg-dark py-lg-5 py-md-5 py-3">
        <div class="container">
            <div class="inner-sec-w3layouts py-lg-5 py-3">
                <h3 class="tittle text-center text-white mb-md-5 mb-4">DSL KARACHI SERVICES</h3>
                <div class="row">
                    <div class="col-lg-6 about-in text-left">
                        <div class="card">
                            <div class="card-body">
                                <i class="fab fa-docker mb-2"></i>
                                <h5 class="card-title ctcolor">COURIERS SERVICE</h5>
                                <p class="card-text">OVERNIGHT</p>
                                <p class="card-text">2ND DAY</p>
                                <p class="card-text">SAME DAY</p>
                                <p class="card-text">TIME PAY</p>
                                <p class="card-text">UNOFFICAL TIME</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 about-in text-left">
                        <div class="card">
                            <div class="card-body">
                                <i class="far fa-clock mb-2"></i>
                                <h5 class="card-title ctcolor">COD SERVICE</h5>
                                <p class="card-text">OVERNIGHT</p>
                                <p class="card-text">2ND DAY</p>
                                <p class="card-text">SAME DAY</p>
                                <p class="card-text">TIME PAY</p>
                                <p class="card-text">UNOFFICAL TIME</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--services-->
    <!--/featured-->
    <section class="banner-bottom-w3ls py-md-5 py-4">
        <div class="container">
            <div class="inner-sec-w3layouts py-md-5 py-4">
                <h3 class="tittle text-center mb-md-5 mb-4">
                    DSL KARACHI DELIVERIES</h3>
                <!--/services-grids-->
                <div class="row blog-sec">
                                        <div class="col-lg-3 about-in text-left">
                        <div class="card">
                            <div class="card-body">
                                <i class="fab fa-docker mb-2"></i>
                                <h5 class="card-title ">PARCEL PICKNDROP</h5>
                                <p class="card-text">SAME DAY</p>
                                <p class="card-text">TIME PAY</p>
                                <p class="card-text">UNOFFICAL TIME</p>
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-3 about-in text-left">
                        <div class="card">
                            <div class="card-body">
                                <i class="far fa-clock mb-2"></i>

                                <h5 class="card-title ">CAKE DELIVERY</h5>
                                <p class="card-text">SAME DAY</p>
                                <p class="card-text">TIME PAY</p>
                                <p class="card-text">UNOFFICAL TIME</p>                            
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 about-in text-left">
                        <div class="card">
                            <div class="card-body">
                                <i class="far fa-money-bill-alt mb-2"></i>
                                <h5 class="card-title ">FOOD DELIVERY</h5>
                                <p class="card-text">SAME DAY</p>
                                <p class="card-text">TIME PAY</p>
                                <p class="card-text">UNOFFICAL TIME</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 about-in text-left">
                        <div class="card">
                            <div class="card-body">
                                <i class="far fa-money-bill-alt mb-2"></i>
                                <h5 class="card-title ">SURPRISE DELIVERY</h5>
                                <p class="card-text">SAME DAY</p>
                                <p class="card-text">TIME PAY</p>
                                <p class="card-text">UNOFFICAL TIME</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//featured-->

@include('footer')
