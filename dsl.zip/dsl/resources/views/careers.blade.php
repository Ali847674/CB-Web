
@include('header')
    <!-- banner-text -->
    <!-- ab -->
    @yield('headerlinks')
    @yield('headernavigations')
    <!-- /breadcrumb -->
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="/">Home</a>
        </li>
        @if(Session::has('filess'))
        <div class="alert alert-danger">
            <p class="bg-danger">{{session('files')}}</p>
        </div>
        @endif
        <li class="breadcrumb-item active">Careers</li>
    </ol>
    <!-- //breadcrumb -->
    <!-- /Contact-->
    <section class="banner-bottom-w3ls py-lg-5 py-md-5 py-3">
        <div class="container">
            <div class="inner-sec-w3layouts py-lg-5 py-3">
                <h3 class="tittle text-center mb-md-5 mb-4">Careers</h3>
                <div class="contact_grid_right">
                    <form action="{{ route('submitcv') }}" method="post" enctype="multipart/form-data">
                        {{ csrf_field() }}
                        <div class="row contact_left_grid">
                            <div class="col-md-6 con-left">
                                <div class="form-group">
                                    <label>About You</label>
                                    <input class="form-control" type="file" name="file" required>
                                    <textarea id="textarea" placeholder="" required name="info"></textarea>
                                </div>
                                <input class="form-control" type="submit" value="DROP A RESUME">
                            </div>
                            <div class="col-md-6 con-right-w3ls">
                           <img src="assets/site/images/careers.jpg" class="img-responsive carimage">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

@include('footer')
  