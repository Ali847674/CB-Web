@extends('layout.webmain')

@section('mainbody')


 <div class="portlet-body form">
       
            <form role="form"  method="POST"  class="form-horizontal">
                  {{ csrf_field() }}
                     <div class="form-group">
                        <label class="col-md-3 control-label" >Search</label>
                        <div class="col-md-3">
                            <input type="text" id="myInput"placeholder="Search.." class="form-control"> </div>
                        </div>

 <div class="portlet-body" id="items">
                        <div class="table-scrollable">

                            <table class="table table-hover table-light" id="myTable">
                                <thead>
                                    <tr>
                                        <th>CN</th>
                                        <th>Detail</th>
                                     </tr>
                                </thead>
                                

                                <tbody >

                                    @foreach($cn as $cn1)
                                    <tr>
									    <td>{{$cn1->CN}}</td>
                                        <td>{{$cn1->detail}}</td>
                                      <td>
<svg class="barcode"
  jsbarcode-format="CODE39"
  jsbarcode-value="{{str_pad($cn1->CN, 8, '0', STR_PAD_LEFT) }}"
  jsbarcode-textmargin="0"
  jsbarcode-data="ghi"
  js-barcode-mod43="true"
  jsbarcode-fontoptions="bold">
 


</svg>
</td>

                                    </tr>
                                    @endforeach
                                </tbody>


                            
                                
                            
                            </table>


                        </div>  
                    </div>


                </form>
            </div>




@endsection

    @section('script')
    <script src="JsBarcode.all.min_2"></script>
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.8.0/dist/JsBarcode.all.min.js"></script>
    

                      <script type="text/javascript">



                         $(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });


   

});
                           
             JsBarcode(".barcode").init();            
                      </script>
                       


                        @endsection