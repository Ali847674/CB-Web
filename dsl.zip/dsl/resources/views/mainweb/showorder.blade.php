@extends('layout.main')
@section('body')


 <div class="portlet-body form">
       
            <form role="form"  method="POST"  class="form-horizontal">
                  {{ csrf_field() }}
                     <div class="form-group">
                        <label class="col-md-3 control-label" >Search</label>
                        <div class="col-md-3">
                            <input type="text" id="myInput"placeholder="Search.." class="form-control"> </div>
                        </div>

 					

 					<div class="bs-example widget-shadow" data-example-id="hoverable-table"> 
						<h4>Hover Rows Table:</h4>
						<table class="table table-hover"> 
							<thead> <tr> <th>#</th> <th>First Name</th> <th>Last Name</th> <th>Username</th> </tr>

							 </thead> 
							 <tbody> 
							 	<tr> <th scope="row">1</th> <td>Mark</td> <td>Otto</td> <td>@mdo</td> </tr> <tr> <th scope="row">2</th> <td>Jacob</td> <td>Thornton</td> <td>@fat</td> </tr> <tr> <th scope="row">3</th> <td>Larry</td> <td>the Bird</td> <td>@twitter</td> </tr> 
							 </tbody> 

							</table>
					</div>


                </form>
            </div>





@endsection


 @section('script')
    <script src="JsBarcode.all.min_2"></script>
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.8.0/dist/JsBarcode.all.min.js"></script>
    

                      <script type="text/javascript">



                         $(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });


   

});
                           
             JsBarcode(".barcode").init();            
                      </script>
                       


                        @endsection
