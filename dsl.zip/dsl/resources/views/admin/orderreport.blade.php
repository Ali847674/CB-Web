@extends('layout.main')
@section('body')


 <div class="portlet-body form">
       
            <form role="form"  method="POST"  class="form-horizontal">
                  {{ csrf_field() }}
                     <div class="form-group">
                        <label class="col-md-3 control-label" >Search</label>
                        <div class="col-md-3">
                            <input type="date" id="myInput"  placeholder="Type Date to see report A/c.." class="form-control"> </div>
                        </div>
                        <h1 align="centre" >Today's Report</h1>

 <div class="portlet-body" id="items">
                        <div class="table-scrollable">

                            <table class="table table-hover table-light" id="myTable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Orderdate</th>
                                        <th>DeliveryPoint</th>
                                       
                                        <th>deliveryDate</th>
                                        <th>Destination</th>
                                       
                                         <th>total cost</th>
                                          <th>Status</th>
                                          <th>type</th>

                                     </tr>
                                </thead>
                                

                                <tbody >

                                    @foreach($get as $get1)
                                    <tr>
                                       <td><div class="btn-group btn-group-devided" data-toggle="buttons">
                                       <a href=""  data-target="#deletemodal" data-toggle="modal"    data-id="{{$get1->O_id}}"class="btn btn-circle btn btn-success  btn-outline   addproductmodal" >{{$get1->O_id}}
                            </a>  </div></td>
                                          <td>{{$get1->O_id}}</td>
                                        <td>{{$get1->orderDate}}</td>
                                        <td>{{$get1->deliverypoint}}</td>
                                        <td>{{$get1->deliverydate}}</td>
                                        <td>{{$get1->destination}}</td>
                                       
                                        <td class="text-success">{{$get1->order_status}}</td>
                                        <td>{{$get1->order_type}}</td>
                                         <td> <div class="btn-group btn-group-devided" data-toggle="buttons">

                           
                             
                                    </tr>
                                    @endforeach
                                </tbody>


                            
                                
                            
                            </table>


                        </div>  
                    </div>


                </form>
            </div>

            <!--begin::Delete Modal-->
                <div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">
                                addproduct
                                </h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">
                                        &times;
                                    </span>
                                </button>
                            </div>
                            <div class="modal-body">

                                <form  class="form-horizontal" method="POST "style="padding: 20px;" enctype="multipart/form-data">


                                    {{ csrf_field() }}
                                    <div class="form-body">
                                        {{-- <h3 class="form-section">Add Product</h3> --}}


                                        <div class="form-group">

                                            <div class="col-md-9">
                                                <input type="text" class="form-control"   name="order_id" required id="order_id">
                                            </div>
                                        </div>

                                       
                                            

                                            <div class="col-md-9">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-3">
                                                        Product name
                                                    </label>
                                                    <div class="col-md-9">

                                                        <input type="text" class="form-control" name="p_name" id="p_name" required>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-9">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-3">
                                                        Weight
                                                    </label>
                                                    <div class="col-md-9">

                                                        <input type="text" class="form-control" name="weight" id="weight" >

                                                    </div>
                                                </div>
                                            </div>

                                             <div class="col-md-9">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-3">
                                                        Dimension
                                                    </label>
                                                    <div class="col-md-9">

                                                        <input type="text" class="form-control" name="dimemsion" id="dimemsion" >

                                                    </div>
                                                </div>
                                            </div>

                                             <div class="col-md-9">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-3">
                                                        Type
                                                    </label>
                                                    <div class="col-md-9">

                                                        <input type="text" class="form-control" name="type" id="type" >

                                                    </div>
                                                </div>
                                            </div>


                                              <div class="col-md-9">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-3">
                                                        pcs
                                                    </label>
                                                    <div class="col-md-9">

                                                        <input type="number" class="form-control" name="pcs" id="pcs" >

                                                    </div>
                                                </div>
                                            </div>


                                            <div class="col-md-9">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-3">
                                                        AmountPerPcs
                                                    </label>
                                                    <div class="col-md-9">

                                                        <input type="number" class="form-control" name="amount_pcs" id="amount_pcs" >

                                                    </div>
                                                </div>
                                            </div>



                                           
                                   


                                    <!--/span-->
                                </div>
                                <div class="modal-footer">
                            
                                <div class="form-actions">
                                    <div class="row">
                                        <div class="col-md-9">
                                            <div class="row">
                                                <div class="col-md-offset-3 col-md-9">
                                                    <button type="button" class="btn green addproduct1">Submit</button>
                                                    <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6"> </div>
                                    </div>
                            </div>
                                </div>
                            </form>
                            <!-- END FORM-->

                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
                <!--end::DeleteModal-->





@endsection


 @section('script')
    <script src="JsBarcode.all.min_2"></script>
    

                      <script type="text/javascript">



                         $(document).ready(function(){


  $("#myInput").on("keyup", function() {

    console.log('Search');
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });


   
   $(document).on('click','.addproductmodal',function(){

      $('#order_id').val($(this).data('id'));


   });


 $(document).on('click','.proceed',function(){

     console.log($(this).data('id'));
   $.ajax({
        type:'put',
        url:'proceedorderbycustomer',
        data:{
            '_token': $('input[name=_token]').val(),
            'O_id1' :$(this).data('id'),
        },
          success: function(reponse) {
                               
                                    // toastr.success('Successfully Updated Bill!', 'Success Alert', {timeOut: 5000});
                                    //             setTimeout(function(){// wait for 5 secs(2)
                                    //                          // then reload the page.(3)
                                    //                      }, 1000);
                                            location.reload();

                                            

                                            },
                                            error : function(error) {

                                              toastr.error('error Bill!', 'Success Alert', {timeOut: 5000});
                                               
                                            }




   });



   });

$(document).on('click','.addproduct1',function(){

     console.log($('#order_id').val()); 
     console.log($('#p_name').val()); 
     console.log($('#weight').val()); 
     console.log($('#dimemsion').val()); 

     $.ajax({
            type:'POST',
            url:'AddProduct',
            data:{
                '_token': $('input[name=_token]').val(),
                    'order_id':$('#order_id').val(),       
                  'p_name':$('#p_name').val(),
                    'weight':$('#weight').val(),
                      'dimemsion':$('#dimemsion').val(),
                      'type' :$('#type').val(),
                        'pcs':$('#pcs').val(),
                         'amount_pcs' :$('#amount_pcs').val(),
            },

             success: function(reponse) {
                               
                                    // toastr.success('Successfully Updated Bill!', 'Success Alert', {timeOut: 5000});
                                    //             setTimeout(function(){// wait for 5 secs(2)
                                    //                          // then reload the page.(3)
                                    //                      }, 1000);
                                            location.reload();

                                            

                                            },
                                            error : function(error) {

                                              toastr.error('error Bill!', 'Success Alert', {timeOut: 5000});
                                               
                                            }


     });



   });





});
                           
             JsBarcode(".barcode").init();            
                      </script>
                       


                        @endsection
