@extends('layout.main')

@section('body')
    {{-- main form --}}
        <div class="portlet-body " >

            <form  class="form-horizontal"  method="post" action="{{url('/addorder')}}" >

                {{ csrf_field() }}
                <div class="form-body">


                    <div class="form-group">
                        <label for="deliverydate" class="col-md-4 control-label">Order Date</label>
                        <div class="col-md-4">
                            <input id="date" type="hidden" name="date" value="{{ \Carbon\Carbon::now()->format('Y-m-d') }}" required>
                            <input type="text" class="form-control" value="{{ \Carbon\Carbon::now()->format('l d-M-Y') }}" readonly>
                        </div>
                    </div>  
                    

                    {{-- <div class="form-group{{$errors->has('customer_id') ? ' has-error' : '' }}">
                        <label for="customer_id" class="col-md-4 control-label">Customer</label>
                        <div class="col-md-4">
                            <select class="form-control" name="customer_id">
                                <option selected disabled value>``Select Customer``</option>
                                @foreach($customer as $key=>$value)
                                    <option value="{{ $value->id }}">{{ $value->name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div> --}}        
                    

                    <div class="form-group{{$errors->has('deliverypoint') ? ' has-error' : '' }}">
                        <label for="email" class="col-md-4 control-label">Delivery Point</label>
                        <div class="col-md-6">
                            <div class="col-md-4">
                                <select class="form-control" name="deliverypoint" required id="city1" required>
                                    <option disabled selected value>Select City</option>
                                    @foreach($cities as $key=>$value)
                                        <option value="{{ encrypt($value->id) }}">{{ $value->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn-xs btn-success citymodal">Add More</button>
                            </div>
                        </div>
                    </div>

                    <div class="form-group{{$errors->has('deliverydate') ? ' has-error' : '' }}">
                        <label for="deliverydate" class="col-md-4 control-label">Delivery Date</label>
                        <div class="col-md-4">
                            <input id="deliverydate" type="date" min="{{ \Carbon\Carbon::now() }}" class="form-control" name="deliverydate" value="{{ old('deliverydate') }}" required>
                        </div>
                    </div>

                    <div class="form-group{{$errors->has('destination') ? ' has-error' : '' }}">
                        <label for="destination" class="col-md-4 control-label">Destination</label>
                        <div class="col-md-6">
                            <div class="col-md-4">
                                <select class="form-control" required name="destination" id="city2" required>
                                    <option disabled selected value>Select City</option>
                                    @foreach($cities as $key=>$value)
                                        <option value="{{ encrypt($value->id) }}">{{ $value->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn-xs btn-success citymodal">Add More</button>
                            </div>
                        </div>
                    </div>

                    <div class="form-group{{$errors->has('type') ? ' has-error' : '' }}">
                        <label for="type" class="col-md-4 control-label">Type</label>
                        <div class="col-md-4">
                            <input id="type" type="text" class="form-control" name="type" required>

                            @if ($errors->has('type'))
                            <span class="help-block">
                                <strong>{{ $errors->first('type') }}</strong>
                            </span>
                            @endif
                        </div>
                    </div>

                    <div class="form-group{{$errors->has('payment_type') ? ' has-error' : '' }}">
                        <label for="payment_type" class="col-md-4 control-label">Payment Type</label>
                        <div class="col-md-4">
                            <input id="payment_type" type="radio" name="payment_type" value="1" required>Cash
                            <input id="payment_type" type="radio" name="payment_type" value="2" required>Credit
                            @if ($errors->has('payment_type'))
                            <span class="help-block">
                                <strong>{{ $errors->first('payment_type') }}</strong>
                            </span>
                            @endif
                        </div>
                    </div>

                    <div class="form-actions">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-offset-9 col-md-9">
                                        <button type="Submit"  class="btn btn-success">Submit</button>
                                        <button type="button" class="btn default" >Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </form>
        </div>
    {{-- end main form --}}

        <!--begin::add city Modal-->
            <div class="modal fade" id="citymodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">
                                Add New City
                            </h5>
                        </div>
                        <div class="modal-body">
                            <form id="city" class="form-horizontal" method="POST" style="padding: 20px;" enctype="multipart/form-data">
                                {{ csrf_field() }}
                                <div class="form-body">
                                    <div class="col-md-9">
                                        <div class="form-group ">
                                            <label class="control-label col-md-4">
                                                City Name
                                            </label>
                                            <div class="col-md-8">
                                                <input type="text" placeholder="City Name" class="form-control" name="name" id="name" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="form-group ">
                                            <label class="control-label col-md-4">
                                                City Acronym
                                            </label>
                                            <div class="col-md-8">
                                                <input type="text" minlength="3" maxlength="4" placeholder="3 - 4 Letter Short Name" class="form-control" name="acr" id="acr" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">

                                    <div class="form-actions">
                                        <div class="row">
                                            <div class="col-md-9">
                                                <div class="row">
                                                    <div class="col-md-offset-3 col-md-9">
                                                        <button type="submit" class="btn green addproduct1">Submit</button>
                                                        <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6"> </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <!--end::Add city Modal-->






@endsection

@section('script')
    <script type="text/javascript">
	


        $(document).ready(function ()
        {
            $(document).on('click', '.addorder', function()
            {

               $.ajax
               ({
                     type: 'post',
                     url: 'addorder',
                     data: {
                        '_token': $('input[name=_token]').val(),
                        'deliverypoint': $('#deliverypoint').val(),
                        'deliverydate': $('#deliverydate').val(),
                        'destination' : $('#destination').val(),
                        'productweight': $('#productweight').val(),
                        'dimension': $('#dimension').val(),
                        'totalcost': $('#totalcost').val(),
                        'type': $('#type').val(),
                    },
                    success: function(reponse) {

                        toastr.success('Successfully Updated Bill!', 'Success Alert', {timeOut: 5000});
                        setTimeout(function()
                        {
                        }, 1000);
                    },
                    error : function(error) {
                       toastr.error('error Bill!', 'Success Alert', {timeOut: 5000});
                   }
                });
                console.log('log');
            });

            $(document).on('click','.citymodal',function()
            {
                $('#citymodal').modal('show');
            });

            $(document).on('submit','#city',function(event)
            {
                event.preventDefault();
                var data = $(this).serialize();
                console.log(data);
                $(this).serialize();
                $.ajax({
                    url: "{{ route('addcity') }}",
                    type: "POST",
                    data: {
                        '_token':$('input[name=_token]').val(),
                        'name':$('#name').val(),
                        'acr':$('#acr').val()
                    },
                    success:function(data)
                    {
                        if (data == 'name')
                        {
                            toastr.error('City With Same Name Already Exist','Error Alert');
                        }
                        else if (data == 'acr')
                        {
                            toastr.error('City With Same Acronym Already Exist','Error Alert');
                        }
                        else
                        {
                            console.log(data);
                            toastr.success('New City Added Successfully','Success Alert');
                            $('#city1').append(' <option value="' + data + ' "> ' + $('#name').val() + ' </option> ');
                            $('#city2').append(' <option value="' + data + ' "> ' + $('#name').val() + ' </option> ');
                        }
                        
                    },
                    error:function()
                    {
                        toastr.error('Server Down','Error Alert');
                    }
                });
            });


        });

    </script>

                   






                    @endsection