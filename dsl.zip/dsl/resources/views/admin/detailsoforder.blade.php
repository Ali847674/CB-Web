@extends('layout.main')
	@section('body')
    
		<style>
                *
                {

                    font-family: roboto;
                    font-size: 15px;
                }
                table, td, th {
                  border: 1px solid black;
                }

                table {
                  border-collapse: collapse;
                  width: 100%;
                }

                th {
                  text-align: left;
                }

                td
                {
                  text-align: center;
                }

                img.imgbar {
                    width: 314px;
                }

                td.rightside {
                    text-align: right;
                }

                td.leftside {
                    text-align: left;
                }

                td.test {
                    width: 70px;
                }

                p.tac {
                    font-size: 20px;
                    margin-top: 5px;
                    margin-bottom: 5px;
                }
                ul.ultac {
                    padding-left: 18px;
                    margin-top: 0px;
                }
    	</style>  
        <form action="{{ route('updateorder') }}" method="POST">

            <input type="hidden" name="id" value="{{ $order[0]->id }}">
            <input type="hidden" name="created_id" value="{{ Auth::user()->id }}">
            {{ csrf_field() }}
    	<table>
    		<tr>
    			<td colspan="4" rowspan="4"  class="test"><img height="100" src="logo2.jpg"></td>               
    			<td colspan="5" rowspan="4" ><img height="100" src="bar.png" class="imgbar"></td>
    			<td colspan="3">DSL CLIENT A/C # </td>
    			<td>DATE</td>
    			<td colspan="3">
    				<strong><u>{{ $order[0]->date }}</u></strong>
    				<input type="hidden" value="{{ \Carbon\Carbon::now()->format('Y-m-d') }}" name="date">
    			</td>
    		</tr>
    		<tr>
    			<td colspan="3" class="test"><input type="text" name="account_no" class="form-control" value="{{ $order[0]->account_no }}"></td>
    			<td colspan="4"><strong>SHIPMENTS DETAIL'S </strong></td>
    		</tr>
    		<tr>
    			<td colspan="3">TRACKING VIA </td>
    			<td colspan="2">ORIGIN </td>
    			<td colspan="2">DESTINATION</td>
    		</tr>
    		<tr>
    			<td colspan="3" class="test"><input type="text" name="ref_no" class="form-control" value="{{$order[0]->ref_no}}"></td>
    			<td colspan="2">
                    @if($order[0]->region == "INTERNATIONAL")
    				{{$order[0]->origin}}
                    @else
                    <select class="form-control" name="origin">
                        @foreach($cities as $city)
                            <option value="{{ $city->id }}">{{ $city->name }}</option>
                        @endforeach
                    </select>
                    @endif
    			</td>
    			<td colspan="2" class="test">
                    @if($order[0]->region == "INTERNATIONAL")
                    <select class="form-control" name="destination">
                        @foreach($countries as $country)
                            <option value="{{ $country->id }}">{{ $country->name }}</option>
                        @endforeach
                    </select>
                    @else
                    <select class="form-control" name="destination">
                        @foreach($cities as $city)
                            <option value="{{ $city->id }}">{{ $city->name }}</option>
                        @endforeach
                    </select>
                    @endif
    			</td>
    		</tr>
    		<tr>
    			<td colspan="12" class="leftside"><strong>FROM DETAIL'S</strong></td>               
    			<td colspan="2">WEIGHT (KG)</td>
    			<td colspan="2">WEIGHT (DIM)</td>
    		</tr>
    		<tr>
    			<td colspan="3" class="rightside">SENDER NAME</td>               
    			<td colspan="4" class="test">
    				<input type="text" name="sender_name" class="form-control" value="{{$order[0]->sender_name}}">
    			</td>
    			<td colspan="2">COMPANY NAME</td>
    			<td colspan="3" class="test">
    				<input type="text" name="sender_company" class="form-control" value="{{$order[0]->sender_company}}">
    			</td>
    			<td colspan="2" class="test">
    				<input type="text" name="weight_kg" class="form-control" value="{{$order[0]->weight_kg}}">
    			</td>
    			<td colspan="2" class="test">
    				<input type="text" name="weight_dim" class="form-control" value="{{$order[0]->weight_dim}}">
    			</td>
    		</tr>
    		<tr>
    			<td colspan="3" class="rightside">CELL #</td>               
    			<td colspan="5" class="test">
    				<input type="text" name="sender_cell" class="form-control" value="{{$order[0]->sender_cell}}">
    			</td>
    			<td>LINE #</td>
    			<td colspan="3" class="test">
    				<input type="text" name="" class="form-control" value="{{$order[0]->sender_line}}">
    			</td>
    			<td colspan="2">PIECES</td>
    			<td colspan="2">PACKAGE</td>
    		</tr>
    		<tr>
    			<td colspan="3" class="rightside">ADDRESS</td>               
    			<td colspan="9" class="test">
    				<input type="text" name="sender_address" class="form-control" value="{{$order[0]->sender_address}}">
    			</td>
    			<td colspan="2" class="test">
    				<input type="text" name="pieces" class="form-control" value="{{$order[0]->pieces}}">
    			</td>
    			<td colspan="2">
                    @if($order[0]->region == "INTERNATIONAL")
    				{{$order[0]->package_id}}
                    @else
                    <select class="form-control" name="package_id">
                        <option disabled selected value>Select PACKAGE</option>
                        @foreach($packages as $package)
                            <option value="{{ $package->id }}">{{ $package->name }}</option>
                        @endforeach
                    </select>
                    @endif
    			</td>
    		</tr>
    		<tr>
    			<td colspan="12" class="test"></td>               
    			<td colspan="2">SERVICE TYPE </td>
    			<td colspan="2">PAYMENT</td>
    		</tr>
    		<tr>
    			<td colspan="8" class="test"></td>               
    			<td colspan="2">POSTAL CODE</td>
    			<td colspan="2" class="test">
    				<input type="text" name="sender_postal" class="form-control" value="{{$order[0]->sender_postal}}">
    			</td>
    			<td colspan="2">
                    @if($order[0]->region == "INTERNATIONAL")
    				{{$order[0]->service_type}}
                    @else
                    <select class="form-control" name="service_type">
                        <option disabled selected value>Select Service Type</option>
                        @foreach($services as $service)
                            <option value="{{ $service->id }}">{{ $service->name }}</option>
                        @endforeach
                    </select>
                    @endif
    			</td>
    			<td colspan="2">
    				<select class="form-control" name="payment_id">
                        <option disabled selected value>Select PAYMENT Type</option>  
                        @foreach($payments as $payment)
                        <option value="{{ $payment->id }}">{{ $payment->name }}</option>
                        @endforeach       
                    </select>
    			</td>
    		</tr>
    		<tr>
    			<td colspan="12" class="leftside"><strong>TO DETAIL'S</strong></td>               
    			<td colspan="2">CHARGES </td>
    			<td colspan="2">PAK RUPEES</td>
    		</tr>
    		<tr>
    			<td colspan="3" class="rightside">RECEIVER NAME </td>               
    			<td colspan="4" class="test">
    				<input type="text" name="receiver_name" class="form-control" value="{{$order[0]->receiver_name}}">
    			</td>
    			<td colspan="2">COMPANY NAME</td>
    			<td colspan="3" class="test">
    				<input type="text" name="receiver_company" class="form-control" value="{{$order[0]->receiver_company}}">
    			</td>
    			<td colspan="2">AMOUNT</td>
    			<td colspan="2" class="test">
    				<input type="text" name="amount" id="field1" class="form-control" value="{{$order[0]->amount}}">
    			</td>
    		</tr>
    		<tr>
    			<td colspan="3" class="rightside">CELL# </td>               
    			<td colspan="5" class="test">
    				<input type="text" name="receiver_cell" class="form-control" value="{{$order[0]->receiver_cell}}">
    			</td>
    			<td>LINE #</td>
    			<td colspan="3" class="test">
    				<input type="text" name="receiver_line" class="form-control" value="{{$order[0]->receiver_line}}">
    			</td>
    			<td colspan="2">GST%</td>
    			<td colspan="2" class="test">
    				<input type="text" name="gst" id="field2" class="form-control" value="{{$order[0]->gst}}">
    			</td>
    		</tr>
    		<tr>
    			<td colspan="3" class="rightside">ADDRESS</td>               
    			<td colspan="9" class="test">
    				<input type="text" name="receiver_address" class="form-control" value="{{$order[0]->receiver_address}}">
    			</td>
    			<td colspan="2">DISCOUNT</td>
    			<td colspan="2" class="test">
    				<input type="text" name="discount" id="field3" class="form-control" value="{{$order[0]->discount}}">
    			</td>
    		</tr>
    		<tr>
    			<td colspan="12" class="test"></td>               
    			<td colspan="2">TOTAL</td>
    			<td colspan="2" class="test">
    				<input type="text" id="field4" name="total" class="form-control" value="{{$order[0]->total}}">
    			</td>
    		</tr>
    		<tr>
    			<td colspan="8" class="test"></td>               
    			<td colspan="2">POSTAL CODE</td>
    			<td colspan="2" class="test">
    				<input type="text" name="receiver_postal" class="form-control" value="{{$order[0]->receiver_postal}}">
    			</td>
    			<td colspan="4" rowspan="6" width="1px">"i confirm and affirm that i have understood and agree on all the rates and terms and conditions should hereinafter and that all details given here in are true and correct. This execution of this consignment note is prima facia evidence of the conclusions of contract between shipper & DSL"</td>
    		</tr>
    		<tr>
    			<td colspan="8"><strong>COMMODITY DESCRIPTION</strong></td>               
    			<td colspan="2">DOX / NON DOX </td>
    			<td colspan="2">INVOICE</td>              
    		</tr>
    		<tr>
    			<td colspan="3" class="test">
    				<input type="text" class="form-control" id="e1" name="name[]" value="{{$product[0]->name ?? 'Null'}}">
    			</td>               
    			<td class="test">
    				<input type="text" class="form-control" id="e2" name="quantity[]" value="{{$product[0]->quantity ?? 'Null'}}">
    			</td>
    			<td colspan="3" class="test">
    				<input type="text" class="form-control" id="e3" name="name[]" value="{{$product[1]->name ?? 'Null'}}">
    			</td>
    			<td class="test">
    				<input type="text" class="form-control" id="e4" name="quantity[]" value="{{$product[1]->quantity ?? 'Null'}}">
    			</td>
    			<td colspan="2" class="test">
    				@foreach($dutiable as $duty)
                        <input type="radio" name="dutiable" value="{{ $duty->id }}">{{ $duty->name }}
                    @endforeach
    			</td>
    			<td colspan="2">
    				<input type="text" name="insurance" class="form-control" value="{{$order[0]->insurance}}">
    			</td>               

    		</tr>
    		<tr>
    			<td colspan="3" class="test">
    				<input type="text" class="form-control" id="e5" name="name[]" value="{{$product[2]->name ?? 'Null'}}">
    			</td>               
    			<td class="test">
    				<input type="text" class="form-control" id="e6" name="quantity[]" value="{{$product[2]->quantity ?? 'Null'}}">
    			</td>
    			<td colspan="3" class="test">
    				<input type="text" class="form-control" id="e7" name="name[]" value="{{$product[3]->name ?? 'Null'}}">
    			</td>
    			<td class="test">
    				<input type="text" class="form-control" id="e8" name="quantity[]" value="{{$product[3]->quantity ?? 'Null'}}">
    			</td>
    			<td colspan="2">TOTAL CONTENTS </td>
    			<td colspan="2">VALUE $</td>               
    		</tr>
    		<tr>
    			<td colspan="3" class="test">
    				<input type="text" class="form-control" id="e9" name="name[]" value="{{$product[4]->name ?? 'Null'}}">
    			</td>               
    			<td class="test">
    				<input type="text" class="form-control" id="e10" name="quantity[]" value="{{$product[4]->quantity ?? 'Null'}}">
    			</td>
    			<td colspan="3" class="test">
    				<input type="text" class="form-control" id="e11" name="name[]" value="{{$product[5]->name ?? 'Null'}}">
    			</td>
    			<td class="test">
    				<input type="text" class="form-control" id="e12" name="quantity[]" value="{{$product[5]->quantity ?? 'Null'}}">
    			</td>
    			<td colspan="2">
    				<input type="text" name="contents" class="form-control" value="{{$order[0]->contents}}">
    			</td>
    			<td colspan="2" class="test">
    				<input type="text" name="value" class="form-control" value="{{$order[0]->value}}">
    			</td>              
    		</tr>
    		<tr>
    			<td colspan="10" width="1px" class="leftside">OFFICE: SHOP 46-A BC-5-6 1ST FLOOR, SASI ARCADE, BLOCK-7 CLIFTON KARACHI- 75600</td>
    			<td class="test"></td>               
    			<td class="test"></td>               
    		</tr>
    		<tr>
    			<td colspan="7" class="leftside">EMAIL : dailyswipelogistics@gmail.com</td> 
    			<td colspan="4" class="leftside">TEL: 021-35879946, CELL:03122699902</td>
    			<td class="test"></td>              
    			<td colspan="4"><strong>SHIPPER'S SIGNATURE</strong></td>               
    		</tr>
    	</table>

    	<div>
    		<p class="tac">TERMS & CONDITIONS <span style="margin-left: 35px; ">Shipment Via DSL Courier For Documents/Parcels Are Subject To The Following Terms & Conditions</span></p> 
    		<ul class="ultac">
    			<li> DSL courier reserves the rights to inspect the goods to insured that they are capable of carriage to the countries of destination.</li>
    			<li> Any Consignments note if not Insured through DSL Courier Service by the Shipper it will be treated ''On Shipper's Risk''</li>
    			<li> Any Complained by the shipper should be notified within 24 hours after delivery at destination iin written</li>
    			<li> Rates are excusive of any value added tax,duties at destination</li>
    			<li> Shipper is liable to provide complete packing list with values of goods</li>
    		</ul>
    	</div>
        <input style="margin-left: 85%" type="submit" value="submit" class="btn btn-primary">
    </form>
	@stop

	@section('script')
        <script type="text/javascript">
        $(document).ready(function(){
            $('input').prop('required',true);
            $('select').prop('required',true);
            for (var i=1 ; i < 13; i++) 
            {
                $('#e'+i).prop('required',false);
                $('#e'+i).prop('disabled',true);

            }
        });
        $(document).ready(function()
        {
            var gstamount = 0;
            $(document).on('change paste keyup keypress keydown','#field1', function()
            {
                var a = $(this).val();
                var b = gstamount;
                var c = $('#field3').val();

                var d = ((+a)+(+gstamount))-(+c);
                $('#field4').val(d);
            });

            // GST Calculation
            $(document).on('change paste keyup keypress keydown','#field2', function()
            {
                var a = $(this).val();
                var b = $('#field1').val();
                var c = $('#field3').val();

                gstamount = ((+a)*(+b))/100;
                var d  = ((+b) + (+gstamount)) - (+c); 
                $('#field4').val(d);
            });
            $(document).on('change paste keyup keypress keydown','#field3', function()
            {
                var a = $(this).val();
                var b = $('#field1').val();
                var c = gstamount;

                var d  = ((+b) + (+gstamount)) - (+a);
                $('#field4').val(d);
            });
        });
        </script>
	@stop