@extends('layout.main')

@section('body')


<!--  <div class="portlet-body " >
@foreach($image1 as $img) 
<img class="img-responsive" src="../{{$img->image}}" alt="Chania">
@endforeach -->

<div class="main-page">
				<h2 class="title1">Widgets</h2>
				<div class="elements">
					<!--photoday-section-->	
                    	<div class="col-sm-4 wthree-crd widgettable">
                            <div class="card">
                                <div class="card-body">
							<div class="agileinfo-cdr">
                                        
                                <div class="card-header">
                                    <h3>Report</h3>
                                </div>
                                <hr class="widget-separator">
                                        
                                        <div class="widget-body">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Amount</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>#24436</td>
                                                        <td>Maecenas molestie</td>
                                                        <td>$2,100.00</td>
                                                    </tr>
                                                    <tr>
                                                        <td>#2118</td>
                                                        <td>Vivamus molestie</td>
                                                        <td>$4,200.00</td>
                                                    </tr>
                                                    
                                                    <tr>
                                                        <td>#6668</td>
                                                        <td>Donec at auctor</td>
                                                        <td>$1,900.00</td>
                                                    </tr>                                                    
                                                    <tr>
                                                        <td>#8446</td>
                                                        <td>Nullam sollicitudin</td>
                                                        <td>$4,300.00</td>
                                                    </tr>
                                                    <tr>
                                                        <td>#3279</td>
                                                        <td>Ullamcorper dictum</td>
                                                        <td>$3,600.00</td>
                                                    </tr>
                                                </tbody>
                                            </table>    
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-4 w3-agileits-crd widgettable">
						
                            <div class="card card-contact-list">
							<div class="agileinfo-cdr">
                                <div class="card-header">
                                    <h3>Contacts</h3>
                                </div>
                                <hr class="widget-separator">
                                <div class="card-body p-b-20">
                                    <div class="list-group">
                                    	@foreach($image1 as $img) 
                                        <a class="list-group-item media" href="">
                                             <div class="pull-left">
                                                <img class="lg-item-img" src="../{{$img->image}}" alt="" width="">
                                            </div>
                                            <div class="media-body">
                                                s<div class="pull-left">
                                                	<div class="lg-item-heading">{{$img->name}}</div>
                                                	<small class="lg-item-text">{{$img->email}}</small>
                                                </div>
                                                <div class="pull-right">
                                                	<div class="lg-item-heading">{{$img->type}}</div>
                                                </div>
                                            </div>
                                        </a>

                                        @endforeach
                                       
                                        
                                   	</div>
                                </div>
                            </div>
							</div>
                      	</div>
                    	<div class="col-sm-4 w3-agile-crd widgettable">
                            <div class="card">
                                <div class="card-body card-padding">
                                    <div class="">
                                        <header class="widget-header">
                                            <h4 class="widget-title">Activities</h4>
                                        </header>
                                        <hr class="widget-separator">
                                        <div class="widget-body">
                                            <div class="streamline">
                                                <div class="sl-item sl-primary">
                                                    <div class="sl-content">
                                                        <small class="text-muted">0 mins ago</small>
                                                        <p>Alexander has just joined</p>
                                                    </div>
                                                </div>
                                                <div class="sl-item sl-danger">
                                                    <div class="sl-content">
                                                        <small class="text-muted">15 minutes ago</small>
                                                        <p>Michael has sent a request for access</p>
                                                    </div>
                                                </div>
                                                <div class="sl-item sl-success">
                                                    <div class="sl-content">
                                                        <small class="text-muted">18 minutes ago</small>
                                                        <p>chris added you to his team</p>
                                                    </div>
                                                </div>
                                                <div class="sl-item">
                                                    <div class="sl-content">
                                                        <small class="text-muted">22 minutes ago</small>
                                                        <p>jackson has finished his task</p>
                                                    </div>
                                                </div>
                                                <div class="sl-item sl-warning">
                                                    <div class="sl-content">
                                                        <small class="text-muted">30 minutes ago</small>
                                                        <p>Jacob shared a folder with you</p>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
						<div class="clearfix"></div>
                   
	<!--//photoday-section-->

		<!-- mainpage-chit -->
		<div class="chit-chat-layer1">
	<div class="col-md-6 chit-chat-layer1-left">
               <div class="work-progres">
                                        <header class="widget-header">
                                            <h4 class="widget-title">Recent Followers</h4>
                                        </header>
							<hr class="widget-separator">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                  <thead>
                                    <tr>
                                      <th>#</th>
                                      <th>Project</th>
                                      <th>Manager</th>                                   
                                                                        
                                      <th>Status</th>
                                      <th>Progress</th>
                                  </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td>1</td>
                                  <td>Face book</td>
                                  <td>Alexander</td>                                 
                                                             
                                  <td><span class="label label-danger">in progress</span></td>
                                  <td><span class="badge badge-info">70%</span></td>
                              </tr>
                              <tr>
                                  <td>2</td>
                                  <td>Twitter</td>
                                  <td>Lucika adam</td>                               
                                                                  
                                  <td><span class="label label-success">completed</span></td>
                                  <td><span class="badge badge-success">80%</span></td>
                              </tr>
                              <tr>
                                  <td>3</td>
                                  <td>Google</td>
                                  <td>Michael</td>                                
                                  
                                  <td><span class="label label-warning">in progress</span></td>
                                  <td><span class="badge badge-warning">30%</span></td>
                              </tr>
                              <tr>
                                  <td>4</td>
                                  <td>LinkedIn</td>
                                  <td>Chris dany</td>                                 
                                                             
                                  <td><span class="label label-info">in progress</span></td>
                                  <td><span class="badge badge-info">55%</span></td>
                              </tr>
                              <tr>
                                  <td>5</td>
                                  <td>Tumblr</td>
                                  <td>Jacob velly</td>                                
                                                                 
                                  <td><span class="label label-warning">in progress</span></td>
                                  <td><span class="badge badge-danger">75%</span></td>
                              </tr>
                              <tr>
                                  <td>6</td>
                                  <td>Tesla</td>
                                  <td>Donald chris</td>                                  
                                                             
                                  <td><span class="label label-info">in progress</span></td>
                                  <td><span class="badge badge-success">25%</span></td>
                              </tr>
                              <tr>
                                  <td>7</td>
                                  <td>Behance</td>
                                  <td>alexa louis</td>                                  
                                                             
                                  <td><span class="label label-info">in progress</span></td>
                                  <td><span class="badge badge-success">100%</span></td>
                              </tr>
                          </tbody>
                      </table>
                  </div>
             </div>
      </div>
      <div class="col-md-6 chit-chat-layer1-rit">    	
      	  <div class="geo-chart">
					<section id="charts1" class="charts">
				<div class="wrapper-flex">
				
				    <table id="myTable" class="geoChart tableChart data-table col-table myTable chtr-table" style="display: none; position: absolute; top: -99999px; width: 485px;">
				        <caption>Student Nationalities Table</caption>
				        <tbody><tr>
				            <th scope="col" data-type="string">Country</th>
				            <th scope="col" data-type="number">Number of Students</th>
				            <th scope="col" data-role="annotation">Annotation</th>
				        </tr>
				        <tr>
				            <td>China</td>
				            <td align="right">20</td>
				            <td align="right">20</td>
				        </tr>
				        <tr>
				            <td>Colombia</td>
				            <td align="right">5</td>
				            <td align="right">5</td>
				        </tr>
				        <tr>
				            <td>France</td>
				            <td align="right">3</td>
				            <td align="right">3</td>
				        </tr>
				        <tr>
				            <td>Italy</td>
				            <td align="right">1</td>
				            <td align="right">1</td>
				        </tr>
				        <tr>
				            <td>Japan</td>
				            <td align="right">18</td>
				            <td align="right">18</td>
				        </tr>
				        <tr>
				            <td>Kazakhstan</td>
				            <td align="right">1</td>
				            <td align="right">1</td>
				        </tr>
				        <tr>
				            <td>Mexico</td>
				            <td align="right">1</td>
				            <td align="right">1</td>
				        </tr>
				        <tr>
				            <td>Poland</td>
				            <td align="right">1</td>
				            <td align="right">1</td>
				        </tr>
				        <tr>
				            <td>Russia</td>
				            <td align="right">11</td>
				            <td align="right">11</td>
				        </tr>
				        <tr>
				            <td>Spain</td>
				            <td align="right">2</td>
				            <td align="right">2</td>
				        </tr>
				        <tr>
				            <td>Tanzania</td>
				            <td align="right">1</td>
				            <td align="right">1</td>
				        </tr>
				        <tr>
				            <td>Turkey</td>
				            <td align="right">2</td>
				            <td align="right">2</td>
				        </tr>
				
				    </tbody></table>
				
				    <div class="col geo_main">
				         <h3 id="geoChartTitle">World Market</h3>
				        <div id="geoChart" class="chart"> </div>
				    </div>
				
				
				</div><!-- .wrapper-flex -->
				</section>				
			</div>

      </div>
     <div class="clearfix"> </div>
</div>
		<!-- //mainpage-chit -->
		
					
		<div class="agil-info-calendar">
		<!-- calendar -->
		<div class="col-md-4 agile-calendar">
			<div class="calendar-widget">
                                        <header class="widget-header">
                                            <h4 class="widget-title">Calender widget</h4>
                                        </header>
							<hr class="widget-separator">
				<!-- grids -->
					<div class="agile-calendar-grid">
						<div class="page">
							
							<div class="w3l-calendar-left">
								<div class="calendar-heading">
									
								</div>
								<div class="monthly" id="mycalendar"></div>
							</div>
							
							<div class="clearfix"> </div>
						</div>
					</div>
			</div>
		</div>
		<div class="col-md-4 stats-info widget">
						<div class="stats-info-agileits">
                                        <header class="widget-header">
                                            <h4 class="widget-title">Browser stats</h4>
                                        </header>
                                        <hr class="widget-separator">
							<div class="stats-body">
								<ul class="list-unstyled">
									<li>GoogleChrome <span class="pull-right">85%</span>  
										<div class="progress progress-striped active progress-right">
											<div class="bar green" style="width:85%;"></div> 
										</div>
									</li>
									<li>Firefox <span class="pull-right">35%</span>  
										<div class="progress progress-striped active progress-right">
											<div class="bar yellow" style="width:35%;"></div>
										</div>
									</li>
									<li>Internet Explorer <span class="pull-right">78%</span>  
										<div class="progress progress-striped active progress-right">
											<div class="bar red" style="width:78%;"></div>
										</div>
									</li>
									<li>Safari <span class="pull-right">50%</span>  
										<div class="progress progress-striped active progress-right">
											<div class="bar blue" style="width:50%;"></div>
										</div>
									</li>
									<li>Opera <span class="pull-right">80%</span>  
										<div class="progress progress-striped active progress-right">
											<div class="bar light-blue" style="width:80%;"></div>
										</div>
									</li>
									<li>Microsoft Edge <span class="pull-right">78%</span>  
										<div class="progress progress-striped active progress-right">
											<div class="bar red" style="width:78%;"></div>
										</div>
									</li>
									<li class="last">Others <span class="pull-right">60%</span>  
										<div class="progress progress-striped active progress-right">
											<div class="bar orange" style="width:60%;"></div>
										</div>
									</li> 
								</ul>
							</div>
						</div>
					</div>
					<div class="col-md-4 chart-layer1-right"> 
						<div class="user-marorm">
						<div class="malorum-top">				
						</div>
						<div class="malorm-bottom">
							<span class="malorum-pro"> </span>
							 <h2>Calorine ELiza</h2>
							<p>Fusce elit sem, dictum non gravida vitae, pulv
							inar ac mi. Proin aliquet ex nunc, sodales efficitur 
							ris imperdiet et. Vestibulum antei psum primis in faucibus orci luctus et </p>
							<ul class="malorum-icons">
								<li><a href="#"><i class="fa fa-facebook"> </i>
									<div class="tooltip"><span>Facebook</span></div>
								</a></li>
								<li><a href="#"><i class="fa fa-twitter"> </i>
									<div class="tooltip"><span>Twitter</span></div>
								</a></li>
								<li><a href="#"><i class="fa fa-google-plus"> </i>
									<div class="tooltip"><span>Google</span></div>
								</a></li>
							</ul>
						</div>
					   </div>
					</div>
		<div class="clearfix"></div>
		</div>
		<!-- //calendar -->	
				</div>
			</div>






@endsection