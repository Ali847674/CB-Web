@extends('layout.main')
@section('body')
    <style>
                *
                {

                    font-family: roboto;
                    font-size: 15px;
                }
                table, td, th {
                  border: 1px solid black;
                }

                table {
                  border-collapse: collapse;
                  width: 100%;
                }

                th {
                  text-align: left;
                }

                td
                {
                  text-align: center;
                }

                img.imgbar {
                    width: 314px;
                }

                td.rightside {
                    text-align: right;
                }

                td.leftside {
                    text-align: left;
                }

                td.test {
                    width: 70px;
                }

                p.tac {
                    font-size: 20px;
                    margin-top: 5px;
                    margin-bottom: 5px;
                }
                ul.ultac {
                    padding-left: 18px;
                    margin-top: 0px;
                }
    </style>  
        {{-- <span href=""  class="btn btn-success pendingorders" >Pending Orders</span> --}}
        <span href=""  class="btn btn-warning productorders" >Domestic Orders</span>
        <span href=""  class="btn btn-danger pendingorders" >International Orders</span>
        <span href=""  class="btn btn-primary" data-toggle="modal" data-target="#ordermodal">New Domestic Booking</span>
        <span href=""  class="btn btn-info" data-toggle="modal" data-target="#ordermodal1">New International Booking</span><br><br><br>
        {{-- begin:: main table --}}
            <div class="portlet-body form">
                <input type="hidden" id="useful">
                {{-- <form action="{{ route('neworder') }}">
                   <button type="submit" class="btn btn-info">Create Order</button>
                </form>--}}  
                            {{-- <form role="form"  method="POST"  class="form-horizontal"> --}}
                              {{ csrf_field() }}
                                {{-- <div class="form-group">
                                    <label class="col-md-3 control-label" >Search</label>
                                    <div class="col-md-3">
                                        <input type="text" id="myInput"placeholder="Search.." class="form-control">
                                    </div>
                                </div> --}}

                                <div class="portlet-body" id="items">
                                    <div class="table-scrollable">
                                        <table class="table table-hover table-light" id="myTable">
                                            <thead>
                                                <tr>
                                                    <th>Order Code</th>
                                                    <th>Orderdate</th>
                                                    <th>Customer Name</th>
                                                    <th>Origin</th>
                                                    <th>Destination</th>
                                                    <th>Type</th>
                                                    <th>Activity</th>
                                                    <th>Confirm</th>
                                                    {{-- <th>Action</th> --}}
                                                </tr>
                                            </thead>
                                            <tbody id="orderbody">
                                            </tbody>
                                        </table>
                                    </div>  
                                </div>
                        {{-- </form> --}}
            </div>
        {{--end:: main table  --}}
        
            <!--begin::add domestic order Modal-->
                <div class="modal fade bd-example-modal-lg" id="ordermodal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-lg" style="width:1250px;">
                <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">
                                <legend>Domestic Booking</legend>
                                </h5>
                            </div>
                            <div class="modal-body">
                                <form id="createorder"  class="form-horizontal">
                                    {{ csrf_field() }}
                                    <table>
                                        <tr>
                                            <td colspan="4" rowspan="4"  class="test"><img height="100" src="logo2.jpg"></td>               
                                            <td colspan="5" rowspan="4" ><img height="100" src="bar.png" class="imgbar"></td>
                                            <td colspan="3">DSL CLIENT A/C # </td>
                                            <td>DATE</td>
                                            <td colspan="3">
                                                <strong><u>{{ \Carbon\Carbon::now()->format('l d-M-Y') }}</u></strong>
                                                <input type="hidden" value="{{ \Carbon\Carbon::now()->format('Y-m-d') }}" name="date">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="test"><input class="form-control" type="text" placeholder="Enter A/C No" name="account_no"></td>
                                            <td colspan="4"><strong>SHIPMENTS DETAIL'S </strong></td>
                                        </tr>
                                        <tr>
                                            <td colspan="3">TRACKING VIA </td>
                                            <td colspan="2">ORIGIN </td>
                                            <td colspan="2">DESTINATION</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="test"><input class="form-control"  type="text" placeholder="Enter REF No" name="ref_no"></td>
                                            <td colspan="2">
                                                <select class="form-control"  name="origin">
                                                    <option disabled selected value>Select Destination</option>
                                                    @foreach($cities as $city)
                                                        <option value="{{ $city->id }}">{{ $city->name }}</option>
                                                    @endforeach
                                                </select>
                                            </td>
                                            <td colspan="2" class="test">
                                                <select class="form-control"  name="destination">
                                                    <option disabled selected value>Select Destination</option>
                                                    @foreach($cities as $city)
                                                        <option value="{{ $city->id }}">{{ $city->name }}</option>
                                                    @endforeach
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="12" class="leftside"><strong>FROM DETAIL'S</strong></td>               
                                            <td colspan="2">WEIGHT (KG)</td>
                                            <td colspan="2">WEIGHT (DIM)</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">SENDER NAME</td>               
                                            <td colspan="4" class="test">
                                                <input class="form-control"  type="text" placeholder="Enter Sender Name" name="sender_name">
                                            </td>
                                            <td colspan="2">COMPANY NAME</td>
                                            <td colspan="3" class="test">
                                                <input class="form-control"  type="text" placeholder="Enter Company Name" name="sender_company">
                                            </td>
                                            <td colspan="2" class="test">
                                                <input class="form-control"  type="text" placeholder="Weight in KG" name="weight_kg">
                                            </td>
                                            <td colspan="2" class="test">
                                                <input class="form-control"  type="text" placeholder="Weight in Dimension" name="weight_dim">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">CELL #</td>               
                                            <td colspan="5" class="test">
                                                <input class="form-control"  type="text" placeholder="Enter #" name="sender_cell">
                                            </td>
                                            <td>LINE #</td>
                                            <td colspan="3" class="test">
                                                <input class="form-control"  type="text" placeholder="Enter LINE#" name="sender_line">
                                            </td>
                                            <td colspan="2">PIECES</td>
                                            <td colspan="2">PACKAGE</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">ADDRESS</td>               
                                            <td colspan="9" class="test">
                                                <input class="form-control"  type="text" name="sender_address" placeholder="Enter Address">
                                            </td>
                                            <td colspan="2" class="test"><input placeholder="No Of Pieces" class="form-control" type="text" name="pieces"></td>
                                            <td colspan="2">
                                                <select class="form-control" name="package_id">
                                                    <option disabled selected value>Select PACKAGE Type</option>
                                                    @foreach($packages as $package)
                                                        <option value="{{ $package->id }}">{{ $package->name }}</option>
                                                    @endforeach
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="12" class="test"></td>               
                                            <td colspan="2">SERVICE TYPE </td>
                                            <td colspan="2">PAYMENT</td>
                                        </tr>
                                        <tr>
                                            <td colspan="8" class="test"></td>               
                                            <td colspan="2">POSTAL CODE</td>
                                            <td colspan="2" class="test">
                                                <input class="form-control" placeholder="Enter POSTAL Code" type="text" name="sender_postal">
                                            </td>
                                            <td colspan="2">
                                                <select class="form-control" name="service_type">
                                                    <option disabled selected value>Select Service Type</option>
                                                    @foreach($services as $service)
                                                        <option value="{{ $service->id }}">{{ $service->name }}</option>
                                                    @endforeach
                                                </select>
                                            </td>
                                            <td colspan="2">
                                                <select class="form-control" name="payment_id">
                                                    <option disabled selected value>Select PAYMENT Type</option>
                                                    @foreach($payment as $service)
                                                        <option value="{{ $service->id }}">{{ $service->name }}</option>
                                                    @endforeach
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="12" class="leftside"><strong>TO DETAIL'S</strong></td>               
                                            <td colspan="2">CHARGES </td>
                                            <td colspan="2">PAK RUPEES</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">RECEIVER NAME </td>               
                                            <td colspan="4" class="test">
                                                <input class="form-control" placeholder="Reciver Name" type="text" name="receiver_name">
                                            </td>
                                            <td colspan="2">COMPANY NAME</td>
                                            <td colspan="3" class="test">
                                                <input class="form-control" placeholder="Enter Company Name" type="text" name="receiver_company">
                                            </td>
                                            <td colspan="2">AMOUNT</td>
                                            <td colspan="2" class="test">
                                                <input class="form-control" type="text" placeholder="Amount In RS" id="field1" name="amount">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">CELL# </td>               
                                            <td colspan="5" class="test">
                                                <input class="form-control" placeholder="Contact Number" type="text" name="receiver_cell">
                                            </td>
                                            <td>LINE #</td>
                                            <td colspan="3" class="test">
                                                <input class="form-control" placeholder="Enter Line#" type="text" name="receiver_line">
                                            </td>
                                            <td colspan="2">GST%</td>
                                            <td colspan="2" class="test">
                                                <input class="form-control" placeholder="Enter GST%" type="text" id="field2" name="gst">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">ADDRESS</td>               
                                            <td colspan="9" class="test">
                                                <input class="form-control" placeholder="Enter Address" type="text" name="receiver_address">
                                            </td>
                                            <td colspan="2">DISCOUNT</td>
                                            <td colspan="2" class="test"><input class="form-control" id="field3" placeholder="Discounted Price In RS" type="text" name="discount"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="12" class="test"></td>               
                                            <td colspan="2">TOTAL</td>
                                            <td colspan="2" class="test">
                                                <input class="form-control" placeholder="TOTAL AMOUNT" id="field4" type="text" name="total" readonly>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="8" class="test"></td>               
                                            <td colspan="2">POSTAL CODE</td>
                                            <td colspan="2" class="test">
                                                <input class="form-control" placeholder="Reciver POSTAL" type="text" name="receiver_postal">
                                            </td>
                                            <td colspan="4" rowspan="6" width="1px">"i confirm and affirm that i have understood and agree on all the rates and terms and conditions should hereinafter and that all details given here in are true and correct. This execution of this consignment note is prima facia evidence of the conclusions of contract between shipper & DSL"</td>
                                        </tr>
                                        <tr>
                                            <td colspan="8"><strong>COMMODITY DESCRIPTION</strong></td>               
                                            <td colspan="2">DOX / NON DOX </td>
                                            <td colspan="2">INVOICE</td>              
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="test">
                                                <input class="form-control" placeholder="Product Name" type="text" name="name[]">
                                            </td>               
                                            <td class="test">
                                                <input class="form-control" placeholder="Quantity" type="text" name="quantity[]">
                                            </td>
                                            <td colspan="3" class="test">
                                                <input class="form-control"  id="c1" placeholder="Product Name" type="text" name="name[]">
                                            </td>
                                            <td class="test">
                                                <input class="form-control" id="c2" placeholder="Quantity" type="text" name="quantity[]">
                                            </td>
                                            <td colspan="2" class="test">
                                                @foreach($dutiable as $value)
                                                    <input type="radio" value="{{ $value->id }}" name="dutiable">{{ $value->name }}
                                                @endforeach
                                            </td>
                                            <td colspan="2"><input class="form-control" placeholder="INVOICE" type="text" name="insurance"></td>               

                                        </tr>
                                        <tr>
                                            <td colspan="3" class="test">
                                                <input class="form-control" id="c3" placeholder="Product Name" type="text" name="name[]">
                                            </td>               
                                            <td class="test">
                                                <input class="form-control" id="c4" placeholder="Quantity" type="text" name="quantity[]">
                                            </td>
                                            <td colspan="3" class="test">
                                                <input class="form-control" id="c5" placeholder="Product Name" type="text" name="name[]">
                                            </td>
                                            <td class="test">
                                                <input class="form-control" id="c6" placeholder="Quantity" type="text" name="quantity[]">
                                            </td>
                                            <td colspan="2">TOTAL CONTENTS </td>
                                            <td colspan="2">VALUE $</td>               
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="test">
                                                <input class="form-control" id="c7" placeholder="Product Name" type="text" name="name[]">
                                            </td>               
                                            <td class="test">
                                                <input class="form-control" id="c8" placeholder="Quantity" type="text" name="quantity[]">
                                            </td>
                                            <td colspan="3" class="test">
                                                <input class="form-control" id="c9" placeholder="Product Name" type="text" name="name[]">
                                            </td>
                                            <td class="test">
                                                <input class="form-control" id="c10" placeholder="Quantity" type="text" name="quantity[]">
                                            </td>
                                            <td colspan="2">
                                                <input class="form-control" placeholder="Total Contents" type="text" name="contents">
                                            </td>
                                            <td colspan="2" class="test">
                                                <input class="form-control" placeholder="VALUE" type="text" name="value">
                                            </td>              
                                        </tr>
                                        <tr>
                                            <td colspan="10" width="1px" class="leftside">OFFICE: SHOP 46-A BC-5-6 1ST FLOOR, SASI ARCADE, BLOCK-7 CLIFTON KARACHI- 75600</td>
                                            <td class="test"></td>               
                                            <td class="test"></td>               
                                        </tr>
                                        <tr>
                                            <td colspan="7" class="leftside">EMAIL : dailyswipelogistics@gmail.com</td> 
                                            <td colspan="4" class="leftside">TEL: 021-35879946, CELL:03122699902</td>
                                            <td class="test"></td>              
                                            <td colspan="4"><strong>SHIPPER'S SIGNATURE</strong></td>               
                                        </tr>
                                    </table>
                                    <div>
                                        <p class="tac">TERMS & CONDITIONS <span style="margin-left: 35px; ">Shipment Via DSL Courier For Documents/Parcels Are Subject To The Following Terms & Conditions</span></p> 
                                        <ul class="ultac">
                                          <li> DSL courier reserves the rights to inspect the goods to insured that they are capable of carriage to the countries of destination.</li>
                                          <li> Any Consignments note if not Insured through DSL Courier Service by the Shipper it will be treated ''On Shipper's Risk''</li>
                                          <li> Any Complained by the shipper should be notified within 24 hours after delivery at destination iin written</li>
                                          <li> Rates are excusive of any value added tax,duties at destination</li>
                                          <li> Shipper is liable to provide complete packing list with values of goods</li>
                                      </ul>
                                    </div>
                                        <div class="modal-footer">
                                            <div class="form-actions">
                                                <div class="row">
                                                    <div class="col-md-9">
                                                        <div class="row">
                                                            <div class="col-md-offset-3 col-md-9">
                                                                <button type="submit" class="btn btn-success addproduct1">Submit</button>
                                                                <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6"> </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </form>    
                            </div>
                            
                        </div>
                    </div>
                </div>
                </div>
            <!--end::add domestic Modal-->

            <!--begin::add international order Modal-->
                <div class="modal fade bd-example-modal-lg" id="ordermodal1" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-lg" style="width:1250px;">
                <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">
                                <legend>International Booking</legend>
                                </h5>
                            </div>
                            <div class="modal-body">
                                <form id="createorder1"  class="form-horizontal">
                                    {{ csrf_field() }}
                                    <table>
                                        <tr>
                                            <td colspan="4" rowspan="4"  class="test"><img height="100" src="logo2.jpg"></td>               
                                            <td colspan="5" rowspan="4" ><img height="100" src="bar.png" class="imgbar"></td>
                                            <td colspan="3">DSL CLIENT A/C # </td>
                                            <td>DATE</td>
                                            <td colspan="3">
                                                <strong><u>{{ \Carbon\Carbon::now()->format('l d-M-Y') }}</u></strong>
                                                <input type="hidden" value="{{ \Carbon\Carbon::now()->format('Y-m-d') }}" name="date">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="test"><input class="form-control" type="text" placeholder="Enter A/C No" name="account_no"></td>
                                            <td colspan="4"><strong>SHIPMENTS DETAIL'S </strong></td>
                                        </tr>
                                        <tr>
                                            <td colspan="3">TRACKING VIA </td>
                                            <td colspan="2">ORIGIN </td>
                                            <td colspan="2">DESTINATION</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="test"><input class="form-control"  type="text" placeholder="Enter REF No" name="ref_no"></td>
                                            <td colspan="2">
                                                <input class="form-control" type="text" name="origin" value="PK" readonly>
                                            </td>
                                            <td colspan="2" class="test">
                                                <select class="form-control"  name="destination">
                                                    <option disabled selected value>Select Destination</option>
                                                    @foreach($countries as $country)
                                                        <option value="{{ $country->id }}">{{ $country->name }}</option>
                                                    @endforeach
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="12" class="leftside"><strong>FROM DETAIL'S</strong></td>               
                                            <td colspan="2">WEIGHT (KG)</td>
                                            <td colspan="2">WEIGHT (DIM)</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">SENDER NAME</td>               
                                            <td colspan="4" class="test">
                                                <input class="form-control"  type="text" placeholder="Enter Sender Name" name="sender_name">
                                            </td>
                                            <td colspan="2">COMPANY NAME</td>
                                            <td colspan="3" class="test">
                                                <input class="form-control"  type="text" placeholder="Enter Company Name" name="sender_company">
                                            </td>
                                            <td colspan="2" class="test">
                                                <input class="form-control"  type="text" placeholder="Weight in KG" name="weight_kg">
                                            </td>
                                            <td colspan="2" class="test">
                                                <input class="form-control"  type="text" placeholder="Weight in Dimension" name="weight_dim">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">CELL #</td>               
                                            <td colspan="5" class="test">
                                                <input class="form-control"  type="text" placeholder="Enter #" name="sender_cell">
                                            </td>
                                            <td>LINE #</td>
                                            <td colspan="3" class="test">
                                                <input class="form-control"  type="text" placeholder="Enter LINE#" name="sender_line">
                                            </td>
                                            <td colspan="2">PIECES</td>
                                            <td colspan="2">PACKAGE</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">ADDRESS</td>               
                                            <td colspan="9" class="test">
                                                <input class="form-control"  type="text" name="sender_address" placeholder="Enter Address">
                                            </td>
                                            <td colspan="2" class="test"><input placeholder="No Of Pieces" class="form-control" type="text" name="pieces"></td>
                                            <td colspan="2">
                                                <input class="form-control" type="text" name="package_id" value="MEGA" readonly>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="12" class="test"></td>               
                                            <td colspan="2">SERVICE TYPE </td>
                                            <td colspan="2">PAYMENT</td>
                                        </tr>
                                        <tr>
                                            <td colspan="8" class="test"></td>               
                                            <td colspan="2">POSTAL CODE</td>
                                            <td colspan="2" class="test">
                                                <input class="form-control" placeholder="Enter POSTAL Code" type="text" name="sender_postal">
                                            </td>
                                            <td colspan="2">
                                                <input class="form-control" type="text" name="service_type" value="INTL. Priority" readonly>
                                            </td>
                                            <td colspan="2">
                                                <select class="form-control" name="payment_id">
                                                    <option disabled selected value>Select PAYMENT Type</option>
                                                    @foreach($payment as $service)
                                                        <option value="{{ $service->id }}">{{ $service->name }}</option>
                                                    @endforeach
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="12" class="leftside"><strong>TO DETAIL'S</strong></td>               
                                            <td colspan="2">CHARGES </td>
                                            <td colspan="2">PAK RUPEES</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">RECEIVER NAME </td>               
                                            <td colspan="4" class="test">
                                                <input class="form-control" placeholder="Reciver Name" type="text" name="receiver_name">
                                            </td>
                                            <td colspan="2">COMPANY NAME</td>
                                            <td colspan="3" class="test">
                                                <input class="form-control" placeholder="Enter Company Name" type="text" name="receiver_company">
                                            </td>
                                            <td colspan="2">AMOUNT</td>
                                            <td colspan="2" class="test">
                                                <input class="form-control" type="text" placeholder="Amount In RS" id="field1a" name="amount">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">CELL# </td>               
                                            <td colspan="5" class="test">
                                                <input class="form-control" placeholder="Contact Number" type="text" name="receiver_cell">
                                            </td>
                                            <td>LINE #</td>
                                            <td colspan="3" class="test">
                                                <input class="form-control" placeholder="Enter Line#" type="text" name="receiver_line">
                                            </td>
                                            <td colspan="2">GST%</td>
                                            <td colspan="2" class="test">
                                                <input class="form-control" placeholder="Enter GST%" type="text" id="field2a" name="gst">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">ADDRESS</td>               
                                            <td colspan="9" class="test">
                                                <input class="form-control" placeholder="Enter Address" type="text" name="receiver_address">
                                            </td>
                                            <td colspan="2">DISCOUNT</td>
                                            <td colspan="2" class="test"><input class="form-control" id="field3a" placeholder="Discounted Price In RS" type="text" name="discount"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="12" class="test"></td>               
                                            <td colspan="2">TOTAL</td>
                                            <td colspan="2" class="test">
                                                <input class="form-control" placeholder="TOTAL AMOUNT" id="field4a" type="text" name="total" readonly>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="8" class="test"></td>               
                                            <td colspan="2">POSTAL CODE</td>
                                            <td colspan="2" class="test">
                                                <input class="form-control" placeholder="Reciver POSTAL" type="text" name="receiver_postal">
                                            </td>
                                            <td colspan="4" rowspan="6" width="1px">"i confirm and affirm that i have understood and agree on all the rates and terms and conditions should hereinafter and that all details given here in are true and correct. This execution of this consignment note is prima facia evidence of the conclusions of contract between shipper & DSL"</td>
                                        </tr>
                                        <tr>
                                            <td colspan="8"><strong>COMMODITY DESCRIPTION</strong></td>               
                                            <td colspan="2">DOX / NON DOX </td>
                                            <td colspan="2">INVOICE</td>              
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="test">
                                                <input class="form-control" placeholder="Product Name" type="text" name="name[]">
                                            </td>               
                                            <td class="test">
                                                <input class="form-control" placeholder="Quantity" type="text" name="quantity[]">
                                            </td>
                                            <td colspan="3" class="test">
                                                <input class="form-control" id="e1" placeholder="Product Name" type="text" name="name[]">
                                            </td>
                                            <td class="test">
                                                <input class="form-control" id="e2" placeholder="Quantity" type="text" name="quantity[]">
                                            </td>
                                            <td colspan="2" class="test">
                                                @foreach($dutiable as $value)
                                                    <input type="radio" value="{{ $value->id }}" name="dutiable">{{ $value->name }}
                                                @endforeach
                                            </td>
                                            <td colspan="2"><input class="form-control" placeholder="INVOICE" type="text" name="insurance"></td>               

                                        </tr>
                                        <tr>
                                            <td colspan="3" class="test">
                                                <input class="form-control" id="e3" placeholder="Product Name" type="text" name="name[]">
                                            </td>               
                                            <td class="test">
                                                <input class="form-control" id="e4" placeholder="Quantity" type="text" name="quantity[]">
                                            </td>
                                            <td colspan="3" class="test">
                                                <input class="form-control" id="e5" placeholder="Product Name" type="text" name="name[]">
                                            </td>
                                            <td class="test">
                                                <input class="form-control" id="e6" placeholder="Quantity" type="text" name="quantity[]">
                                            </td>
                                            <td colspan="2">TOTAL CONTENTS </td>
                                            <td colspan="2">VALUE $</td>               
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="test">
                                                <input class="form-control" id="e7" placeholder="Product Name" type="text" name="name[]">
                                            </td>               
                                            <td class="test">
                                                <input class="form-control" id="e8" placeholder="Quantity" type="text" name="quantity[]">
                                            </td>
                                            <td colspan="3" class="test">
                                                <input class="form-control" id="e9" placeholder="Product Name" type="text" name="name[]">
                                            </td>
                                            <td class="test">
                                                <input class="form-control" id="e10" placeholder="Quantity" type="text" name="quantity[]">
                                            </td>
                                            <td colspan="2">
                                                <input class="form-control" placeholder="Total Contents" type="text" name="contents">
                                            </td>
                                            <td colspan="2" class="test">
                                                <input class="form-control" placeholder="VALUE" type="text" name="value">
                                            </td>              
                                        </tr>
                                        <tr>
                                            <td colspan="10" width="1px" class="leftside">OFFICE: SHOP 46-A BC-5-6 1ST FLOOR, SASI ARCADE, BLOCK-7 CLIFTON KARACHI- 75600</td>
                                            <td class="test"></td>               
                                            <td class="test"></td>               
                                        </tr>
                                        <tr>
                                            <td colspan="7" class="leftside">EMAIL : dailyswipelogistics@gmail.com</td> 
                                            <td colspan="4" class="leftside">TEL: 021-35879946, CELL:03122699902</td>
                                            <td class="test"></td>              
                                            <td colspan="4"><strong>SHIPPER'S SIGNATURE</strong></td>               
                                        </tr>
                                    </table>
                                    <div>
                                        <p class="tac">TERMS & CONDITIONS <span style="margin-left: 35px; ">Shipment Via DSL Courier For Documents/Parcels Are Subject To The Following Terms & Conditions</span></p> 
                                        <ul class="ultac">
                                          <li> DSL courier reserves the rights to inspect the goods to insured that they are capable of carriage to the countries of destination.</li>
                                          <li> Any Consignments note if not Insured through DSL Courier Service by the Shipper it will be treated ''On Shipper's Risk''</li>
                                          <li> Any Complained by the shipper should be notified within 24 hours after delivery at destination iin written</li>
                                          <li> Rates are excusive of any value added tax,duties at destination</li>
                                          <li> Shipper is liable to provide complete packing list with values of goods</li>
                                      </ul>
                                    </div>
                                        <div class="modal-footer">
                                            <div class="form-actions">
                                                <div class="row">
                                                    <div class="col-md-9">
                                                        <div class="row">
                                                            <div class="col-md-offset-3 col-md-9">
                                                                <button type="submit" class="btn btn-success addproduct1">Submit</button>
                                                                <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6"> </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </form>    
                            </div>
                            
                        </div>
                    </div>
                </div>
                </div>
            <!--end::add international Modal-->

            <!--begin::add product Modal-->
                <div class="modal fade" id="#" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">
                                Add Product To Order
                                </h5>
                            </div>
                            <div class="modal-body">

                                <form id="#" class="form-horizontal" method="POST" style="padding: 20px;" enctype="multipart/form-data">


                                    {{ csrf_field() }}
                                    <div class="form-body">
                                            <div class="col-md-9">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-4">
                                                        Order Id
                                                    </label>
                                                    <div class="col-md-8">
                                                        <input type="text" class="form-control" name="order_id" id="order_id" required readonly>
                                                    </div>
                                                </div>
                                            </div> 
                                            <input type="hidden" name="status" value="product">
                                    </div>
                                <div class="modal-footer">
                                    <div class="form-actions">
                                        <div class="row">
                                            <div class="col-md-9">
                                                <div class="row">
                                                    <div class="col-md-offset-4 col-md-9">
                                                        <button type="submit" class="btn green addproduct1">Submit</button>
                                                        <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6"> </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            <!--end::Add Modal-->

            <!--begin::show Modal-->
                        <div class="modal fade" id="showmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">
                                            Added Products
                                        </h5>
                                    </div>
                                    <div class="modal-body">
                                        <table class="table table-scrollable">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Quantity</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody id="pbody">
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="modal-footer">

                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-offset-3 col-md-9">
                                                            {{-- <button type="submit" class="btn green addproduct1">Submit</button> --}}
                                                            <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6"> </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
            <!--end::Show modal-->

            <!--begin:: proceed Modal -->
                <div class="modal fade" id="proceedmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Proceed To Next</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <center>
                            All Product Added To The Order?
                            <h3>Once Proceed Cannot Be Revert</h3>
                        </center>
                      </div>
                      <div class="modal-footer">
                        <form id="proceedform">
                            {{ csrf_field() }}
                            <input type="hidden" name="id" id="order_id2">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success">Proceed</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
            <!--end:: proceed Modal -->

            <!--begin:: Delete product modal -->
                <div class="modal fade" id="deleteproductmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Remove Product From Order</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <center>
                            Do You Want To Remove Product From Order?
                            <h3>Once Proceed Cannot Be Revert</h3>
                        </center>
                      </div>
                      <div class="modal-footer">
                        <form method="post" id="productdelete">
                            {{ csrf_field() }}
                            <input type="hidden" name="order_id"   id="o_id">
                            <input type="hidden" name="product_id" id="p_id">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success"   {{-- data-dismiss="modal" --}}>Proceed</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
            <!--end:: delete product Modal -->


            <!--begin::show product detail Modal-->
                        <div class="modal fade" id="detailmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">
                                            Added Products
                                        </h5>
                                    </div>
                                    <div class="modal-body">
                                        <table class="table table-scrollable">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Length</th>
                                                    <th>Width</th>
                                                    <th>Height</th>
                                                    <th>Dimensional Weight</th>
                                                    <th>Quantity</th>
                                                    <th>Amount/Piece</th>
                                                </tr>
                                            </thead>
                                            <tbody id="pdbody">
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="modal-footer">

                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-offset-3 col-md-9">
                                                            {{-- <button type="submit" class="btn green addproduct1">Submit</button> --}}
                                                            <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6"> </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
            <!--end::Show product detail modal-->


            <!--begin:: Delete order modal -->
                <div class="modal fade" id="deleteorder" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Delete The Current Order</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <center>
                            <h2>Do You Want To Delete This Order?</h2>
                            <h3>Once Proceed Cannot Be Revert</h3>
                        </center>
                      </div>
                      <div class="modal-footer">
                        <form method="get" id="orderdelete">
                            {{ csrf_field() }}
                            <input type="hidden" name="order_id" id="o_id2">
                            <input type="hidden" id="mytyped">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-danger"   {{-- data-dismiss="modal" --}}>Delete</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
            <!--end:: delete order Modal -->

            <!--begin::update order Modal-->
                <div class="modal fade bd-example-modal-lg" id="updateorder" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">
                                Modify Order
                            </h5>
                        </div>
                        <div class="modal-body">

                            <form id="orderupdate" class="form-horizontal" style="padding: 20px;" enctype="multipart/form-data">
                                {{ csrf_field() }}
                                <div class="form-body">

                                    <div class="col-md-9">
                                        <div class="form-group ">
                                            <label class="control-label col-md-4">Order Id </label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" name="order_id" id="o_id3" required readonly>
                                            </div>
                                        </div>
                                    </div>  

                                    <table>
                                        <tr>
                                            <td colspan="4" rowspan="4"  class="test"><img height="100" src="logo2.jpg"></td>               
                                            <td colspan="5" rowspan="4" ><img height="100" src="bar.png" class="imgbar"></td>
                                            <td colspan="3">DSL CLIENT A/C # </td>
                                            <td>DATE</td>
                                            <td colspan="3">01-Dec-18   </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3"  class="test"></td>
                                            <td colspan="4">SHIPMENTS DETAIL'S </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3">TRACKING VIA </td>
                                            <td colspan="2">ORIGIN </td>
                                            <td colspan="2">DESTINATION</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="test"></td>
                                            <td colspan="2">PK </td>
                                            <td colspan="2" class="test"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="12" class="leftside">FROM DETAIL'S</td>               
                                            <td colspan="2">WEIGHT (KG)</td>
                                            <td colspan="2">WEIGHT (DIM)</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">SENDER NAME</td>               
                                            <td colspan="4" class="test"></td>
                                            <td colspan="2">COMPANY NAME</td>
                                            <td colspan="3" class="test"></td>
                                            <td colspan="2" class="test"></td>
                                            <td colspan="2" class="test"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">CELL #</td>               
                                            <td colspan="5" class="test"></td>
                                            <td>LINE #</td>
                                            <td colspan="3" class="test"></td>
                                            <td colspan="2">PIECES</td>
                                            <td colspan="2">PACKAGE</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">ADDRESS</td>               
                                            <td colspan="9" class="test"></td>
                                            <td colspan="2" class="test"></td>
                                            <td colspan="2">MEGA</td>
                                        </tr>
                                        <tr>
                                            <td colspan="12" class="test"></td>               
                                            <td colspan="2">SERVICE TYPE </td>
                                            <td colspan="2">PAYMENT</td>
                                        </tr>
                                        <tr>
                                            <td colspan="8" class="test"></td>               
                                            <td colspan="2">POSTAL CODE</td>
                                            <td colspan="2" class="test"></td>
                                            <td colspan="2">INTL. PRIORITY </td>
                                            <td colspan="2">CASH</td>
                                        </tr>
                                        <tr>
                                            <td colspan="12" class="leftside">TO DETAIL'S</td>               
                                            <td colspan="2">CHARGES </td>
                                            <td colspan="2">PAK RUPEES</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">RECEIVER NAME </td>               
                                            <td colspan="4" class="test"></td>
                                            <td colspan="2">COMPANY NAME</td>
                                            <td colspan="3" class="test"></td>
                                            <td colspan="2">AMOUNT</td>
                                            <td colspan="2" class="test"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">CELL # </td>               
                                            <td colspan="5" class="test"></td>
                                            <td>LINE #</td>
                                            <td colspan="3" class="test"></td>
                                            <td colspan="2">GST%</td>
                                            <td colspan="2" class="test"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="rightside">ADDRESS</td>               
                                            <td colspan="9" class="test"></td>
                                            <td colspan="2">DISCOUNT</td>
                                            <td colspan="2" class="test"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="12" class="test"></td>               
                                            <td colspan="2">TOTAL</td>
                                            <td colspan="2" class="test"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="8" class="test"></td>               
                                            <td colspan="2">POSTAL CODE</td>
                                            <td colspan="2" class="test"></td>
                                            <td colspan="4" rowspan="6" width="1px">"i confirm and affirm that i have understood and agree on all the rates and terms and conditions should hereinafter and that all details given here in are true and correct. This execution of this consignment note is prima facia evidence of the conclusions of contract between shipper & DSL"</td>
                                        </tr>
                                        <tr>
                                            <td colspan="8">COMMODITY DESCRIPTION</td>               
                                            <td colspan="2">DOX / NON DOX </td>
                                            <td colspan="2">INVOICE</td>              
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="test"></td>               
                                            <td class="test"></td>
                                            <td colspan="3" class="test"></td>
                                            <td class="test"></td>
                                            <td colspan="2" class="test"></td>
                                            <td colspan="2">-</td>               

                                        </tr>
                                        <tr>
                                            <td colspan="3" class="test"></td>               
                                            <td class="test"></td>
                                            <td colspan="3" class="test"></td>
                                            <td class="test"></td>
                                            <td colspan="2">TOTAL CONTENTS </td>
                                            <td colspan="2">VALUE $</td>               
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="test"></td>               
                                            <td class="test"></td>
                                            <td colspan="3" class="test"></td>
                                            <td class="test"></td>
                                            <td colspan="2">-</td>
                                            <td colspan="2" class="test"></td>              
                                        </tr>
                                        <tr>
                                            <td colspan="10" width="1px" class="leftside">OFFICE: SHOP 46-A BC-5-6 1ST FLOOR, SASI ARCADE, BLOCK-7 CLIFTON KARACHI- 75600</td>
                                            <td class="test"></td>               
                                            <td class="test"></td>               
                                        </tr>
                                        <tr>
                                            <td colspan="7" class="leftside">EMAIL : dailyswipelogistics@gmail.com</td> 
                                            <td colspan="4" class="leftside">TEL: 021-35879946, CELL:03122699902</td>
                                            <td class="test"></td>              
                                            <td colspan="4">SHIPPER'S SIGNATURE</td>               
                                        </tr>
                                    </table>
                                    <div>
                                        <p class="tac">TERMS & CONDITIONS <span style="margin-left: 35px; ">Shipment Via DSL Courier For Documents/Parcels Are Subject To The Following Terms & Conditions</span></p> 
                                        <ul class="ultac">
                                          <li> DSL courier reserves the rights to inspect the goods to insured that they are capable of carriage to the countries of destination.</li>
                                          <li> Any Consignments note if not Insured through DSL Courier Service by the Shipper it will be treated ''On Shipper's Risk''</li>
                                          <li> Any Complained by the shipper should be notified within 24 hours after delivery at destination iin written</li>
                                          <li> Rates are excusive of any value added tax,duties at destination</li>
                                          <li> Shipper is liable to provide complete packing list with values of goods</li>
                                      </ul>
                                    </div>                          
                                            <input type="hidden" name="status" value="product" placeholder="status of order">
                                            <input type="hidden" id="mytypeu">
                                        </div>
                                        <div class="modal-footer">

                                            <div class="form-actions">
                                                <div class="row">
                                                    <div class="col-md-9">
                                                        <div class="row">
                                                            <div class="col-md-offset-3 col-md-9">
                                                                <button type="submit" class="btn green addproduct1">Submit</button>
                                                                <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6"> </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                    <!-- END FORM-->

                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            <!--end::update order Modal-->

            <!--begin::add city Modal-->
                <div class="modal fade" id="citymodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">
                                    Add New City
                                </h5>
                            </div>
                            <div class="modal-body">
                                <form id="city" class="form-horizontal" method="POST" style="padding: 20px;" enctype="multipart/form-data">
                                    {{ csrf_field() }}
                                    <div class="form-body">
                                        <div class="col-md-9">
                                            <div class="form-group ">
                                                <label class="control-label col-md-4">
                                                    City Name
                                                </label>
                                                <div class="col-md-8">
                                                    <input type="text" placeholder="City Name" class="form-control" name="name" id="name" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-9">
                                            <div class="form-group ">
                                                <label class="control-label col-md-4">
                                                    City Acronym
                                                </label>
                                                <div class="col-md-8">
                                                    <input type="text" minlength="3" maxlength="4" placeholder="3 - 4 Letter Short Name" class="form-control" name="acr" id="acr" required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">

                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-offset-3 col-md-9">
                                                            <button type="submit" class="btn green addproduct1">Submit</button>
                                                            <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6"> </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <!--end::Add city Modal-->






@endsection


 @section('script')
    
        <script type="text/javascript">
        $(document).ready(function()
        {
            $('input').prop('required',true);
            $('select').prop('required',true);
            for (var i=1 ; i < 11; i++) 
            {
                $('#e'+i).prop('required',false);
                $('#c'+i).prop('required',false);
            }
            $(document).on('click','.productorders',function(event)
            {   
                event.preventDefault();
                 $('#myTable').DataTable().destroy();
                $('#myTable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "ajax": "{{ route('productorders') }}",
                    "columns":[
                        { "data": "ordercode" },
                        { "data": "date" },
                        { "data": "sender_name" },
                        { "data": "name1"},
                        { "data": "name2"},
                        { "data": "stname"},
                        { "data": "activity"},
                        { "data": "status"},
                        // { "data": "action"},
                    ]
                });
            });
            $(document).on('click','.pendingorders',function(event)
            {   
                event.preventDefault();
                 $('#myTable').DataTable().destroy();
                $('#myTable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "ajax": "{{ route('pendingorders') }}",
                    "columns":[
                        { "data": "ordercode" },
                        { "data": "date" },
                        { "data": "sender_name" },
                        { "data": "name1"},
                        { "data": "name2"},
                        { "data": "stname"},
                        { "data": "activity"},
                        { "data": "status"},
                        // { "data": "action"},
                    ]
                });
            });
            // 
            // $('.productorders').click();
        });

        jQuery(document).ready(function()
        {
            var i =1;
            $(document).on('click', '.replica', function()
            {
                i++;
                var html = '';
                html+= '<div class=" row' +i+ ' col-md-12" >';
                    html+= '<label class="control-label col-md-1">Name</label><div class="col-md-3"><input type="text" class="form-control" name="name[]" id="name" required></div>';
                    html+= '<label class="control-label col-md-1">Quantity</label><div class="col-md-3"><input type="number" class="form-control" name="quantity[]" id="name" required></div>';
                    html+= '<div class="col-md-2"><button type="button" class="btn-xs btn-success replica">Add More</button></div>';
                    html+= '<div class="col-md-2"><button id="' +i+ '" type="button" class="btn-xs btn-danger btn_remove">X</button></div>';
                html+= '</div>';
                $('#productreplica').append(html);
            });
            $(document).on('click', '.btn_remove', function()
            {
                console.log('Hello');
                var id = $(this).attr('id');
                console.log(id);
                $('.row'+id).remove();
            })
        });

        $(document).ready(function()
        {
            var gstamount = 0;
            $(document).on('change paste keyup keypress keydown','#field1', function()
            {
                var a = $(this).val();
                var b = gstamount;
                var c = $('#field3').val();

                var d = ((+a)+(+gstamount))-(+c);
                $('#field4').val(d);
            });

            // GST Calculation
            $(document).on('change paste keyup keypress keydown','#field2', function()
            {
                var a = $(this).val();
                var b = $('#field1').val();
                var c = $('#field3').val();

                gstamount = ((+a)*(+b))/100;
                var d  = ((+b) + (+gstamount)) - (+c); 
                $('#field4').val(d);
            });
            $(document).on('change paste keyup keypress keydown','#field3', function()
            {
                var a = $(this).val();
                var b = $('#field1').val();
                var c = gstamount;

                var d  = ((+b) + (+gstamount)) - (+a);
                $('#field4').val(d);
            });
        });

        $(document).ready(function()
        {
            var gstamounts = 0;
            $(document).on('change paste keyup keypress keydown','#field1a', function()
            {
                var a = $(this).val();
                var b = gstamounts;
                var c = $('#field3a').val();

                var d = ((+a)+(+gstamounts))-(+c);
                $('#field4a').val(d);
            });

            // GST Calculation
            $(document).on('change paste keyup keypress keydown','#field2a', function()
            {
                var a = $(this).val();
                var b = $('#field1a').val();
                var c = $('#field3a').val();

                gstamounts = ((+a)*(+b))/100;
                var d  = ((+b) + (+gstamounts)) - (+c); 
                $('#field4a').val(d);
            });
            $(document).on('change paste keyup keypress keydown','#field3a', function()
            {
                var a = $(this).val();
                var b = $('#field1a').val();
                var c = gstamounts;

                var d  = ((+b) + (+gstamounts)) - (+a);
                $('#field4a').val(d);
            });
        });

        $(document).ready(function()
        {
            
            $("#myInput").on("keyup", function()
            {
                console.log('Search');
                var value = $(this).val().toLowerCase();
                $("#myTable tr").filter(function()
                {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });

            $(document).on('click','.showproduct',function(){
                var key = $(this).attr('id');
                console.log('Id'+key);

                var id = $(this).data('id');
                console.log('ID: '+id);
                $.ajax({
                    'type': 'POST',
                    'url' : "{{ route('showproduct') }}",
                    'data': {
                        'id':id,
                        '_token':$('input[name=_token]').val()
                    },
                    success:function(data)
                    {

                        console.log('Data: \n'+data);
                        data = JSON.parse(data,true);
                        console.log('Data: \n'+data);
                        var html  = '';
                        $('#pbody').html(html);
                        for(var i=0; i<data.length; i++)
                        {
                            console.log('i')
                            console.log(i);
                            html+= '<tr>';
                            html+= '<td><button class="btn-xs btn-primary pname" data-p_id="'+ data[i]['p_id'] +'" </button>'+data[i]['name']+'</td>';
                            html+= '<td>'+data[i]['quantity']+'</td>';
                            // html+= '<td>'+data[i]['amount_pc']+'</td>';
                            // html+= '<td><button class="btn-xs btn-warning updatebtn" data-id="'+ id + '" data-p_id="'+ data[i]['p_id'] +'"> Update </button></td>';
                            html+= '<td><button class="btn-xs btn-danger removebtn" data-id="'+  id + '" data-p_id="'+ data[i]['p_id'] +'"> Remove</button></td>';
                            html+= '</tr>';
                        }
                        $('#pbody').append(html);
                        $('#useful').val(key);
                    },
                    error:function()
                    {
                        toastr.error('Server Down!', 'Error Alert', {timeOut: 5000});
                    }
                });
            });

            $(document).on('click','.removebtn',function()
            {
                console.log('remove btn');
                $('#showmodal').modal('toggle');
                $('#deleteproductmodal').modal('show');
                $('#o_id').val($(this).data('id'));
                $('#p_id').val($(this).data('p_id'));
                                
            });
            $(document).on('click','.pname',function()
            {
                console.log('name btn');
                // $('#showmodal').modal('toggle');
                $('#detailmodal').modal('show');
                var p_id = $(this).data('p_id');

                $.ajax({
                    url:"{{ route('productdetail') }}",
                    type:"GET",
                    data:{
                        // "_token":$('input[name=_token]'),
                        "id":p_id
                    },
                    success:function(data)
                    {
                        console.log('Data: \n'+ data);
                        data = JSON.parse(data,true);
                        console.log('Data: \n'+ data);
                        var html  = '';
                        $('#pdbody').html(html);
                            // console.log('i:'+i);
                            html+= '<tr>';
                            html+= '<td>' +data[0]['name']+ '</td>';
                            html+= '<td>' +data[0]['length'] +'</td>';
                            html+= '<td>' +data[0]['width']+ '</td>';
                            html+= '<td>' +data[0]['height'] +'</td>';
                            html+= '<td>' +data[0]['dimensional_weight'] +'</td>';
                            html+= '<td>' +data[0]['quantity'] +'</td>';
                            html+= '<td>' +data[0]['amount_pc'] +'</td>';
                            html+= '</tr>';
                            $('#pdbody').append(html);
                    }
                });
            });


            $(document).on('submit','#productdelete',function(event)
            {
                event.preventDefault();
                var butonclk = $('#useful').val();
                var o_id = $('#o_id').val();
                var p_id = $('#p_id').val();
                $.ajax({
                    url: '{{ route('deleteproduct') }}',
                    type: 'POST',
                    data: {
                        _token  :$('input[name=_token]').val(), 
                        o_id    : o_id,
                        p_id    : p_id
                    },
                    success:function(data)
                    {

                        console.log('Data: \n'+data);
                        data = JSON.parse(data,true);
                        console.log('Data: \n'+data);
                        var html  = '';
                        $('#pbody').html(html);
                        console.log('Data Length'+ data.length);
                        if(data.length == 0)
                        {
                            $.ajax({
                                url: '{{ route('changestatuspending') }}',
                                type: 'POST',
                                data: {
                                    _token  :$('input[name=_token]').val(), 
                                    id    : o_id
                                },
                                success:function()
                                {
                                    $("#deleteproductmodal .close").click();
                                    $('.productorders').click();
                                }
                            })
                        }
                        else
                        {
                            for(var i=0; i<data.length; i++)
                            {
                                console.log('i')
                                console.log(i);
                                html+= '<tr>';
                                html+= '<td>'+data[i]['name']+'</td>';
                                html+= '<td>'+data[i]['quantity']+'</td>';
                                html+= '<td>'+data[i]['amount_pc']+'</td>';
                                // html+= '<td><button class="btn-xs btn-warning updatebtn" data-id="'+ id + '" data-p_id="'+ data[i]['p_id'] +'"> Update </button></td>';
                                html+= '<td><button class="btn-xs btn-danger removebtn" data-id="'+  o_id + '" data-p_id="'+ data[i]['p_id'] +'"> Remove</button></td>';
                                html+= '</tr>';
                            }
                            $('#pbody').append(html);
                            toastr.success('Product Remove From Order','Success Alert', {timeOut: 3000});
                            $("#deleteproductmodal .close").click();
                            console.log('butonclk: '+butonclk);
                            $('#'+butonclk).click();
                        }

                    },
                });
            })


            $(document).on('click','.addproductmodal',function()
            {
                $('#order_id').val($(this).data('id'));
            });

            $(document).on('click','.proceedbtn',function()
            {
                console.log($(this).data('id'));
                $('#order_id2').val($(this).data('id'));
            });


            $(document).on('click','.proceed',function()
            {

                   console.log($(this).data('id'));
                   $.ajax
                   ({
                        type:'put',
                        url:'proceedorder',
                        data:{
                            '_token': $('input[name=_token]').val(),
                            'O_id1' :$(this).data('id'),
                        },
                        success: function(reponse)
                        {
                            toastr.success('Successfully Updated !', 'Success Alert', {timeOut: 5000});
                            setTimeout(function(){}, 1000);
                            $('.productorders').click();
                        },
                        error : function(error) 
                        {

                          toastr.error('Error Occurred!', 'Error Alert', {timeOut: 5000});
                        }
                    });
            });

            $(document).on('submit','#product',function(event)
            {
                    event.preventDefault();
                    var formdata = $('#product').serialize();
                    console.log(formdata);
                    console.log($('#order_id').val()); 
                    console.log($('#p_name').val()); 
                    console.log($('#weight').val()); 
                    console.log($('#dimemsion').val()); 

                    $.ajax
                    ({
                        'type':     'POST',
                        'url':      'AddProduct',
                        'data':     formdata,
                        success: function(reponse)
                        {
                            toastr.success('Product Successfully Added !', 'Success Alert', {timeOut: 5000});
                            setTimeout(function(){}, 1000);
                            $('.productorders').click();
                        },
                        error : function(error)
                        {
                            toastr.error('Server Down!', 'Error Alert', {timeOut: 5000});
                        }
                    });
            });

            $(document).on('click','.citymodal',function()
            {
                $('#citymodal').modal('show');
            });

            $(document).on('submit','#city',function(event)
            {
                event.preventDefault();
                var data = $(this).serialize();
                console.log(data);
                $(this).serialize();
                $.ajax({
                    url: "{{ route('addcity') }}",
                    type: "POST",
                    data: {
                        '_token':$('input[name=_token]').val(),
                        'name':$('#name').val(),
                        'acr':$('#acr').val()
                    },
                    success:function(data)
                    {
                        if (data == 'name')
                        {
                            toastr.error('City With Same Name Already Exist','Error Alert');
                        }
                        else if (data == 'acr')
                        {
                            toastr.error('City With Same Acronym Already Exist','Error Alert');
                        }
                        else
                        {
                            console.log(data);
                            toastr.success('New City Added Successfully','Success Alert');
                            $('#city1').append(' <option value="' + data + ' "> ' + $('#name').val() + ' </option> ');
                            $('#city2').append(' <option value="' + data + ' "> ' + $('#name').val() + ' </option> ');
                        }
                        
                    },
                    error:function()
                    {
                        toastr.error('Server Down','Error Alert');
                    }
                });
            });

            $(document).on('click', '.deleteorderbtn', function()
            {
                $('#o_id2').val( $(this).data('id') );
                $('#mytyped').val( $(this).data('mytype') );
            });

            $(document).on('click', '.updateorderbtn', function()
            {
                console.log('order type: '+$(this).data('order_type') )
                $('#o_id3').val( $(this).data('id') );
                $('#city1').val($(this).data('deliverypoint'));
                $('#deliverydate').val($(this).data('deliverydate'));
                $('#city2').val($(this).data('destination'));
                $('#customer_id').val($(this).data('customer_id'));
                $('#ordertype').val($(this).data('order_type'));
                $('#payment_type').val($(this).data('payment_type'));
                $('#mytypeu').val( $(this).data('mytype') );
            });

            $(document).on('submit','#orderdelete',function(event)
            {
                    event.preventDefault();
                    var formdata = $('#orderdelete').serialize();
                    console.log(formdata);
                    console.log($('#o_id2').val()); 
                    var mytype = $('#mytyped').val();
                    console.log('mytype'+ mytype);
                    $.ajax
                    ({
                        'type':     'GET',
                        'url':      '{{ route('deleteorder') }}',
                        'data':     formdata,
                        success: function(reponse)
                        {
                            toastr.success('Order Successfully Deleted !', 'Success Alert', {timeOut: 5000});
                            setTimeout(function(){}, 1000);
                            $('#deleteorder').modal('hide');
                            if (mytype == 0)
                            {
                                $('.productorders').click();
                            }
                            else if (mytype == 1)
                            {
                                $('.productorders').click();
                            }
                            
                        },
                        error : function(error)
                        {
                            toastr.error('Server Down!', 'Error Alert', {timeOut: 5000});
                        }
                    });
            });

            $(document).on('submit','#orderupdate',function(event)
            {
                    event.preventDefault();
                    var formdata = $('#orderupdate').serialize();
                    console.log(formdata);
                    console.log($('#o_id2').val()); 
                    var mytype = $('#mytypeu').val();
                    console.log('mytype'+ mytype);
                    $.ajax
                    ({
                        'type':     'POST',
                        'url':      '{{ route('updateorder') }}',
                        'data':     formdata,
                        success: function(reponse)
                        {
                            toastr.success('Order Successfully Updated !', 'Success Alert', {timeOut: 5000});
                            setTimeout(function(){}, 1000);
                            $('#updateorder').modal('hide');
                            if (mytype == 0)
                            {
                                $('.productorders').click();
                            }
                            else if (mytype == 1)
                            {
                                $('.productorders').click();
                            }
                            
                        },
                        error : function(error)
                        {
                            toastr.error('Server Down!', 'Error Alert', {timeOut: 5000});
                        }
                    });
            });

            $(document).on('submit','#proceedform',function(event)
            {
                    event.preventDefault();
                    var formdata = $('#proceedform').serialize();
                    console.log(formdata);
                    console.log($('#order_id2').val());
                    $.ajax
                    ({
                        'type':     'POST',
                        'url':      '{{ route('proceed') }}',
                        'data':     formdata,
                        success: function(reponse)
                        {
                            toastr.success('Order Successfully Proceeded !', 'Success Alert', {timeOut: 5000});
                            setTimeout(function(){}, 1000);
                            $('#proceedmodal').modal('hide');
                            $('.productorders').click();
                            
                        },
                        error : function(error)
                        {
                            toastr.error('Server Down!', 'Error Alert', {timeOut: 5000});
                        }
                    });
            });

            $(document).on('submit','#createorder',function(event)
            {
                    event.preventDefault();
                    var formdata = $('#createorder').serialize();
                    console.log(formdata); 
                    $.ajax
                    ({
                        'type':     'POST',
                        'url':      '{{url('/addorder')}}',
                        'data':     formdata,
                        success: function(reponse)
                        {
                            toastr.success('Order Successfully Added !', 'Success Alert', {timeOut: 5000});
                            setTimeout(function(){}, 1000);
                            $('#createorder').trigger("reset");
                            // $('#createorder')[0].reset();
                            $('#ordermodal').modal('trigger');
                            $('#ordermodal').modal('hide');
                            $('.productorders').click();
                        },
                        error : function(error)
                        {
                            toastr.error('Server Down!', 'Error Alert', {timeOut: 5000});
                        }
                    });
            });
            $(document).on('submit','#createorder1',function(event)
            {
                    event.preventDefault();
                    var formdata = $('#createorder1').serialize();
                    console.log(formdata); 
                    $.ajax
                    ({
                        'type':     'POST',
                        'url':      '{{url('/addorder1')}}',
                        'data':     formdata,
                        success: function(reponse)
                        {
                            toastr.success('Order Successfully Added !', 'Success Alert', {timeOut: 5000});
                            setTimeout(function(){}, 1000);
                            $('#createorder1').trigger("reset");
                            // $('#createorder1')[0].reset();
                            $('#ordermodal1').modal('trigger');
                            $('#ordermodal1').modal('hide');
                            $('.productorders').click();
                        },
                        error : function(error)
                        {
                            toastr.error('Server Down!', 'Error Alert', {timeOut: 5000});
                        }
                    });
            });
        }); 
        </script>


@endsection
