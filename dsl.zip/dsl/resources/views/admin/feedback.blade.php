@extends('layout.main')
@section('body')


        <div class="portlet-body form">
            <div class="portlet-body" id="items">
                <div class="table-scrollable">
                    <table class="table table-hover table-light" id="myTable">
                        <thead>
                            <tr>
                                <th>User Name</th>
                                <th>Email</th>
                                <th>Subject</th>
                                <th>Message</th>
                            </tr>
                        </thead>
                    </table>
                </div>  
            </div>
        </div>


@endsection


@section('script')
    
    <script type="text/javascript">
        jQuery(document).ready(function() {
            $('#myTable').DataTable().destroy();
            $('#myTable').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": "{{ route('feedbackdata') }}",
                "columns":[
                    { "data": "name" },
                    { "data": "email" },
                    { "data": "subject" },
                    { "data": "message"}
                ]
            });
        });
    </script>       
@endsection
