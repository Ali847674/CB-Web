@extends('layout.main')

@section('body')
  <div class="portlet-body " >

 <form  class="form-horizontal"  method="post" action="{{url('/admincreate1')}}" enctype="multipart/form-data" >




                                                    {{ csrf_field() }}
                                                    <div class="form-body">
                                                        {{-- <h3 class="form-section">AdminRegister</h3> --}}


                                                       <div class="form-group{{$errors->has('name') ? ' has-error' : '' }}">
                                                        <label for="name" class="col-md-4 control-label">admin name</label>

                                                        <div class="col-md-6">
                                                            <input id="name" type="text" class="form-control" name="name" value="{{ old('name') }}" required autofocus>

                                                            @if ($errors->has('name'))
                                                            <span class="help-block">
                                                                <strong>{{ $errors->first('name') }}</strong>
                                                            </span>
                                                            @endif
                                                        </div>
                                                    </div>

                                                      <div class="form-group{{$errors->has('email') ? ' has-error' : '' }}">
                                                        <label for="email" class="col-md-4 control-label">Email</label>

                                                        <div class="col-md-6">
                                                            <input id="email" type="text" class="form-control" name="email" value="{{ old('email') }}" required autofocus>

                                                            @if ($errors->has('email'))
                                                            <span class="help-block">
                                                                <strong>{{ $errors->first('email') }}</strong>
                                                            </span>
                                                            @endif
                                                        </div>
                                                    </div>

                                                         <div class="form-group{{$errors->has('contact') ? ' has-error' : '' }}">
                                                        <label for="name" class="col-md-4 control-label">Contact</label>

                                                        <div class="col-md-6">
                                                            <input id="contact" type="text" class="form-control" name="contact" value="{{ old('name') }}" required autofocus>

                                                            @if ($errors->has('contact'))
                                                            <span class="help-block">
                                                                <strong>{{ $errors->first('contact') }}</strong>
                                                            </span>
                                                            @endif
                                                        </div>
                                                    </div>


                                                    
                                                        <label for="name" class="col-md-4 control-label">admin name</label>

                                                        <div class="col-md-6">
                                                            <input id="image" type="file" class="form-control" name="image"  required autofocus>

                                                           
                                                        </div>
                                                   


                                                      <div class="form-group{{$errors->has('type') ? ' has-error' : '' }}">
                                                        <label for="type" class="col-md-4 control-label">type</label>

                                                        <div class="col-md-6">
                                                            <input id="type" type="text" class="form-control" name="type" value="{{ old('type') }}" required autofocus>

                                                            @if ($errors->has('type'))
                                                            <span class="help-block">
                                                                <strong>{{ $errors->first('type') }}</strong>
                                                            </span>
                                                            @endif
                                                        </div>
                                                    </div>
                                                   
                                                        <div class="form-actions">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="row">
                                                                        <div class="col-md-offset-3 col-md-9">
                                                                            <button type="Submit" class="btn btn-success">Submit</button>
                                                                            <button type="button" class="btn default" >Cancel</button>
                                                                           


                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                >
                                                            </div>
                                                        </div>
                  </div>
                  </form>

                   <form method="get" action="{{url('/showimg')}}">
                     <div class="col-md-offset-3 col-md-9">
                      <button type="submit" class="btn btn-primaryShowimage">Showimage</button>
                  </div>

                  </form>
              </div>



        


                    @endsection



                    @section('script')




                    @endsection