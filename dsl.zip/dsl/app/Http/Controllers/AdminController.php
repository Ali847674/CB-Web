<?php

namespace App\Http\Controllers;

use App\Account;
use App\Admin;
use App\CustOrderdetail;
use App\Customer;
use App\Employee;
use App\Office;
use App\Order;
use Auth;
use Carbon\Carbon;
use DB;
use DataTables;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Session;
use Validator;
class AdminController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function neworder(Request $request)
    {
        $customer = DB::table('customer')->get(['name','id']);
        $cities = DB::table('cities')->orderBy('name','asc')->get(['name','id']);
        return view('admin.neworder',compact('cities','customer'));
    }

    public function addcity(Request $request)
    {
        $temp = strtolower($request->name);
        $cityname = ucfirst($temp);

        $cityacr = strtoupper($request->acr);

        $name = Validator::make($request->all(), [
            'name' => ['required',Rule::unique('cities')]
        ]);

        $acr = Validator::make($request->all(), [
            'acr'  => ['required',Rule::unique('cities')]
        ]);

        
        if ($name->fails())
        {
            return response()->json('name');
        }
        elseif ($acr->fails())
        {
            return response()->json('acr');
        }
        else
        {
            $data = DB::table('cities')->insertGetId([
            'name'=>$cityname,
            'acr'=>$cityacr
            ]);
            return response()->json(encrypt($data));
        }
    }

    public function addorder(Request $request)
    {
        // return $request->all();
        
        #obsolete 
            // $order_id=Order::insertGetId([
            //     'date' => $request->date,
            //     'created_id' => $auth_id,
            //     'customer_id' => $request->customer_id,
            //     'deliverypoint' => $request->input('deliverypoint'),
            //     'deliverydate' =>$request->input('deliverydate'),
            //     'destination' => $request->input('destination'),
            //     'order_status' =>"pending",
            //     'order_type' => $request->input('type'),
            //     'payment_type' => $request->input('payment_type'),
            // ]);
        #end
    
        $auth_id = Auth::user()->id;
        $orderid = Order::insertGetId($request->except(['_token','name','quantity']));
        $type = '';
        if ($request->input('payment_id') == 1) {
            $type = 'CR';
        }
        elseif ($request->input('payment_id') == 2) {
            $type = 'CH';
        }
        $id= str_pad($orderid, 4, '0',STR_PAD_LEFT);
        Order::where('id',$orderid)->update([
            'alpha_id'=>$request->date.'/'.$type.'/'.$id,
            'created_id'=>$auth_id,
            'order_status'=>'product',
            'region'=>'DOMESTIC'
        ]);

        for ($i=0; $i < sizeof($request->name) ; $i++) 
        { 
            if ($request->name[$i] == null)
            {
                continue;
            }
            else
            {
                $p_id = DB::table('products')->insertGetId([
                    'name'=>$request->name[$i],
                    'quantity'=>$request->quantity[$i]
                ]);
                DB::table('cust_orderdetails')->insert([
                    'order_id'=>$orderid,
                    'product_id'=>$p_id,
                ]);
            }
        }
        return response()->json('success');
    }
    public function addorder1(Request $request)
    {
        // return $request->all();
        
        #obsolete 
            // $order_id=Order::insertGetId([
            //     'date' => $request->date,
            //     'created_id' => $auth_id,
            //     'customer_id' => $request->customer_id,
            //     'deliverypoint' => $request->input('deliverypoint'),
            //     'deliverydate' =>$request->input('deliverydate'),
            //     'destination' => $request->input('destination'),
            //     'order_status' =>"pending",
            //     'order_type' => $request->input('type'),
            //     'payment_type' => $request->input('payment_type'),
            // ]);
        #end
    
        $auth_id = Auth::user()->id;
        $orderid = Order::insertGetId($request->except(['_token','name','quantity']));
        $type = '';
        if ($request->input('payment_id') == 1) {
            $type = 'CR';
        }
        elseif ($request->input('payment_id') == 2) {
            $type = 'CH';
        }
        $id= str_pad($orderid, 4, '0',STR_PAD_LEFT);
        Order::where('id',$orderid)->update([
            'alpha_id'=>$request->date.'/'.$type.'/'.$id,
            'created_id'=>$auth_id,
            'order_status'=>'product',
            'region'=>'INTERNATIONAL'
        ]);

        for ($i=0; $i < sizeof($request->name) ; $i++) 
        { 
            if ($request->name[$i] == null)
            {
                continue;
            }
            else
            {
                $p_id = DB::table('products')->insertGetId([
                    'name'=>$request->name[$i],
                    'quantity'=>$request->quantity[$i]
                ]);
                DB::table('cust_orderdetails')->insert([
                    'order_id'=>$orderid,
                    'product_id'=>$p_id,
                ]);
            }
        }
        return response()->json('success');
    }

    public function showorder(Request $request)
    {
        $cities = DB::table('cities')->get(['name','id']);
        $countries = DB::table('countries')->get(['name','id']);
        $services = DB::table('service_types')->get(['name','id']);
        $packages = DB::table('packages')->get(['name','id']);
        $payment = DB::table('payment_types')->get(['name','id']);
        $dutiable = DB::table('dutiable')->get(['name','id']);
        $customer = DB::table('customer')->get(['name','id']);
        return view('admin.showorder',compact('cities','countries','customer','services','packages','payment','dutiable'));
    }
    // domestic orders show
    public function productorders(Request $request)
    {
        $auth_id1 = Auth::user()->id;
        $orders = DB::table('orderdetail')
            ->join('cities as city1','city1.id','orderdetail.origin')
            ->join('cities as city2','city2.id','orderdetail.destination')
            ->join('dutiable','dutiable.id','orderdetail.dutiable')
            ->join('packages','packages.id','orderdetail.package_id')
            ->join('payment_types','payment_types.id','orderdetail.payment_id')
            ->join('service_types','service_types.id','orderdetail.service_type')
            ->select('orderdetail.*','city1.name as name1','city2.name as name2','dutiable.name as dname','packages.name as pname','payment_types.name as ptname','service_types.name as stname')
            ->where('orderdetail.created_id',$auth_id1)
            ->where('orderdetail.order_status', '=', 'product')
            ->where('orderdetail.region', '=', 'DOMESTIC')
            ->get();
        return DataTables::of($orders)
                         ->addColumn('ordercode',function($order){
                            return '<a href="" id="" class="btn btn-primary showproduct" data-id="' .$order->id. '" data-toggle="modal" data-target="#showmodal" >' .$order->alpha_id. '</a>';
                         })
                         ->addColumn('activity',function($order){
                            return '<form action="'.route('printorder1').'" method="POST"><input type="hidden" name="id" value="' .$order->id.'">'.csrf_field().'<input type="submit" data-id="' .$order->id.'"class="btn btn-circle btn btn-primary  btn-outline" value="Print"></form>';
                        })
                         ->addColumn('status',function($order){
                            return '<a class="btn btn-danger proceedbtn" data-id="' .$order->id. '" data-toggle="modal" data-target="#proceedmodal">Proceed</a>';
                         })
                         // ->addColumn('action',function($order){
                         //    return '<a href=""  data-id="' .$order->id. '"
                         //    data-origin="'.$order->origin. '"
                         //    data-destination="' .$order->destination. '"
                         //    data-customer_id="' .$order->customer_id. '"
                         //    data-payment_ide="' .$order->payment_id. '"
                         //    data-mytype="0"
                         //    data-toggle="modal" data-target="#updateorder" class="btn-xs btn-warning updateorderbtn">Update</a>
                         //    <a href="" data-id="' .$order->id. '" data-mytype="0" data-toggle="modal" data-target="#deleteorder" class="btn-xs btn-danger deleteorderbtn">Delete</a>';
                         // })
                         ->rawColumns(['ordercode','status','activity','action'])
                         ->make(true);
        // return $orders;
    }
    // international orders show
    public function pendingorders(Request $request)
    {
        $auth_id1 = Auth::user()->id;
        $orders = DB::table('orderdetail')
        ->join('countries as city2','city2.id','orderdetail.destination')
        ->join('dutiable','dutiable.id','orderdetail.dutiable')
        ->join('payment_types','payment_types.id','orderdetail.payment_id')
        ->select('orderdetail.id','orderdetail.alpha_id','orderdetail.date','orderdetail.destination','orderdetail.origin as name1','city2.name as name2','dutiable.name as dname','orderdetail.package_id as pname','payment_types.name as ptname','orderdetail.service_type as stname','orderdetail.payment_id','orderdetail.sender_name')
        ->where('orderdetail.created_id',$auth_id1)
        ->where('orderdetail.order_status', '=', 'product')
        ->where('orderdetail.region', '=', 'INTERNATIONAL')
        ->get();
        return DataTables::of($orders)
        ->addColumn('ordercode',function($order){
            return '<a href="" id="" class="btn btn-primary showproduct" data-id="' .$order->id. '" data-toggle="modal" data-target="#showmodal" >' .$order->alpha_id. '</a>';
        })
        ->addColumn('activity',function($order){
            return '<form action="'.route('printorder2').'" method="POST"><input type="hidden" name="id" value="' .$order->id.'">'.csrf_field().'<input type="submit" data-id="' .$order->id.'"class="btn btn-circle btn btn-primary  btn-outline" value="Print"></form>';
        })
        ->addColumn('status',function($order){
            return '<a class="btn btn-danger proceedbtn" data-id="' .$order->id. '" data-toggle="modal" data-target="#proceedmodal">Proceed</a>';
        })
        // ->addColumn('action',function($order){
        //     return '<a href=""  data-id="' .$order->id. '"
        //     data-origin="'.$order->name1. '"
        //     data-destination="' .$order->destination. '"
        //     data-payment_id="' .$order->payment_id. '"
        //     data-mytype="0"
        //     data-toggle="modal" data-target="#updateorder" class="btn-xs btn-warning updateorderbtn">Update</a>
        //     <a href="" data-id="' .$order->id. '" data-mytype="0" data-toggle="modal" data-target="#deleteorder" class="btn-xs btn-danger deleteorderbtn">Delete</a>';
        // })
        ->rawColumns(['ordercode','status','activity','action'])
        ->make(true);
    }
    public function printorder2(Request $request)
    {
        $id = $request->id;
        $order = DB::table('orderdetail')
        ->join('countries as city2','city2.id','orderdetail.destination')
        ->join('dutiable','dutiable.id','orderdetail.dutiable')
        ->join('payment_types','payment_types.id','orderdetail.payment_id')
        ->select('orderdetail.*','city2.name as destination','dutiable.name as dutiable','payment_types.name as payment_id')
        // ,'orderdetail.id','orderdetail.alpha_id','orderdetail.date','orderdetail.destination','orderdetail.origin as name1','city2.name as name2','dutiable.name as dname','orderdetail.package_id as pname','payment_types.name as ptname','orderdetail.service_type as stname','orderdetail.payment_id','orderdetail.sender_name'
        ->where('orderdetail.id',$id)
        ->get();
        $product = DB::table('cust_orderdetails')
        ->join('orderdetail','orderdetail.id','cust_orderdetails.order_id')
        ->join('products','products.id','cust_orderdetails.product_id')
        ->where('order_id',$id)
        ->select('products.name','products.quantity')
        ->get();

        return view('admin.printorder',compact('order','product'));

    }
    public function printorder1(Request $request)
    {
        $id = $request->id;
        $order = DB::table('orderdetail')
            ->join('cities as city1','city1.id','orderdetail.origin')
            ->join('cities as city2','city2.id','orderdetail.destination')
            ->join('dutiable','dutiable.id','orderdetail.dutiable')
            ->join('packages','packages.id','orderdetail.package_id')
            ->join('payment_types','payment_types.id','orderdetail.payment_id')
            ->join('service_types','service_types.id','orderdetail.service_type')
            // ->join('customer','customer.id','orderdetail.customer_id')
            ->select('orderdetail.*','city1.name as origin','city2.name as destination','dutiable.name as dutiable','payment_types.name as payment_id','packages.name as packages_id','service_types.name as service_type')
            ->where('orderdetail.id',$id)
            ->get();
            $product = DB::table('cust_orderdetails')
        ->join('orderdetail','orderdetail.id','cust_orderdetails.order_id')
        ->join('products','products.id','cust_orderdetails.product_id')
        ->where('order_id',$id)
        ->select('products.name','products.quantity')
        ->get();
        // return $product;
        return view('admin.printorder',compact('order','product'));

    }

    public function detailsoforder2(Request $request)
    {

        $cities = DB::table('cities')->get(['name','id']);
        $countries = DB::table('countries')->get(['name','id']);
        $services = DB::table('service_types')->get(['name','id']);
        $packages = DB::table('packages')->get(['name','id']);
        $payments = DB::table('payment_types')->get(['name','id']);
        $dutiable = DB::table('dutiable')->get(['name','id']);
        $id = $request->id;
        $order = DB::table('orderdetail')
        ->join('countries as city2','city2.id','orderdetail.destination')
        ->select('orderdetail.*','city2.name as destination')
        ->where('orderdetail.id',$id)
        ->get();
        $product = DB::table('cust_orderdetails')
        ->join('orderdetail','orderdetail.id','cust_orderdetails.order_id')
        ->join('products','products.id','cust_orderdetails.product_id')
        ->select('products.name','products.quantity')
        ->get();
        return view('admin.detailsoforder',compact('order','product','cities','countries','services','packages','payments','dutiable'));

    }
    public function detailsoforder1(Request $request)
    
    {

        $cities = DB::table('cities')->get(['name','id']);
        $countries = DB::table('countries')->get(['name','id']);
        $services = DB::table('service_types')->get(['name','id']);
        $packages = DB::table('packages')->get(['name','id']);
        $payments = DB::table('payment_types')->get(['name','id']);
        $dutiable = DB::table('dutiable')->get(['name','id']);
        $id = $request->id;
        $order = DB::table('orderdetail')
            ->join('cities as city1','city1.id','orderdetail.origin')
            ->join('cities as city2','city2.id','orderdetail.destination')
            // ->join('customer','customer.id','orderdetail.customer_id')
            ->select('orderdetail.*','city1.name as origin','city2.name as destination')
            ->where('orderdetail.id',$id)
            ->get();
            // return $order;
            $product = DB::table('cust_orderdetails')
        ->join('orderdetail','orderdetail.id','cust_orderdetails.order_id')
        ->join('products','products.id','cust_orderdetails.product_id')
        ->select('products.name','products.quantity')
        ->get();
        return view('admin.detailsoforder',compact('order','product','cities','countries','services','packages','payments','dutiable'));

    }
    
    public function updateorder(Request $request)
    {
        // return $request->all();
        // DB::table('orderdetail')->where('id','=',$request->order_id)->update([]);
        $order = Order::findOrFail($request->id);
        $input = $request->except(['_token','name','quantity']);
        $order->fill($input)->save();
        DB::table('orderdetail')->where('id',$request->id)->update(['order_status'=>'1']);
        if ($order->region == "INTERNATIONAL") {
            return redirect(url('/internationalreq'));
        }
        else{
            return redirect(url('/domesticreq'));
        }
        
    }

    public function deleteorder(Request $request)
    {
        // echo "delete order".'<br>';
        // return $request->all();
         DB::table('orderdetail')->where('id','=',$request->order_id)->delete();
         return redirect()->back();
    }

    public function AddProduct_order(Request $request)
    {
        $product_id = DB::table('products')->insertGetId($request->except(['_token','order_id','status']));

        DB::table('cust_orderdetails')->insert([
            'product_id'=>$product_id,
            'order_id'=>$request->order_id
        ]);
        DB::table('orderdetail')
            ->where('id',$request->order_id)
            ->update(['order_status'=>'product']);
        return response()->json('success');
    }

    public function showproduct(Request $request)
    {
        $data = DB::table('cust_orderdetails')
                ->join('products','cust_orderdetails.product_id','products.id')
                ->join('orderdetail','cust_orderdetails.order_id','orderdetail.id')
                ->where('cust_orderdetails.order_id',$request->id)
                ->select('products.id as p_id', 'products.name','products.quantity','products.amount_pc')
                ->get();
        // return $data;
        echo json_encode($data);
    }

    public function deleteproduct(Request $request)
    {
        DB::table('cust_orderdetails')
        ->where('order_id',$request->o_id)
        ->where('product_id',$request->p_id)
        ->delete();
        $data = DB::table('cust_orderdetails')
                ->join('products','cust_orderdetails.product_id','products.id')
                ->join('orderdetail','cust_orderdetails.order_id','orderdetail.id')
                ->where('cust_orderdetails.order_id',$request->o_id)
                ->select('products.id as p_id', 'products.name','products.quantity','products.amount_pc')
                ->get();
        echo json_encode($data);
    }
    public function productdetail(Request $request)
    {
        $product = DB::table('products')
        ->where('id',$request->id)
        ->select('products.*')
        ->get();
        echo json_encode($product);
    }

    public function proceed(Request $request)
    {
        $date = Carbon::now();
        DB::table('orderdetail')->where('id',$request->id)->update([
            'order_status'=>'1',
            'booked_date'=>$date
        ]);
        return redirect()->back();
    }

    public function proceeded()
    {
        return view('admin.showproceedorder');
    }
    public function proceedorder1()
    {
        $auth_id1 = Auth::user()->id;
        $orders =DB::table('orderdetail')
            // ->join('cities as city1','city1.id','orderdetail.origin')
            ->join('cities as city2','city2.id','orderdetail.destination')
            ->join('dutiable','dutiable.id','orderdetail.dutiable')
            // ->join('packages','packages.id','orderdetail.package_id')
            ->join('payment_types','payment_types.id','orderdetail.payment_id')
            // ->join('service_types','service_types.id','orderdetail.service_type')
            // ->join('customer','customer.id','orderdetail.customer_id')
            // ,'city1.name as name1' ,'dutiable.name as dname' ,'service_types.name as stname','packages.name as pname'
            ->select('orderdetail.*','orderdetail.origin as name1','city2.name as name2','payment_types.name as ptname')
            ->where('orderdetail.created_id',$auth_id1)
            ->where('order_status', '=' , '1')
            ->get();
        return DataTables::of($orders)
                         ->addColumn('ordercode',function($order){
                            return '<a href="" id="" class="btn btn-primary showproduct" data-id="' .$order->id. '" data-toggle="modal" data-target="#showmodal" >' .$order->alpha_id. '</a>';
                         })
                         ->addColumn('status',function($order){
                            if($order->order_status == 1)
                            return '<h2><span class="label label-success">Booked</span></h2>';
                            else
                            return '<h2><span class="label label-default">' .ucfirst($order->order_status). '</span></h2>';
                         })
                         ->addColumn('activity',function($order){
                            if($order->order_status != 5)
                            {
                                return '<form method="POST" id="statusform"> ' .csrf_field(). '
                                <input type="hidden" name="id" value="' .$order->id. '">
                                <input type="hidden" id="statusid" value>
                                <select name="status" style="width: 70%;" class="form-control status_select" required>
                                <option disabled selected value> -- Select a Action -- </option>
                                <option value="2">At DSL</option>
                                <option value="3">In Transit</option>
                                <option value="4">Ready For Delivery</option>
                                <option value="5">Delivered</option>
                                </select>
                                <button type="submit" class="btn btn-primary">Proceed</button></form>';
                            }
                            else
                            return '<h2><span class="label label-success">Completed</span></h2>';
                         })
                         // ->addColumn('action',function($order){
                         //    if($order->order_status != 5)
                         //    return '<button type="submit" class="btn btn-primary">Proceed</button></form>';
                         //    else
                         //    return '<h2><span class="label label-success">Completed</span></h2>';
                         // })
                         ->rawColumns(['ordercode','status','activity'])
                         ->make(true);
    }
    public function proceedorder2()
    {
        $auth_id1 = Auth::user()->id;
        $orders =DB::table('orderdetail')
            // ->join('cities as city1','city1.id','orderdetail.origin')
            ->join('cities as city2','city2.id','orderdetail.destination')
            ->join('dutiable','dutiable.id','orderdetail.dutiable')
            // ->join('packages','packages.id','orderdetail.package_id')
            ->join('payment_types','payment_types.id','orderdetail.payment_id')
            // ->join('service_types','service_types.id','orderdetail.service_type')
            // ->join('customer','customer.id','orderdetail.customer_id')
            ->select('orderdetail.*','orderdetail.origin as name1','city2.name as name2','payment_types.name as ptname')
            ->where('orderdetail.created_id',$auth_id1)
            ->where('order_status', '=' , '2')
            ->get();
        return DataTables::of($orders)
                         ->addColumn('ordercode',function($order){
                            return '<a href="" id="" class="btn btn-primary showproduct" data-id="' .$order->id. '" data-toggle="modal" data-target="#showmodal" >' .$order->alpha_id. '</a>';
                         })
                          ->addColumn('status',function($order){
                            if($order->order_status == 2)
                            return '<h2><span class="label label-warning">At DSL</span></h2>';
                            else
                            return '<h2><span class="label label-default">' .ucfirst($order->order_status). '</span></h2>';
                         })
                         ->addColumn('activity',function($order){
                            if($order->order_status != 5)
                            {
                                return '<form method="POST" id="statusform"> ' .csrf_field(). '
                                <input type="hidden" name="id" value="' .$order->id. '">
                                <input type="hidden" id="statusid" value>
                                <select name="status" style="width: 70%;" class="form-control status_select" required>
                                <option disabled selected value> -- Select a Action -- </option>
                                
                                <option value="3">In Transit</option>
                                <option value="4">Ready For Delivery</option>
                                <option value="5">Delivered</option>
                                </select>
                                <button type="submit" class="btn btn-primary">Proceed</button></form>';
                            }
                            else
                            return '<h2><span class="label label-success">Completed</span></h2>';
                         })
                         // ->addColumn('action',function($order){
                         //    if($order->order_status != 5)
                         //    return '<button type="submit" class="btn btn-primary">Proceed</button></form>';
                         //    else
                         //    return '<h2><span class="label label-success">Completed</span></h2>';
                         // })
                         ->rawColumns(['ordercode','status','activity'])
                         ->make(true);
    }
    public function proceedorder3()
    {
        $auth_id1 = Auth::user()->id;
        $orders =DB::table('orderdetail')
            // ->join('cities as city1','city1.id','orderdetail.origin')
            ->join('cities as city2','city2.id','orderdetail.destination')
            ->join('dutiable','dutiable.id','orderdetail.dutiable')
            // ->join('packages','packages.id','orderdetail.package_id')
            ->join('payment_types','payment_types.id','orderdetail.payment_id')
            // ->join('service_types','service_types.id','orderdetail.service_type')
            // ->join('customer','customer.id','orderdetail.customer_id')
            ->select('orderdetail.*','orderdetail.origin as name1','city2.name as name2','payment_types.name as ptname')
            ->where('orderdetail.created_id',$auth_id1)
            ->where('order_status', '=' , '3')
            ->get();
        return DataTables::of($orders)
                         ->addColumn('ordercode',function($order){
                            return '<a href="" id="" class="btn btn-primary showproduct" data-id="' .$order->id. '" data-toggle="modal" data-target="#showmodal" >' .$order->alpha_id. '</a>';
                         })
                          ->addColumn('status',function($order){
                            if($order->order_status == 3)
                            return '<h2><span class="label label-danger">In Transit</span></h2>';
                            else
                            return '<h2><span class="label label-default">' .ucfirst($order->order_status). '</span></h2>';
                         })
                         ->addColumn('activity',function($order){
                            if($order->order_status != 5)
                            {
                                return '<form method="POST" id="statusform"> ' .csrf_field(). '
                                <input type="hidden" name="id" value="' .$order->id. '">
                                <input type="hidden" id="statusid" value>
                                <select name="status" style="width: 70%;" class="form-control status_select" required>
                                <option disabled selected value> -- Select a Action -- </option>
                                
                                <option value="4">Ready For Delivery</option>
                                <option value="5">Delivered</option>
                                </select>
                                <button type="submit" class="btn btn-primary">Proceed</button></form>';
                            }
                            else
                            return '<h2><span class="label label-success">Completed</span></h2>';
                         })
                         // ->addColumn('action',function($order){
                         //    if($order->order_status != 5)
                         //    return '<button type="submit" class="btn btn-primary">Proceed</button></form>';
                         //    else
                         //    return '<h2><span class="label label-success">Completed</span></h2>';
                         // })
                         ->rawColumns(['ordercode','status','activity'])
                         ->make(true);
    }
    public function proceedorder4()
    {
        $auth_id1 = Auth::user()->id;
        $orders =DB::table('orderdetail')
            // ->join('cities as city1','city1.id','orderdetail.origin')
            ->join('cities as city2','city2.id','orderdetail.destination')
            ->join('dutiable','dutiable.id','orderdetail.dutiable')
            // ->join('packages','packages.id','orderdetail.package_id')
            ->join('payment_types','payment_types.id','orderdetail.payment_id')
            // ->join('service_types','service_types.id','orderdetail.service_type')
            // ->join('customer','customer.id','orderdetail.customer_id')
            ->select('orderdetail.*','orderdetail.origin as name1','city2.name as name2','payment_types.name as ptname')
            ->where('orderdetail.created_id',$auth_id1)
            ->where('order_status', '=' , '4')
            ->get();
        return DataTables::of($orders)
                         ->addColumn('ordercode',function($order){
                            return '<a href="" id="" class="btn btn-primary showproduct" data-id="' .$order->id. '" data-toggle="modal" data-target="#showmodal" >' .$order->alpha_id. '</a>';
                         })
                          ->addColumn('status',function($order){
                            if($order->order_status == 4)
                            return '<h2><span class="label label-default">Ready For Delivery</span></h2>';
                            else
                            return '<h2><span class="label label-default">' .ucfirst($order->order_status). '</span></h2>';
                         })
                         ->addColumn('activity',function($order){
                            if($order->order_status != 5)
                            {
                                return '<form method="POST" id="statusform"> ' .csrf_field(). '
                                <input type="hidden" name="id" value="' .$order->id. '">
                                <input type="hidden" id="statusid" value>
                                <select name="status" style="width: 70%;" class="form-control status_select" required>
                                <option disabled selected value> -- Select a Action -- </option>
                                
                                <option value="5">Delivered</option>
                                </select>
                                <button type="submit" class="btn btn-primary">Proceed</button></form>';
                            }
                            else
                            return '<h2><span class="label label-success">Completed</span></h2>';
                         })
                         // ->addColumn('action',function($order){
                         //    if($order->order_status != 5)
                         //    return '<button type="submit" class="btn btn-primary">Proceed</button></form>';
                         //    else
                         //    return '<h2><span class="label label-success">Completed</span></h2>';
                         // })
                         ->rawColumns(['ordercode','status','activity'])
                         ->make(true);
    }

    public function changestatus(Request $request)
    {
        $id = $request->id;
        $status = $request->status;
        $date = Carbon::now();
        if ($status == 1) 
        {
            DB::table('orderdetail')->where('id',$id)->update([
            'order_status'=> $status,
            'booked_date'=>$date
            ]);
            return redirect()->back();
        }
        elseif ($status == 2) 
        {
            DB::table('orderdetail')->where('id',$id)->update([
            'order_status'=> $status,
            'dsl_date'=>$date
            ]);
            return redirect()->back();
        }
        elseif ($status == 3) 
        {
            DB::table('orderdetail')->where('id',$id)->update([
            'order_status'=> $status,
            'transit_date'=>$date
            ]);
            return redirect()->back();
        }
        elseif ($status == 4) 
        {
            DB::table('orderdetail')->where('id',$id)->update([
            'order_status'=> $status,
            'out_date'=>$date
            ]);
            return redirect()->back();
        }
        elseif ($status == 5) 
        {
            DB::table('orderdetail')->where('id',$id)->update([
            'order_status'=> $status,
            'deliever_date'=>$date
            ]);
        }
    }
    public function changestatuspending(Request $request)
    {
        $id = $request->id;
        $status = $request->status;
        DB::table('orderdetail')->where('id',$id)->update([
            'order_status'=> 'pending'
        ]);
        return response()->json('success');
    }

    public function completed()
    {
        return view('admin.showcompletedorder');
    }
    public function completed1()
    {
        return view('admin.showcompletedorder1');
    }
    public function completedorders()
    {
        $auth_id1 = Auth::user()->id;
        $orders = DB::table('orderdetail')
            ->join('cities as city1','city1.id','orderdetail.origin')
            ->join('cities as city2','city2.id','orderdetail.destination')
            ->join('dutiable','dutiable.id','orderdetail.dutiable')
            ->join('packages','packages.id','orderdetail.package_id')
            ->join('payment_types','payment_types.id','orderdetail.payment_id')
            ->join('service_types','service_types.id','orderdetail.service_type')
            ->select('orderdetail.*','city1.name as name1','city2.name as name2','dutiable.name as dname','packages.name as pname','payment_types.name as ptname','service_types.name as stname')
            ->where('orderdetail.created_id',$auth_id1)
            ->where('orderdetail.order_status', '=', '5')
            ->where('orderdetail.region', '=', 'DOMESTIC')
            ->get();
        return DataTables::of($orders)
                         ->addColumn('ordercode',function($order){
                            return '<a href="" id="" class="btn btn-primary showproduct" data-id="' .$order->id. '" data-toggle="modal" data-target="#showmodal" >' .$order->alpha_id. '</a>';
                         })
                         ->addColumn('activity',function($order){
                            return '<form action="'.route('printorder1').'" method="POST"><input type="hidden" name="id" value="' .$order->id.'">'.csrf_field().'<input type="submit" data-id="' .$order->id.'"class="btn btn-circle btn btn-primary  btn-outline" value="Print"></form>';
                        })
                         ->rawColumns(['ordercode','status','activity','action'])
                         ->make(true);
    }
    public function completedorders2()
    {
        $auth_id1 = Auth::user()->id;
        $orders = DB::table('orderdetail')
        ->join('countries as city2','city2.id','orderdetail.destination')
        ->join('dutiable','dutiable.id','orderdetail.dutiable')
        ->join('payment_types','payment_types.id','orderdetail.payment_id')
        ->select('orderdetail.id','orderdetail.alpha_id','orderdetail.date','orderdetail.destination','orderdetail.origin as name1','city2.name as name2','dutiable.name as dname','orderdetail.package_id as pname','payment_types.name as ptname','orderdetail.service_type as stname','orderdetail.payment_id','orderdetail.sender_name')
        ->where('orderdetail.created_id',$auth_id1)
        ->where('orderdetail.order_status', '=', '5')
        ->where('orderdetail.region', '=', 'INTERNATIONAL')
        ->get();
        return DataTables::of($orders)
        ->addColumn('ordercode',function($order){
            return '<a href="" id="" class="btn btn-primary showproduct" data-id="' .$order->id. '" data-toggle="modal" data-target="#showmodal" >' .$order->alpha_id. '</a>';
        })
        ->addColumn('activity',function($order){
            return '<form action="'.route('printorder2').'" method="POST"><input type="hidden" name="id" value="' .$order->id.'">'.csrf_field().'<input type="submit" data-id="' .$order->id.'"class="btn btn-circle btn btn-primary  btn-outline" value="Print"></form>';
        })
        ->rawColumns(['ordercode','activity'])
        ->make(true);
    }

    public function domesticreq()
    {
        return view('admin.domesticreq');
    }
    public function domesticorders()
    {
        $orders = DB::table('orderdetail')
            ->join('cities as city1','city1.id','orderdetail.origin')
            ->join('cities as city2','city2.id','orderdetail.destination')
            // ->join('customer','customer.id','orderdetail.customer_id')
            ->select('orderdetail.*','city1.name as name1','city2.name as name2')
            ->where('orderdetail.created_id',0)
            ->where('orderdetail.order_status', '=', 'product')
            ->where('orderdetail.region', '=', 'DOMESTIC')
            ->get();
        return DataTables::of($orders)
                         ->addColumn('ordercode',function($order){
                            return '<a href="" id="" class="btn btn-primary showproduct" data-id="' .$order->id. '" data-toggle="modal" data-target="#showmodal" >' .$order->alpha_id. '</a>';
                         })
                         ->addColumn('status',function($order){
                            return '<form method="POST" action="detailsoforder1">'.csrf_field().'<input type="hidden" name="id" value="' .$order->id. '"><input type="submit" class="btn btn-danger" data-id="' .$order->id. '" value="Proceed"></form>';
                         })
                         ->rawColumns(['ordercode','status'])
                         ->make(true);
    }
    public function internationalreq()
    {
        return view('admin.internationalreq');
    }
    public function internationalorders()
    {
        $orders = DB::table('orderdetail')
            ->join('cities as city2','city2.id','orderdetail.destination')
            ->select('orderdetail.*','city2.name as name2')
            ->where('orderdetail.created_id',0)
            ->where('orderdetail.order_status', '=', 'product')
            ->where('orderdetail.region', '=', 'INTERNATIONAL')
            ->get();
        return DataTables::of($orders)
                         ->addColumn('ordercode',function($order){
                            return '<a href="" id="" class="btn btn-primary showproduct" data-id="' .$order->id. '" data-toggle="modal" data-target="#showmodal" >' .$order->alpha_id. '</a>';
                         })
                         ->addColumn('status',function($order){
                            return '<form method="POST" action="detailsoforder2">'.csrf_field().'<input type="hidden" name="id" value="' .$order->id. '"><input type="submit" class="btn btn-danger" data-id="' .$order->id. '" value="Proceed"></form>';
                         })
                         ->rawColumns(['ordercode','status'])
                         ->make(true);
    }


    // public function customercreditordershow(Request $request)
    // {
    //     $customer = Customer::all();
    //     $data = 'empty';
    //     return view('admin.creditorderscustomer',compact('data','customer'));
    // }
    // public function customercreditorders($id)
    // {
    //     $customer = Customer::all();
    //     $data = 'empty';
    //     $data = DB::table('orderdetail')
    //         ->join('cities as city1','city1.id','orderdetail.deliverypoint')
    //         ->join('cities as city2','city2.id','orderdetail.destination')
    //         ->join('customer','customer.id','orderdetail.customer_id')
    //         ->select('orderdetail.*','city1.name as name1','city2.name as name2','customer.name as cname')
    //         ->where('customer_id',$id)
    //         ->where('payment_type',2)
    //         ->get();
    //     return DataTables::of($data)
    //                      ->addColumn('ordercode',function($value){
    //                         if($value->order_status != 'pending')
    //                         return '<a href="" class="btn btn-primary showproduct" data-id="' .$value->id. '" data-toggle="modal" data-target="#showmodal" >' .$value->alpha_id. '</a>';
    //                         else
    //                         return '<h2> <span class="label label-primary showproduct">' .$value->alpha_id. '</span></h2>';
    //                      })
    //                      ->addColumn('status',function($value){
    //                         if($value->order_status == 1)
    //                         return '<h2><span class="label label-primary">Picking Up Order</span></h2>';
    //                         elseif($value->order_status == 2)
    //                         return '<h2><span class="label label-info">At Warehouse</span></h2>';
    //                         elseif($value->order_status == 3)
    //                         return '<h2><span class="label label-warning">Ready For Delivery</span></h2>';
    //                         elseif($value->order_status == 4)
    //                         return '<h2><span class="label label-danger">On The Way</span></h2>';
    //                         elseif($value->order_status == 5)
    //                         return '<h2><span class="label label-success">Delivered</span></h2>';
    //                         else
    //                         return '<h2><span class="label label-default">' .ucfirst($value->order_status). '</span></h2>';
    //                      })
    //                      ->addColumn('action',function($value){
    //                         if($value->order_status != 'pending')
    //                             return '<form action="' .route('changetocash'). '" method="POST">
    //                                 ' .csrf_field(). '
    //                                 <input type="hidden" name="id" value="' .$value->id. '">
    //                                 <button type="submit" class="btn btn-success">Cash Received</button>
    //                                 </form>';
    //                         else
    //                         return '--';
    //                      })
    //                      ->rawColumns(['ordercode','status','action'])
    //                      ->make(true);
    //     // return view('admin.creditorders',compact('data','customer'));
    // }

    public function creditordershow(Request $request)
    {
        $customer = 'empty';
        $data = 'empty';
        return view('admin.creditorders',compact('data','customer'));
    }
    public function creditorders(Request $request)
    {
        $customer = 'empty';
        $data = 'empty';
        $auth_id1 = Auth::user()->id;
        $data = DB::table('orderdetail')
            ->join('cities as city1','city1.id','orderdetail.origin')
            ->join('cities as city2','city2.id','orderdetail.destination')
            ->join('dutiable','dutiable.id','orderdetail.dutiable')
            ->join('packages','packages.id','orderdetail.package_id')
            ->join('payment_types','payment_types.id','orderdetail.payment_id')
            ->join('service_types','service_types.id','orderdetail.service_type')
            ->select('orderdetail.*','city1.name as name1','city2.name as name2','dutiable.name as dname','packages.name as pname','payment_types.name as ptname','service_types.name as stname')
            ->where('orderdetail.created_id',$auth_id1)
            ->where('orderdetail.region', '=', 'DOMESTIC')
            ->get();
        return DataTables::of($data)
                         ->addColumn('ordercode',function($value){
                            if($value->order_status != 'pending')
                            return '<a href="" class="btn btn-primary showproduct" data-id="' .$value->id. '" data-toggle="modal" data-target="#showmodal" >' .$value->alpha_id. '</a>';
                            else
                            return '<h2> <span class="label label-primary showproduct">' .$value->alpha_id. '</span></h2>';
                         })
                         ->addColumn('status',function($value){
                            if($value->order_status == 1)
                            return '<h2><span class="label label-primary">Picking Up Order</span></h2>';
                            elseif($value->order_status == 2)
                            return '<h2><span class="label label-info">At Warehouse</span></h2>';
                            elseif($value->order_status == 3)
                            return '<h2><span class="label label-warning">Ready For Delivery</span></h2>';
                            elseif($value->order_status == 4)
                            return '<h2><span class="label label-danger">On The Way</span></h2>';
                            elseif($value->order_status == 5)
                            return '<h2><span class="label label-success">Delivered</span></h2>';
                            else
                            return '<h2><span class="label label-default">' .ucfirst($value->order_status). '</span></h2>';
                         })
                         ->addColumn('action',function($value){
                            if($value->order_status != 'pending')
                                return '<form action="' .route('changetocash'). '" method="POST">
                                    ' .csrf_field(). '
                                    <input type="hidden" name="id" value="' .$value->id. '">
                                    <button type="submit" class="btn btn-success">Cash Received</button>
                                    </form>';
                            else
                            return '--';
                         })
                         ->rawColumns(['ordercode','status','action'])
                         ->make(true);
    }

    public function dailyreport(Request $request)
    {
        $report = 'empty';
        $report1 = 'empty';
        return view('admin.dailyreport',compact('report','report1'));
    }
    public function daily(Request $request)
    {
        $date   =     Carbon::parse($request->date)->format('d');
        // return $date;
        $month  =    Carbon::parse($request->date)->format('m');
        // return $month;
        $year   =     Carbon::parse($request->date)->format('Y');
        // return $year;

        $report =   DB::table('orderdetail')
            ->join('cities as city1','city1.id','orderdetail.origin')
            ->join('cities as city2','city2.id','orderdetail.destination')
            ->whereYear('orderdetail.date',$year)
            ->whereMonth('orderdetail.date', $month)
            ->whereDay('orderdetail.date', $date)
            ->select('orderdetail.*','city1.name as name1','city2.name as name2')
            ->get();
        $report1 =   DB::table('orderdetail')
            ->join('cities as city2','city2.id','orderdetail.destination')
            ->whereYear('orderdetail.date',$year)
            ->whereMonth('orderdetail.date', $month)
            ->whereDay('orderdetail.date', $date)
            ->where('orderdetail.origin','=','PK')
            ->select('orderdetail.*','city2.name as name2')
            ->get();
        // return $report;
        return view('admin.dailyreport',compact('report','report1'));
    }

    public function monthlyreport(Request $request)
    {
        $report = 'empty';
        $report1 = 'empty';
        return view('admin.monthlyreport',compact('report','report1'));
    }
    public function monthly(Request $request)
    {
        
        $year =  Carbon::parse($request->month)->format('Y');
        $month = Carbon::parse($request->month)->format('m');
        $report = DB::table('orderdetail')
            ->join('cities as city1','city1.id','orderdetail.origin')
            ->join('cities as city2','city2.id','orderdetail.destination')
            ->whereYear('orderdetail.date',$year)
            ->whereMonth('orderdetail.date',$month)
            ->select('orderdetail.*','city1.name as name1','city2.name as name2')
            ->get();
            $report1 = DB::table('orderdetail')
            ->join('cities as city2','city2.id','orderdetail.destination')
            ->whereYear('orderdetail.date',$year)
            ->whereMonth('orderdetail.date',$month)
            ->where('origin',"=",'PK')
            ->select('orderdetail.*','city2.name as name2')
            ->get();
        // return $report;
        return view('admin.monthlyreport',compact('report','report1'));
    }

     public function yearlyreport(Request $request)
    {
        $report = 'empty';
        $report1 = 'empty';
        return view('admin.yearlyreport',compact('report','report1'));
    }
    public function yearly(Request $request)
    {
        $year = $request->year;
        $report = DB::table('orderdetail')
        ->join('cities as city1','city1.id','orderdetail.origin')
        ->join('cities as city2','city2.id','orderdetail.destination')
        ->whereYear('orderdetail.date',$year)
        ->select('orderdetail.*','city1.name as name1','city2.name as name2')
        ->get();
        $report1 = DB::table('orderdetail')
            ->join('cities as city2','city2.id','orderdetail.destination')
            ->whereYear('orderdetail.date',$year)
            ->where('origin',"=",'PK')
            ->select('orderdetail.*','city2.name as name2')
            ->get();
         return view('admin.yearlyreport',compact('report','report1'));
    }


    public function changetocash(Request $request)
    {
        // return $request->all();
        DB::table('orderdetail')->where('id',$request->id)->update(['payment_type'=>1]);
        return redirect()->back();
    }

    public function newcustomer(Request $request)
    {
        $cities = DB::table('cities')->select('cities.*')->get();
        return view('admin.addcustomer',compact('cities'));
    }

    public function addcustomer(Request $request)
    {
        // return $request->email;
        // 
        $customer = Validator::make($request->all(),[
            'name'=>'required',
            'password'=>'required',
            'address'=>'required',
            'contact'=>'required',
            'city_id'=>'required',
        ]);
        $email = Validator::make($request->all(),[
            'email'=>['required',Rule::unique('customer')]
        ]);
        if ($email->fails())
        {
            // Session::flash('email','Same Email Already Taken');
            return response()->json('email');
        }
        if ($customer->fails())
        {
            // Session::flash('fields','All Fields Are Required');
            return response()->json('fields');
        }
        else
        {
            $id = Customer::insertGetId([
                'name' => $request->input('name'),
                'email' => $request->input('email'),
                'contact' => $request->input('contact'),
                'address'=>$request->input('address'),
                'city_id'=>$request->input('city_id'),
                'password'=>encrypt($request->input('password'))
            ]);
            $acr= DB::table('cities')->where('id',$request->input('city_id'))->select('cities.acr')->first()->acr;
            $alpha_id = $acr.'/C'.str_pad($id, 4, '0', STR_PAD_LEFT);
            DB::table('customer')->where('id',$id)->update(['alpha_id'=>$alpha_id]);
            return response()->json('success');
        }
    }

    public function viewcustomer(Request $request)
    {
        $cities = DB::table('cities')->select('cities.*')->get();
        return view('admin.viewcustomers',compact('customers','cities'));
    }
    public function customerdata()
    {
        $customers = Customer::join('cities','cities.id','customer.city_id')
                             ->select('customer.*','cities.name as c_name')
                             ->get();
        return DataTables::of($customers)
                         ->addColumn('alphaid',function($value){
                            return '<h2><span class="label label-success">' .$value->alpha_id. '</span></h2>';
                         })
                         ->addColumn('membersince',function($value){
                            return Carbon::parse( $value->created_at)->format('d-M-Y');
                         })
                         ->addColumn('origin',function($value){
                            return $value->c_name;
                         })
                         ->addColumn('action',function($value){
                            return '<a href="" class="btn-xs btn-warning updatebtn"
                            data-id="' .$value->id. '"
                            data-name="' .$value->name. '"
                            data-city_id="' .$value->city_id. '"
                            data-contact="' .$value->contact. '"
                            data-address="' .$value->address. '"
                            data-email="' .$value->email. '"
                            data-toggle="modal" data-target="#updatemodal">Update
                            </a>
                            <a href="" class="btn-xs btn-danger  deletebtn" data-id="' .$value->id. '" data-toggle="modal" data-target="#deletemodal">Delete</a>';
                         })
                         ->rawColumns(['alphaid','action'])
                         ->make(true);
    }
    public function updatecustomer(Request $request)
    {
        
        $oldemail = Customer::where('id',$request->id)->select('email')->first()->email;
        $newemail = $request->email;
        if ($oldemail == $newemail)
        {
            $customer = Validator::make($request->all(),[
            'name'=>'required',
            'password'=>'required',
            'address'=>'required',
            'contact'=>'required',
            'city_id'=>'required',
            ]);
            if ($customer->fails())
            {
                Session::flash('fields','All Fields Are Required');
                return response()->json('fields');
            }
            else
            {
                DB::table('customer')->where('id',$request->id)->update([
                    'name' => $request->input('name'),
                    'email' => $request->input('email'),
                    'contact' => $request->input('contact'),
                    'address'=>$request->input('address'),
                    'city_id'=>$request->input('city_id'),
                    'password'=>encrypt($request->input('password'))
                ]);
                return response()->json('success');
            }
        }
        else
        {
            $email = Validator::make($request->all(),[
            'email'=>['required',Rule::unique('customer')]
            ]);
            if ($email->fails())
            {
                // Session::flash('email','Same Email Already Taken');
                return response()->json('email');
            }
        }
        
    }
    public function deletecustomer(Request $request)
    {
        DB::table('customer')->where('id',$request->id)->delete();
        return response()->json('success');
    }

    public function newemployee(Request $request)
    {
        $cities = DB::table('cities')->select('cities.*')->get();
        return view('admin.addemployee',compact('offices','cities'));
    }
    public function employeesdata()
    {
        $offices = DB::table('office')
                    ->join('cities','cities.id','office.city_id')
                    ->select('office.*','cities.name as cname')->get();
        $employees = employee::join('office','office.id','employee.office_id')
                             ->join('cities','cities.id','office.city_id')
                             ->select('employee.*','cities.name as e_name')
                             ->get();
        return DataTables::of($employees)
                         ->addColumn('alphaid',function($value){
                            return '<h2><span class="label label-success">' .$value->alpha_id. '</span></h2>';
                         })
                         ->addColumn('membersince',function($value){
                            return Carbon::parse( $value->created_at)->format('d-M-Y');
                         })
                         ->addColumn('origin',function($value){
                            return $value->e_name;
                         })
                         ->addColumn('action',function($value){
                            return '<a href="" class="btn-xs btn-warning updatebtn"
                            data-id="' .$value->id. '"
                            data-name="' .$value->name. '"
                            data-office_id="' .$value->office_id. '"
                            data-contact="' .$value->contact. '"
                            data-address="' .$value->address. '"
                            data-email="' .$value->email. '"
                            data-toggle="modal" data-target="#updatemodal">Update
                            </a>
                            <a href="" class="btn-xs btn-danger  deletebtn" data-id="' .$value->id. '" data-toggle="modal" data-target="#deletemodal">Delete</a>';
                         })
                         ->rawColumns(['alphaid','action'])
                         ->make(true);
    }

    public function addemployee(Request $request)
    {
        // return $request->all();
        // 
        $employee = Validator::make($request->all(),[
            'name'=>'required',
            'password'=>'required',
            'address'=>'required',
            'contact'=>'required',
            'office_id'=>'required',
        ]);
        $email = Validator::make($request->all(),[
            'email'=>['required',Rule::unique('employee')]
        ]);
        if ($email->fails())
        {
            // Session::flash('email','Same Email Already Taken');
            return response()->json('email');
        }
        if ($employee->fails())
        {
            // Session::flash('fields','All Fields Are Required');
            return response()->json('fields');
        }
        else
        {
            $id = Employee::insertGetId([
                'name' => $request->input('name'),
                'email' => $request->input('email'),
                'contact' => $request->input('contact'),
                'address'=>$request->input('address'),
                'office_id'=>$request->input('office_id'),
                'password'=>encrypt($request->input('password'))
            ]);
            $city= DB::table('office')->where('id',$request->office_id)->select('city_id')->first()->city_id;
            $acr= DB::table('cities')->where('id',$city)->select('cities.acr')->first()->acr;
            $alpha_id = $acr.'/E'.str_pad($id, 4, '0', STR_PAD_LEFT);
            DB::table('employee')->where('id',$id)->update(['alpha_id'=>$alpha_id]);
            return response()->json('success');
        }
    }
    public function viewemployee(Request $request)
    {
        $offices = DB::table('office')
                        ->join('cities','cities.id','office.city_id')
                        ->select('office.*','cities.name as cname')->get();
        $cities = DB::table('cities')->select('cities.*')->get();
        $employees = employee::join('office','office.id','employee.office_id')
                             ->join('cities','cities.id','office.city_id')
                             ->select('employee.*','cities.name as e_name')
                             ->get();
        return view('admin.viewemployee',compact('employees','offices','cities'));
    }

    public function updateemployee(Request $request)
    {

        $oldemail = Employee::where('id',$request->id)->select('email')->first()->email;
        $newemail = $request->email;
        if ($oldemail == $newemail)
        {
            $employee = Validator::make($request->all(),[
                'name'=>'required',
                'password'=>'required',
                'address'=>'required',
                'contact'=>'required',
                'office_id'=>'required',
            ]);
            if ($employee->fails())
            {
                Session::flash('fields','All Fields Are Required');
                return response()->json('fields');
            }
            else
            {
                DB::table('employee')->where('id',$request->id)->update([
                    'name' => $request->input('name'),
                    'email' => $request->input('email'),
                    'contact' => $request->input('contact'),
                    'address'=>$request->input('address'),
                    'city_id'=>$request->input('city_id'),
                    'office_id'=>$request->input('office_id'),
                    'password'=>encrypt($request->input('password'))
                ]);
                return response()->json('success');
            }
        }
        else
        {
            $email = Validator::make($request->all(),[
                'email'=>['required',Rule::unique('employee')]
            ]);
            if ($email->fails())
            {
                Session::flash('email','Same Email Already Taken');
                return response()->json('email');
            }
        }
    }
    public function deleteemployee(Request $request)
    {
        DB::table('employee')->where('id',$request->id)->delete();
        return response()->json('success');
    }
    // 
    // 
    public function newoffice(Request $request)
    {
        $cities = DB::table('cities')->select('cities.*')->get();
        return view('admin.addoffice',compact('cities'));
    }

    public function addoffice(Request $request)
    {
        // return $request->all();
        // 
        $office = Validator::make($request->all(),[
            'address'=>'required',
            'contact'=>'required',
            'city_id'=>'required',
        ]);
        
        
        if ($office->fails())
        {
            // Session::flash('fields','All Fields Are Required');
            return response()->json('error');
        }
        else
        {
            $id = Office::insertGetId([
                'contact' => $request->input('contact'),
                'address'=>$request->input('address'),
                'city_id'=>$request->input('city_id'),
            ]);
            $acr= DB::table('cities')->where('id',$request->input('city_id'))->select('cities.acr')->first()->acr;
            $alpha_id = $acr.'/B'.str_pad($id, 4, '0', STR_PAD_LEFT);
            DB::table('office')->where('id',$id)->update(['alpha_id'=>$alpha_id]);
            return response()->json('success');
        }
    }

    public function viewoffice(Request $request)
    {
        $cities = DB::table('cities')->select('cities.*')->get();
        return view('admin.viewoffice',compact('cities'));
    }
    public function officedata()
    {
        $offices = office::join('cities','cities.id','office.city_id')
                        ->select('office.*','cities.name as o_name')
                        ->get();
        return DataTables::of($offices)
                          ->addColumn('alphaid',function($value){
                            return '<h2><span class="label label-success">' .$value->alpha_id. '</span></h2>';
                         })
                         ->addColumn('membersince',function($value){
                            return Carbon::parse( $value->created_at)->format('d-M-Y');
                         })
                         ->addColumn('origin',function($value){
                            return $value->o_name;
                         })
                         ->addColumn('action',function($value){
                            return '<a href="" class="btn-xs btn-warning updatebtn"
                            data-id="' .$value->id. '"
                            data-office_id="' .$value->city_id. '"
                            data-contact="' .$value->contact. '"
                            data-address="' .$value->address. '"
                            data-toggle="modal" data-target="#updatemodal">Update
                            </a>
                            <a href="" class="btn-xs btn-danger  deletebtn" data-id="' .$value->id. '" data-toggle="modal" data-target="#deletemodal">Delete</a>';
                         })
                         ->rawColumns(['alphaid','action'])
                         ->make(true);
    }

    public function updateoffice(Request $request)
    {
        DB::table('office')->where('id',$request->id)->update([
            'contact'=>$request->contact,
            'address'=>$request->address
        ]);
        return response()->json('success');
    }
    public function deleteoffice(Request $request)
    {
        DB::table('office')->where('id',$request->id)->delete();
        return response()->json('success');
    }

    public function accountsview()
    {
        $acc_types = DB::table('account_types')->select('account_types.*')->get();
        return view('admin.accounts',compact('acc_types'));
    }
    public function accountsdata()
    {
        $accounts = DB::table('accounts')->select('accounts.*')->get();
        return DataTables::of($accounts)->make(true);
    }
    public function submitamount(Request $request)
    {
        Account::updateOrCreate(
            [
                'transaction_date'=>$request->transaction_date
            ],
            [   
                'transaction_date'=>$request->transaction_date,

                $request->amount_type=>$request->amount,
            ]
        );
        $DSL = Account::where('transaction_date',$request->transaction_date)->select('accounts.DSL')->first()->DSL;
        $KN = Account::where('transaction_date',$request->transaction_date)->select('accounts.KN')->first()->KN;
        $FUEL = Account::where('transaction_date',$request->transaction_date)->select('accounts.FUEL')->first()->FUEL;
        $PURCH = Account::where('transaction_date',$request->transaction_date)->select('accounts.PURCH')->first()->PURCH;
        $BILTY = Account::where('transaction_date',$request->transaction_date)->select('accounts.BILTY')->first()->BILTY;
        $ENTITY = Account::where('transaction_date',$request->transaction_date)->select('accounts.ENTITY')->first()->ENTITY;
        $SALES = Account::where('transaction_date',$request->transaction_date)->select('accounts.SALES')->first()->SALES;
        $T1 = $DSL + $KN;
        $T2 = $FUEL+ $PURCH + $BILTY + $ENTITY + $SALES;
        $PC = Account::where('transaction_date',$request->transaction_date)->select('accounts.PC')->first()->PC;
        $Grand_Total = ($T1-$T2) + $PC;

        Account::where('transaction_date',$request->transaction_date)->update(
            [
                'DSL'=>$DSL,
                'KN'=>$KN,
                'FUEL'=>$FUEL,
                'PURCH'=>$PURCH,
                'BILTY'=>$BILTY,
                'ENTITY'=>$ENTITY,
                'SALES'=>$SALES,
                'T1'=>$T1,
                'T2'=>$T2,
                'PC'=>$PC,
                'Grand_Total'=>$Grand_Total,
            ]
        );
    }
    public function submitpittycash(Request $request)
    {
        Account::updateOrCreate(
            [
                'transaction_date'=>$request->transaction_date
            ],
            [   
                'transaction_date'=>$request->transaction_date,

                'PC'=>$request->amount,
            ]
        );
        $DSL = Account::where('transaction_date',$request->transaction_date)->select('accounts.DSL')->first()->DSL;
        $KN = Account::where('transaction_date',$request->transaction_date)->select('accounts.KN')->first()->KN;
        $FUEL = Account::where('transaction_date',$request->transaction_date)->select('accounts.FUEL')->first()->FUEL;
        $PURCH = Account::where('transaction_date',$request->transaction_date)->select('accounts.PURCH')->first()->PURCH;
        $BILTY = Account::where('transaction_date',$request->transaction_date)->select('accounts.BILTY')->first()->BILTY;
        $ENTITY = Account::where('transaction_date',$request->transaction_date)->select('accounts.ENTITY')->first()->ENTITY;
        $SALES = Account::where('transaction_date',$request->transaction_date)->select('accounts.SALES')->first()->SALES;
        $T1 = $DSL + $KN;
        $T2 = $FUEL+ $PURCH + $BILTY + $ENTITY + $SALES;
        $PC = Account::where('transaction_date',$request->transaction_date)->select('accounts.PC')->first()->PC;
        $Grand_Total = ($T1-$T2) + $PC;

        Account::where('transaction_date',$request->transaction_date)->update(
            [
                'DSL'=>$DSL,
                'KN'=>$KN,
                'FUEL'=>$FUEL,
                'PURCH'=>$PURCH,
                'BILTY'=>$BILTY,
                'ENTITY'=>$ENTITY,
                'SALES'=>$SALES,
                'T1'=>$T1,
                'T2'=>$T2,
                'PC'=>$PC,
                'Grand_Total'=>$Grand_Total,
            ]
        );
    }

    public function viewfeedback()
    {
        return view('admin.feedback');
    }
    public function feedbackdata()
    {
        $feedback = DB::table('feedback')->select('feedback.*')->get();
        return DataTables::of($feedback)->make(true);
    }














public function checkrequest(Request $request)
{
    return $request->all();
}























































    public function index(Request $request)
    {
    	return view('admin.index');
    }


 	public function adminreg(Request $request)
    {
    	return view('admin.adminreg');

    }

    public function admincreate(Request $request)
    {

    	$image = $request->file('image');
        $name  = $image->getClientOriginalName();
        $path= 'public/mainweb/images/';
        $image->move($path,$name);
        $imageurl=$path.$name;



        Admin::Create([
         'name' => $request->input('name'),
         'email' => $request->input('email'),
         'contact' => $request->input('contact'),
         'image' => $imageurl,
         'type' =>  $request->input('type'),

        ]);
        return redirect('/adminreg');

    }


    public function getimg(Request $request)
    {
        $image1=DB::table('admin')->select('admin.*')->get();
        return view('admin.showimage',compact('image1'));
    }


    
    

    
    public function Acceptbyadmin(Request $request)
    {
           
        $auth_id1 = Auth::user()->id;
        $order_id=$request->input('O_id1');
        DB::table('orderdetail')
        ->where('id',$order_id )
        ->where('id',$auth_id1)->update([
                'order_status' =>'orderinProgress',
        ]);

    }
      public function deliverbyadmin(Request $request)
    {

        $auth_id1 = Auth::user()->id;
        $order_id=$request->input('O_id1');
        DB::table('orderdetail')
        ->where('id',$order_id )
        ->where('id',$auth_id1)->update([
                'order_status' =>'delivered',
        ]);

    }

     public function Rejectbyadmin(Request $request)
    {
        $auth_id1 = Auth::user()->id;
        $order_id=$request->input('O_id1');
        DB::table('orderdetail')
        ->where('id',$order_id )
        ->where('id',$auth_id1)->update([
                'order_status' =>'Rejected',
                'statusbyadmin' =>'your order has been cancell',
        ]);
    }

    //customer order
    

  
    public function proceedorderbycustomer(Request $request)
    {
        $auth_id1 = Auth::user()->id;
        $order_id=$request->input('O_id1');
        DB::table('orderdetail')
        ->where('id',$order_id )
        ->where('id',$auth_id1)->update([
                'order_status' =>'proceededtoadmin',
        ]);
    }


//end customer

    public function showorder_Admin(Request $request)
    {

        $get=DB::table('orderdetail')->select('orderdetail.*')->where('order_status','proceededtoadmin')->orwhere('order_status','orderinProgress')->orwhere('order_status','Rejected')->orwhere('order_status','delivered')->get();
        return view('admin.showneworder_admin',compact('get'));
    }

    
    
    

    //endadminorder

    


    
}
