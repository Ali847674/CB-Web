<?php

namespace App\Http\Controllers;

use App\Order;
use Illuminate\Http\Request;
use DB;
use Session;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\CreateUploadRequest;

class WebController extends Controller
{
    public function index()
    {
    	return view('index');
    }
    public function track(Request $request)
    {
        $id = $request->search;
        $order = DB::table('orderdetail')->where('id','=',$id)->get();
        return view('track',compact('order'));
    }

    public function about()
    {
    	return view('about');
    }

    public function services()
    {
    	return view('services');
    }

    public function contact()
    {
        return view('contact');
    } 
    public function contacted(Request $request)
    {
        DB::table('feedback')->insert($request->except('_token'));
        return redirect(route('contact'));
    }  
    public function client_request()
    {
        $cities = DB::table('cities')->get(['name','id']);
        $countries = DB::table('countries')->get(['name','id']);
        $payment = DB::table('payment_types')->get(['name','id']);
        return view('/client_request',compact('cities','countries','payment'));
    }
    public function addorder(Request $request)
    {  
        $auth_id = 0;
        $orderid = Order::insertGetId($request->except(['_token','name','quantity']));
        $type = 'CH';
        $id= str_pad($orderid, 4, '0',STR_PAD_LEFT);
        Order::where('id',$orderid)->update([
            'alpha_id'=>$request->date.'/'.$type.'/'.$id,
            'created_id'=>$auth_id,
            'order_status'=>'product',
            'region'=>'DOMESTIC'
        ]);

        for ($i=0; $i < sizeof($request->name) ; $i++)
        { 
            if ($request->name[$i] == null)
            {
                continue;
            }
            else
            {
                $p_id = DB::table('products')->insertGetId([
                    'name'=>$request->name[$i],
                    'quantity'=>$request->quantity[$i]
                ]);
                DB::table('cust_orderdetails')->insert([
                    'order_id'=>$orderid,
                    'product_id'=>$p_id,
                ]);
            }
        }
        return response()->json('success');
    }
    public function addorder1(Request $request)
    {
    
        $auth_id = 0;
        $orderid = Order::insertGetId($request->except(['_token','name','quantity']));
        $type = 'CH';
        $id= str_pad($orderid, 4, '0',STR_PAD_LEFT);
        Order::where('id',$orderid)->update([
            'alpha_id'=>$request->date.'/'.$type.'/'.$id,
            'created_id'=>$auth_id,
            'order_status'=>'product',
            'region'=>'INTERNATIONAL'
        ]);

        for ($i=0; $i < sizeof($request->name) ; $i++)
        { 
            if ($request->name[$i] == null)
            {
                continue;
            }
            else
            {
                $p_id = DB::table('products')->insertGetId([
                    'name'=>$request->name[$i],
                    'quantity'=>$request->quantity[$i]
                ]);
                DB::table('cust_orderdetails')->insert([
                    'order_id'=>$orderid,
                    'product_id'=>$p_id,
                ]);
            }
        }
        return response()->json('success');
    }
    public function careers()
    {
        return view('/careers');
    }
    public function submitcv(Request $request)
    {
        $file = Input::file('file');
        $destinationPath = 'assets/uploads'; // upload path
        $name = $file->getClientOriginalName(); // getting original name
        $extension = $file->getClientOriginalExtension(); // getting fileextension
        $fileName = time(). $name . '.' . $extension; // renaming image
        $file->move($destinationPath,$fileName); // uploading file to given path
        // return $destinationPath . '/' .$fileName ;
        $info = $request->input('info');
        DB::table('careers')->insert([
            'file_path'=>$destinationPath . '/' .$fileName,
            'about'=>$info
        ]);
        Session::flash('File Submitted Successfully','files');
        return redirect('/careers');

    }
}