<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class IndexController extends Controller
{
   
    public function index(Request $request)
    {
    	 $image1=DB::table('admin')->select('admin.*')->get();
            return view('mainweb.index',compact('image1'));


    }

    
    public function getcn(Request $request)
    {
    		$cn=DB::table('cn_table')->select('cn_table.*')->get();
    		return view('mainweb.cnorder',compact('cn'));

    }



}
