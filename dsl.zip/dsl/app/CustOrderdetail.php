<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustOrderdetail extends Model
{
    
    protected $guarded = [];
      protected $table='cust_orderdetails';
       protected $primaryKey='Cd_id';

}
