
<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- banner-text -->
    <!-- ab -->
    <?php echo $__env->yieldContent('headerlinks'); ?>
    <?php echo $__env->yieldContent('headernavigations'); ?>
    <!--// banner-text -->
    <!-- /breadcrumb -->
<!--     <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="index.html">Home</a>
        </li>
        <li class="breadcrumb-item active">About</li>
    </ol> -->
    <!-- //breadcrumb -->
    <!-- banner-bottom-w3ls -->
  <!--   <section class="banner-bottom-w3ls pb-lg-5 pb-md-5 pb-3">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 about-img">
                </div>
                <div class="col-lg-6 about-right">
                    <h4>Who We Are</h4>
                    <h3>We give you complete control of your DSLs.</h3>
                    <p class="my-4">Lorem ipsum dolor sit amet Neque porro quisquam est qui dolorem Lorem int ipsum dolor sit amet when an unknown printer took a galley of type.Vivamus id tempor felis. Cras sagittis mi sit amet malesuada mollis. Mauris porroinit consectetur cursus tortor vel interdum.</p>

                    <ul class="author d-flex">
                        <li><img class="img-fluid" src="assets/site/images/author.jpg" alt=""></li>
                        <li><span>Admin Name</span>Comany Namer</li>
                    </ul>
                    <div class="log-in mt-md-5 mt-3">
                        <a class="btn text-uppercase" href="single.html">
                                    Read More</a>
                    </div>

                </div>
            </div>
        </div>
    </section> -->
    <!-- //banner-bottom-w3ls -->
    <!-- ab -->
<!--     <section class="banner-bottom-w3ls py-lg-5 py-md-5 py-3">
<div class="container">
     <h3 class="tittle text-center mb-md-5 mb-4"> DSL Profile</h3>
     
          <p>
Daily Swipe Logistics, Couriers, COD Service
Daily Swipe Logistics & Courier Service was established in 2018 as a business dedicated to provide a guaranteed safe & secure courier service to commerce and industry.

Daily Swipe Logistics & Courier Service has grown to now provide a comprehensive logistical solution to facilitate our clients' every requirement.
Our business has developed through our reputation for close, personalized working relationships with all our customers, ensuring we always satisfy their needs and expectations.




     </p>
     </div>
 </section> -->


<!-- 
<section class="quick-services">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-4">
                <div class="box text-center">
                    <img src="assets/site/images/feature-01.jpg" class="img-responsive" width="290px" height="200">
                    <h2>DSL GOAL</h2>
                    <p>Our goal rather simple; provide a courier service that is super fast in terms of customer service and delivery time while maintaining cost effectiveness. We believe this sets us apart from other courier service providers.
                    <br><br><br><br><br></p>
                </div>
            </div>
            <div class="col-md-4 col-sm-4">
                <div class="box text-center">
                    <img src="assets/site/images/feature-02.jpg"  class="img-responsive"  width="290px" height="200">
                    <h2>DSL VISION</h2>
                    <p>Our vision is to provide unrivaled courier services to clients around the world through professional approach & delivering in time to all destinations around the world. <br><br><br><br><br><br><br></p>
                </div>
            </div>
            <div class="col-md-4 col-sm-4">
                <div class="box text-center">
                    <img src="assets/site/images/feature-03.jpg" class="img-responsive"  width="290px" height="200">
                    <h2>DSL MISSION</h2>
                    <p>DSL Courier Group is committed to providing first-class messenger services to its 24/7 with reasonable rates on a consistent basis. We enable our customers to prosper by delivering their products on time in a professional manner. We will continuously challenge ourselves to exceed our customers’ expectations by providing leading edge solutions to their needs.</p>
                </div>
            </div>
        </div>
   </div>
</section>
 -->

    <!-- /breadcrumb -->
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="/">Home</a>
        </li>
        <li class="breadcrumb-item active">About</li>
    </ol>
    <!-- //breadcrumb -->


<section class="about-section">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <h2>About our company</h2>
                <p>Daily Swipe Logistics, Couriers, COD Service
Daily Swipe Logistics & Courier Service was established in 2018 as a business dedicated to provide a guaranteed safe & secure courier service to commerce and industry.

Daily Swipe Logistics & Courier Service has grown to now provide a comprehensive logistical solution to facilitate our clients' every requirement.
Our business has developed through our reputation for close, personalized working relationships with all our customers, ensuring we always satisfy their needs and expectations.</p>
            </div>
            <div class="col-md-6 pull-right image-sec">
                <img src="assets/site/images/about-banner.jpg" class="img-responsive">
            </div>
        </div>
    </div>
</section>


<section class="banner-bottom-w3ls bg-dark py-lg-5 py-md-5 py-3 aboutvgm">
        <div class="container">
            <div class="inner-sec-w3layouts py-lg-5 py-3">
                <h3 class="tittle text-center text-white mb-md-5 mb-4"> &nbsp</h3>
                <div class="row middle-grids">
                    <div class="col-lg-4 about-in middle-grid-info text-center">
                        <div class="card">
                            <div class="card-body">
                                <img src="assets/site/images/feature-01.jpg" class="img-responsive" width="290px" height="200">                                
                                <h5 class="card-title my-3">DSL GOAL</h5>
                                <p>Our goal rather simple; provide a courier service that is super fast in terms of customer service and delivery time while maintaining cost effectiveness. We believe this sets us apart from other courier service providers.
                                <br><br><br><br><br></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 about-in middle-grid-info text-center">
                        <div class="card">
                            <div class="card-body">
                            <img src="assets/site/images/feature-02.jpg" class="img-responsive" width="290px" height="200">  
                                <h5 class="card-title my-3">DSL VISION</h5>
                    <p>Our vision is to provide unrivaled courier services to clients around the world through professional approach & delivering in time to all destinations around the world. <br><br><br><br><br><br></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 about-in middle-grid-info text-center">
                        <div class="card">
                            <div class="card-body">
                             <img src="assets/site/images/feature-03.jpg" class="img-responsive" width="290px" height="200">  
                                <h5 class="card-title my-3">DSL MISSION</h5>
                    <p>DSL Courier Group is committed to providing first-class messenger services to its 24/7 with reasonable rates on a consistent basis. We enable our customers to prosper by delivering their products on time in a professional manner. We will continuously challenge ourselves to exceed our customers’ expectations by providing leading edge solutions to their needs.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    