<?php $__env->startSection('body'); ?>
<div class="portlet-body " >
    <form  class="form-horizontal"  method="post" action="<?php echo e(url('/addcustomer')); ?>" >

        <?php echo e(csrf_field()); ?>

        <div class="form-body">
           <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <div class="col-md-6">
                    <?php if(Session::has('fields')): ?>
                    <span class="myclass">*<?php echo e(session('fields')); ?></span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                <label for="name" class="col-md-4 control-label">Name</label>
                <div class="col-md-4">
                    <input id="name" type="text" value="<?php echo e(old('name')); ?>" class="form-control" name="name" required autofocus>
                </div>
            </div>

            
            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <label for="email" class="col-md-4 control-label">Email</label>
                <div class="col-md-4">
                    <input id="email" type="email" value="<?php echo e(old('email')); ?>" class="form-control" name="email" required >
                    <?php if(Session::has('email')): ?>
                        <span class="myclass">*<?php echo e(session('email')); ?></span>
                    <?php endif; ?>

                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('contact') ? ' has-error' : ''); ?>">
                <label for="contact" class="col-md-4 control-label">Contact</label>
                <div class="col-md-4">
                    <input id="contact" type="text" value="<?php echo e(old('contact')); ?>" class="form-control" name="contact" required>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('contact') ? ' has-error' : ''); ?>">
                <label for="contact" class="col-md-4 control-label">Origin City</label>
                <div class="col-md-4">
                    <select name="city_id" class="form-control">
                        <option disabled selected value>Select City</option>
                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('contact') ? ' has-error' : ''); ?>">
                <label for="contact" class="col-md-4 control-label">Address</label>
                <div class="col-md-4">
                    <input id="contact" type="text" value="<?php echo e(old('address')); ?>" class="form-control" name="address" required>
                </div>
            </div>


            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                <label for="password" class="col-md-4 control-label">Password</label>
                <div class="col-md-4">
                    <input id="password" minlength="6" maxlength="8" type="password" class="form-control" name="password" required autofocus>
                </div>
            </div>


            <div class="form-actions">
                <div class="row">
                    <div class="col-md-4">
                        <div class="row">
                            <div class="col-md-offset-11 col-md-9">
                                <button type="Submit"  class="btn btn-success">Submit</button>
                                <button type="button" class="btn default" >Cancel</button>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </form>
</div>  

<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>

    <script type="text/javascript">
        $("document").ready(function()
        {
            setTimeout(function()
            {
               $(".myclass").remove();
            }, 5000 );

        });

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>