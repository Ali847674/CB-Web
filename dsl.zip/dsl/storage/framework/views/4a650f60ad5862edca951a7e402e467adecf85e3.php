
<?php $__env->startSection('body'); ?>
        <span href=""  class="btn btn-success proceedorder1" >Booked</span>
        <span href=""  class="btn btn-warning proceedorder2" >At DSL</span>
        <span href=""  class="btn btn-danger proceedorder3" >In Transit</span>
        <span href=""  class="btn btn-primary proceedorder4" >Out For Delivery</span>

        
            <div class="portlet-body form">
                <input type="hidden" id="useful">
                <br><br>
                <div class="portlet-body" id="items">
                    <div class="table-scrollable">
                        <table class="table table-hover table-light" id="myTable">
                            <thead>
                                <tr>
                                    <th>Order Code</th>
                                    <th>Orderdate</th>
                                    <th>Customer Name</th>
                                    
                                    <th>Destination</th>
                                    <th>Status</th>
                                    <th>Activity</th>
                                </tr>
                            </thead>
                        </table>
                    </div>  
                </div>
            </div>
        

            <!--begin::Add Modal-->
                <div class="modal fade" id="productmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">
                                Add Product To Order
                                </h5>
                            </div>
                            <div class="modal-body">

                                <form id="product" class="form-horizontal" method="POST" style="padding: 20px;" enctype="multipart/form-data">


                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-body">
                                                                              
        
                                            
                                            <div class="col-md-9">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-4">
                                                        Product name
                                                    </label>
                                                    <div class="col-md-8">
                                                        <input type="text" class="form-control" name="name" id="name" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-9">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-9">
                                                        *All Fields Are In CM Unit 
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-1">
                                                        Width
                                                    </label>
                                                    <div class="col-md-3">
                                                        <input type="number" min="1" max="1000" class="form-control" name="width" id="width" >
                                                    </div>
                                                
                                                    <label class="control-label col-md-1">
                                                        Length
                                                    </label>
                                                    <div class="col-md-3">
                                                        <input type="number" min="1" max="1000" class="form-control" name="length" id="length" >
                                                    </div>
                                                    <label class="control-label col-md-1">
                                                        Height
                                                    </label>
                                                    <div class="col-md-3">
                                                        <input type="number" min="1" max="1000" class="form-control" name="height" id="height" >
                                                    </div>
                                                </div>
                                            </div>

                                             <div class="col-md-9">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-4">
                                                        Dimension Weight
                                                    </label>
                                                    <div class="col-md-8">
                                                        <input type="number" min="1" max="1000" class="form-control" name="dimensional_weight" id="dimensional_weight" >
                                                    </div>
                                                </div>
                                            </div>

                                             <div class="col-md-9">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-4">
                                                        Type
                                                    </label>
                                                    <div class="col-md-8">
                                                        <input type="text" class="form-control" name="type" id="type" >
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="col-md-9">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-4">
                                                        Quantity
                                                    </label>
                                                    <div class="col-md-8">
                                                        <input type="number" min="1" max="1000" class="form-control" name="quantity" id="quantity" >
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="col-md-9">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-4">
                                                        Amount Per Piece
                                                    </label>
                                                    <div class="col-md-8">
                                                        <input type="number" min="1" max="1000" class="form-control" name="amount_pc" id="amount_pc" >
                                                    </div>
                                                </div>
                                            </div>
                                            <input type="hidden" name="status" value="product">
                                    </div>
                                <div class="modal-footer">
                            
                                <div class="form-actions">
                                    <div class="row">
                                        <div class="col-md-9">
                                            <div class="row">
                                                <div class="col-md-offset-3 col-md-9">
                                                    <button type="submit" class="btn green addproduct1">Submit</button>
                                                    <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6"> </div>
                                    </div>
                            </div>
                                </div>
                            </form>
                            <!-- END FORM-->

                            </div>
                            
                        </div>
                    </div>
                </div>
            <!--end:: Add Modal-->

            <!--begin::Show Modal-->
                        <div class="modal fade" id="showmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">
                                            Added Products
                                        </h5>
                                    </div>
                                    <div class="modal-body">
                                        <table class="table table-scrollable">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Quantity</th>
                                                    <th>Amount/Piece</th>
                                                    
                                                </tr>
                                            </thead>
                                            <tbody id="pbody">
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="modal-footer">

                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-offset-3 col-md-9">
                                                            
                                                            <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6"> </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
            <!--end:: Show Modal-->

            <!-- begin:: Proceed Modal -->
                <div class="modal fade" id="proceedmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Proceed To Next</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <center>
                            All Product Added To The Order?
                            <h3>Once Proceed Cannot Be Revert</h3>
                        </center>
                      </div>
                      <div class="modal-footer">
                        <form method="post" action="<?php echo e(route('proceed')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" id="order_id2">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success">Proceed</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
            <!-- end:: Proceed Modal -->

            <!-- begin:: Delete Product Modal -->
                <div class="modal fade" id="deleteproductmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Remove Product From Order</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <center>
                            Do You Want To Remove Product From Order?
                            <h3>Once Proceed Cannot Be Revert</h3>
                        </center>
                      </div>
                      <div class="modal-footer">
                        <form method="post" id="productdelete">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="order_id"   id="o_id">
                            <input type="hidden" name="product_id" id="p_id">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success"   >Proceed</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
            <!-- end:: Delete Product Modal -->


            <!--begin:: Show Product Detail Modal-->
                        <div class="modal fade" id="detailmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">
                                            Added Products
                                        </h5>
                                    </div>
                                    <div class="modal-body">
                                        <table class="table table-scrollable">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Length</th>
                                                    <th>Width</th>
                                                    <th>Height</th>
                                                    <th>Dimensional Weight</th>
                                                    <th>Quantity</th>
                                                    <th>Amount/Piece</th>
                                                    
                                                </tr>
                                            </thead>
                                            <tbody id="pdbody">
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="modal-footer">

                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-offset-3 col-md-9">
                                                            
                                                            <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6"> </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
            <!--end:: Show Product Detail Modal-->






<?php $__env->stopSection(); ?>


 <?php $__env->startSection('script'); ?>
    
        <script type="text/javascript">
        
        $(document).ready(function()
        {
            $(document).on('click','.proceedorder1',function(event)
            {   
                event.preventDefault();
                 $('#myTable').DataTable().destroy();
                $('#myTable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "ajax": "<?php echo e(route('proceedorder1')); ?>",
                    "columns":[
                        { "data": "ordercode" },
                        { "data": "date" },
                        { "data": "sender_name" },
                        // { "data": "name1"},
                        { "data": "name2"},
                        { "data": "activity"},
                        { "data": "status"},
                        // { "data": "action"},
                    ]
                });
            });
            $(document).on('click','.proceedorder2',function(event)
            {   
                event.preventDefault();
                 $('#myTable').DataTable().destroy();
                $('#myTable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "ajax": "<?php echo e(route('proceedorder2')); ?>",
                    "columns":[
                        { "data": "ordercode" },
                        { "data": "date" },
                        { "data": "sender_name" },
                        // { "data": "name1"},
                        { "data": "name2"},
                        { "data": "status"},
                        { "data": "activity"},
                        // { "data": "action"},
                    ]
                });
            });
            $(document).on('click','.proceedorder3',function(event)
            {   
                event.preventDefault();
                 $('#myTable').DataTable().destroy();
                $('#myTable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "ajax": "<?php echo e(route('proceedorder3')); ?>",
                    "columns":[
                        { "data": "ordercode" },
                        { "data": "date" },
                        { "data": "sender_name" },
                        // { "data": "name1"},
                        { "data": "name2"},
                        { "data": "status"},
                        { "data": "activity"},
                        // { "data": "action"},
                    ]
                });
            });
            $(document).on('click','.proceedorder4',function(event)
            {   
                event.preventDefault();
                 $('#myTable').DataTable().destroy();
                $('#myTable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "ajax": "<?php echo e(route('proceedorder4')); ?>",
                    "columns":[
                        { "data": "ordercode" },
                        { "data": "date" },
                        { "data": "sender_name" },
                        // { "data": "name1"},
                        { "data": "name2"},
                        { "data": "status"},
                        { "data": "activity"},
                        // { "data": "action"},
                    ]
                });
            });
        });

        $(document).ready(function()
        {
            $(document).on('change select','.status_select',function()
            {
                console.log('status val: '+$(this).val());
                $('#statusid').val($(this).val());
                console.log('stausId:: '+$('#statusid').val());
            })
            $(document).on('submit','#statusform',function(event){
                console.log('Hello');
                event.preventDefault();
                var check =  $('#statusid').val();
                var formdata = $('#statusform').serialize();
                $.ajax({
                    url: '<?php echo e(url('/changestatus')); ?>',
                    type:'POST',
                    data: formdata,
                    success:function(data){
                        if (check == 1)
                        {
                            $('.proceedorder1').click();
                        }
                        else if (check == 2)
                        {
                            $('.proceedorder2').click();
                        }
                        else if (check == 3)
                        {
                            $('.proceedorder3').click();
                        }
                        else if (check == 4)
                        {
                            $('.proceedorder4').click();
                        }
                    },
                    error:function(){

                    }
                })
            })

            $(document).on('click','.showproduct',function(){
                var key = $(this).attr('id');
                console.log('Id'+key);

                var id = $(this).data('id');
                console.log('ID: '+id);
                $.ajax({
                    'type': 'POST',
                    'url' : "<?php echo e(route('showproduct')); ?>",
                    'data': {
                        'id':id,
                        '_token':$('input[name=_token]').val()
                    },
                    success:function(data)
                    {

                        console.log('Data: \n'+data);
                        data = JSON.parse(data,true);
                        console.log('Data: \n'+data);
                        var html  = '';
                        $('#pbody').html(html);
                        for(var i=0; i<data.length; i++)
                        {
                            console.log('i')
                            console.log(i);
                            html+= '<tr>';
                            html+= '<td><button class="btn-xs btn-primary pname" data-p_id="'+ data[i]['p_id'] +'" </button>'+data[i]['name']+'</td>';
                            html+= '<td>'+data[i]['quantity']+'</td>';
                            html+= '<td>'+data[i]['amount_pc']+'</td>';
                            // html+= '<td><button class="btn-xs btn-warning updatebtn" data-id="'+ id + '" data-p_id="'+ data[i]['p_id'] +'"> Update </button></td>';
                            // html+= '<td><button class="btn-xs btn-danger removebtn" data-id="'+  id + '" data-p_id="'+ data[i]['p_id'] +'"> Remove</button></td>';
                            html+= '</tr>';
                        }
                        $('#pbody').append(html);
                        $('#useful').val(key);
                    },
                    error:function()
                    {
                        toastr.error('Server Down!', 'Error Alert', {timeOut: 5000});
                    }
                });
            });

            $(document).on('click','.removebtn',function()
            {
                console.log('remove btn');
                $('#showmodal').modal('toggle');
                $('#deleteproductmodal').modal('show');
                $('#o_id').val($(this).data('id'));
                $('#p_id').val($(this).data('p_id'));
                
                
            });
            $(document).on('click','.pname',function()
            {
                console.log('name btn');
                // $('#showmodal').modal('toggle');
                $('#detailmodal').modal('show');
                var p_id = $(this).data('p_id');

                $.ajax({
                    url:"<?php echo e(route('productdetail')); ?>",
                    type:"GET",
                    data:{
                        // "_token":$('input[name=_token]'),
                        "id":p_id
                    },
                    success:function(data)
                    {
                        console.log('Data: \n'+ data);
                        data = JSON.parse(data,true);
                        console.log('Data: \n'+ data);
                        var html  = '';
                        $('#pdbody').html(html);
                            // console.log('i:'+i);
                            html+= '<tr>';
                            html+= '<td>' +data[0]['name']+ '</td>';
                            html+= '<td>' +data[0]['length'] +'</td>';
                            html+= '<td>' +data[0]['width']+ '</td>';
                            html+= '<td>' +data[0]['height'] +'</td>';
                            html+= '<td>' +data[0]['dimensional_weight'] +'</td>';
                            html+= '<td>' +data[0]['quantity'] +'</td>';
                            html+= '<td>' +data[0]['amount_pc'] +'</td>';
                            html+= '</tr>';
                            $('#pdbody').append(html);
                    }
                });
            });


            $(document).on('submit','#productdelete',function(event)
            {
                event.preventDefault();
                var butonclk = $('#useful').val();
                var o_id = $('#o_id').val();
                var p_id = $('#p_id').val();
                $.ajax({
                    url: '<?php echo e(route('deleteproduct')); ?>',
                    type: 'POST',
                    data: {
                        _token  :$('input[name=_token]').val(), 
                        o_id    : o_id,
                        p_id    : p_id
                    },
                    success:function(data)
                    {

                        console.log('Data: \n'+data);
                        data = JSON.parse(data,true);
                        console.log('Data: \n'+data);
                        var html  = '';
                        $('#pbody').html(html);
                        for(var i=0; i<data.length; i++)
                        {
                            console.log('i')
                            console.log(i);
                            html+= '<tr>';
                            html+= '<td>'+data[i]['name']+'</td>';
                            html+= '<td>'+data[i]['quantity']+'</td>';
                            html+= '<td>'+data[i]['amount_pc']+'</td>';
                            // html+= '<td><button class="btn-xs btn-warning updatebtn" data-id="'+ id + '" data-p_id="'+ data[i]['p_id'] +'"> Update </button></td>';
                            html+= '<td><button class="btn-xs btn-danger removebtn" data-id="'+  o_id + '" data-p_id="'+ data[i]['p_id'] +'"> Remove</button></td>';
                            html+= '</tr>';
                        }
                        $('#pbody').append(html);
                        toastr.success('Product Remove From Order','Success Alert', {timeOut: 3000});
                        $("#deleteproductmodal .close").click();
                        $('#'+butonclk).click();

                    },
                });
            })

            $(document).on('click','.addproductmodal',function()
            {
                $('#order_id').val($(this).data('id'));
            });
            $(document).on('click','.proceedbtn',function()
            {
                console.log($(this).data('id'));
                $('#order_id2').val($(this).data('id'));
            });


            $(document).on('click','.proceed',function()
            {

                   console.log($(this).data('id'));
                   $.ajax
                   ({
                        type:'put',
                        url:'proceedorder',
                        data:{
                            '_token': $('input[name=_token]').val(),
                            'O_id1' :$(this).data('id'),
                        },
                        success: function(reponse)
                        {
                            toastr.success('Successfully Updated!', 'Success Alert', {timeOut: 5000});
                            setTimeout(function(){}, 1000);
                            location.reload();
                        },
                        error : function(error) 
                        {

                          toastr.error('error Bill!', 'Success Alert', {timeOut: 5000});
                        }
                    });
            });

            $(document).on('submit','#product',function(event)
            {
                    event.preventDefault();
                    var formdata = $('#product').serialize();
                    console.log(formdata);
                    console.log($('#order_id').val()); 
                    console.log($('#p_name').val()); 
                    console.log($('#weight').val()); 
                    console.log($('#dimemsion').val()); 

                    $.ajax
                    ({
                        'type':     'POST',
                        'url':      'AddProduct',
                        'data':     formdata,
                        success: function(reponse)
                        {
                            toastr.success('Product Successfully Added !', 'Success Alert', {timeOut: 5000});
                            setTimeout(function(){}, 1000);
                            location.reload();
                        },
                        error : function(error)
                        {
                            toastr.error('Server Down!', 'Error Alert', {timeOut: 5000});
                        }
                    });
            });

        }); 
        </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>