<?php $__env->startSection('body'); ?>
    <style>
                *
                {

                    font-family: roboto;
                    font-size: 15px;
                }
                table, td, th {
                  border: 1px solid black;
                }

                table {
                  border-collapse: collapse;
                  width: 100%;
                }

                th {
                  text-align: left;
                }

                td
                {
                  text-align: center;
                }

                img.imgbar {
                    width: 314px;
                }

                td.rightside {
                    text-align: right;
                }

                td.leftside {
                    text-align: left;
                }

                td.test {
                    width: 70px;
                }

                p.tac {
                    font-size: 20px;
                    margin-top: 5px;
                    margin-bottom: 5px;
                }
                ul.ultac {
                    padding-left: 18px;
                    margin-top: 0px;
                }
    </style>  
        
        <br><br><br>
        
            <div class="portlet-body form">
                <input type="hidden" id="useful">
                <div class="portlet-body" id="items">
                    <div class="table-scrollable">
                        <table class="table table-hover table-light" id="myTable">
                            <thead>
                                <tr>
                                    <th>Order Code</th>
                                    <th>Orderdate</th>
                                    <th>Customer Name</th>
                                    <th>Origin</th>
                                    <th>Destination</th>
                                    <th>Activity</th>
                                </tr>
                            </thead>
                            <tbody id="orderbody">
                            </tbody>
                        </table>
                    </div>  
                </div>
            </div>
        
        
            

          

            <!--begin::show Modal-->
                        <div class="modal fade" id="showmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">
                                            Added Products
                                        </h5>
                                    </div>
                                    <div class="modal-body">
                                        <table class="table table-scrollable">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Quantity</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody id="pbody">
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="modal-footer">

                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-offset-3 col-md-9">
                                                            
                                                            <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6"> </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
            <!--end::Show modal-->

            <!--begin:: proceed Modal -->
                <div class="modal fade" id="proceedmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Proceed To Next</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <center>
                            All Product Added To The Order?
                            <h3>Once Proceed Cannot Be Revert</h3>
                        </center>
                      </div>
                      <div class="modal-footer">
                        <form id="proceedform">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" id="order_id2">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success">Proceed</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
            <!--end:: proceed Modal -->

            <!--begin:: Delete product modal -->
                <div class="modal fade" id="deleteproductmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Remove Product From Order</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <center>
                            Do You Want To Remove Product From Order?
                            <h3>Once Proceed Cannot Be Revert</h3>
                        </center>
                      </div>
                      <div class="modal-footer">
                        <form method="post" id="productdelete">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="order_id"   id="o_id">
                            <input type="hidden" name="product_id" id="p_id">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success"   >Proceed</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
            <!--end:: delete product Modal -->


            <!--begin:: Delete order modal -->
                <div class="modal fade" id="deleteorder" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Delete The Current Order</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <center>
                            <h2>Do You Want To Delete This Order?</h2>
                            <h3>Once Proceed Cannot Be Revert</h3>
                        </center>
                      </div>
                      <div class="modal-footer">
                        <form method="get" id="orderdelete">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="order_id" id="o_id2">
                            <input type="hidden" id="mytyped">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-danger"   >Delete</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
            <!--end:: delete order Modal -->

            <!--begin::add city Modal-->
                <div class="modal fade" id="citymodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">
                                    Add New City
                                </h5>
                            </div>
                            <div class="modal-body">
                                <form id="city" class="form-horizontal" method="POST" style="padding: 20px;" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-body">
                                        <div class="col-md-9">
                                            <div class="form-group ">
                                                <label class="control-label col-md-4">
                                                    City Name
                                                </label>
                                                <div class="col-md-8">
                                                    <input type="text" placeholder="City Name" class="form-control" name="name" id="name" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-9">
                                            <div class="form-group ">
                                                <label class="control-label col-md-4">
                                                    City Acronym
                                                </label>
                                                <div class="col-md-8">
                                                    <input type="text" minlength="3" maxlength="4" placeholder="3 - 4 Letter Short Name" class="form-control" name="acr" id="acr" required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">

                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-offset-3 col-md-9">
                                                            <button type="submit" class="btn green addproduct1">Submit</button>
                                                            <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6"> </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <!--end::Add city Modal-->






<?php $__env->stopSection(); ?>


 <?php $__env->startSection('script'); ?>
    
        <script type="text/javascript">
            $(document).ready(function()
            {
                $('#myTable').DataTable().destroy();
                $('#myTable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "ajax": "<?php echo e(route('internationalorders')); ?>",
                    "columns":[
                    { "data": "ordercode" },
                    { "data": "date" },
                    { "data": "sender_name" },
                    { "data": "origin"},
                    { "data": "name2"},
                    { "data": "status"},
                    ]
                });
            });

            jQuery(document).ready(function()
            {
                var i =1;
                $(document).on('click', '.replica', function()
                {
                    i++;
                    var html = '';
                    html+= '<div class=" row' +i+ ' col-md-12" >';
                    html+= '<label class="control-label col-md-1">Name</label><div class="col-md-3"><input type="text" class="form-control" name="name[]" id="name" required></div>';
                    html+= '<label class="control-label col-md-1">Quantity</label><div class="col-md-3"><input type="number" class="form-control" name="quantity[]" id="name" required></div>';
                    html+= '<div class="col-md-2"><button type="button" class="btn-xs btn-success replica">Add More</button></div>';
                    html+= '<div class="col-md-2"><button id="' +i+ '" type="button" class="btn-xs btn-danger btn_remove">X</button></div>';
                    html+= '</div>';
                    $('#productreplica').append(html);
                });
                $(document).on('click', '.btn_remove', function()
                {
                    console.log('Hello');
                    var id = $(this).attr('id');
                    console.log(id);
                    $('.row'+id).remove();
                })
            });


            $(document).ready(function()
            {
                var gstamounts = 0;
                $(document).on('change paste keyup keypress keydown','#field1a', function()
                {
                    var a = $(this).val();
                    var b = gstamounts;
                    var c = $('#field3a').val();

                    var d = ((+a)+(+gstamounts))-(+c);
                    $('#field4a').val(d);
                });

                // GST Calculation
                $(document).on('change paste keyup keypress keydown','#field2a', function()
                {
                    var a = $(this).val();
                    var b = $('#field1a').val();
                    var c = $('#field3a').val();

                    gstamounts = ((+a)*(+b))/100;
                    var d  = ((+b) + (+gstamounts)) - (+c); 
                    $('#field4a').val(d);
                });
                $(document).on('change paste keyup keypress keydown','#field3a', function()
                {
                    var a = $(this).val();
                    var b = $('#field1a').val();
                    var c = gstamounts;

                    var d  = ((+b) + (+gstamounts)) - (+a);
                    $('#field4a').val(d);
                });
            });

            $(document).ready(function()
            {

                $("#myInput").on("keyup", function()
                {
                    console.log('Search');
                    var value = $(this).val().toLowerCase();
                    $("#myTable tr").filter(function()
                    {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });

                $(document).on('click','.showproduct',function(){
                    var key = $(this).attr('id');
                    console.log('Id'+key);

                    var id = $(this).data('id');
                    console.log('ID: '+id);
                    $.ajax({
                        'type': 'POST',
                        'url' : "<?php echo e(route('showproduct')); ?>",
                        'data': {
                            'id':id,
                            '_token':$('input[name=_token]').val()
                        },
                        success:function(data)
                        {

                            console.log('Data: \n'+data);
                            data = JSON.parse(data,true);
                            console.log('Data: \n'+data);
                            var html  = '';
                            $('#pbody').html(html);
                            for(var i=0; i<data.length; i++)
                            {
                                console.log('i')
                                console.log(i);
                                html+= '<tr>';
                                html+= '<td><button class="btn-xs btn-primary pname" data-p_id="'+ data[i]['p_id'] +'" </button>'+data[i]['name']+'</td>';
                                html+= '<td>'+data[i]['quantity']+'</td>';
                            // html+= '<td>'+data[i]['amount_pc']+'</td>';
                            // html+= '<td><button class="btn-xs btn-warning updatebtn" data-id="'+ id + '" data-p_id="'+ data[i]['p_id'] +'"> Update </button></td>';
                            html+= '<td><button class="btn-xs btn-danger removebtn" data-id="'+  id + '" data-p_id="'+ data[i]['p_id'] +'"> Remove</button></td>';
                            html+= '</tr>';
                        }
                        $('#pbody').append(html);
                        $('#useful').val(key);
                    },
                    error:function()
                    {
                        toastr.error('Server Down!', 'Error Alert', {timeOut: 5000});
                    }
                });
                });

                $(document).on('click','.removebtn',function()
                {
                    console.log('remove btn');
                    $('#showmodal').modal('toggle');
                    $('#deleteproductmodal').modal('show');
                    $('#o_id').val($(this).data('id'));
                    $('#p_id').val($(this).data('p_id'));

                });
                $(document).on('click','.pname',function()
                {
                    console.log('name btn');
                // $('#showmodal').modal('toggle');
                $('#detailmodal').modal('show');
                var p_id = $(this).data('p_id');

                $.ajax({
                    url:"<?php echo e(route('productdetail')); ?>",
                    type:"GET",
                    data:{
                        // "_token":$('input[name=_token]'),
                        "id":p_id
                    },
                    success:function(data)
                    {
                        console.log('Data: \n'+ data);
                        data = JSON.parse(data,true);
                        console.log('Data: \n'+ data);
                        var html  = '';
                        $('#pdbody').html(html);
                            // console.log('i:'+i);
                            html+= '<tr>';
                            html+= '<td>' +data[0]['name']+ '</td>';
                            html+= '<td>' +data[0]['length'] +'</td>';
                            html+= '<td>' +data[0]['width']+ '</td>';
                            html+= '<td>' +data[0]['height'] +'</td>';
                            html+= '<td>' +data[0]['dimensional_weight'] +'</td>';
                            html+= '<td>' +data[0]['quantity'] +'</td>';
                            html+= '<td>' +data[0]['amount_pc'] +'</td>';
                            html+= '</tr>';
                            $('#pdbody').append(html);
                        }
                    });
            });


                $(document).on('submit','#productdelete',function(event)
                {
                    event.preventDefault();
                    var butonclk = $('#useful').val();
                    var o_id = $('#o_id').val();
                    var p_id = $('#p_id').val();
                    $.ajax({
                        url: '<?php echo e(route('deleteproduct')); ?>',
                        type: 'POST',
                        data: {
                            _token  :$('input[name=_token]').val(), 
                            o_id    : o_id,
                            p_id    : p_id
                        },
                        success:function(data)
                        {

                            console.log('Data: \n'+data);
                            data = JSON.parse(data,true);
                            console.log('Data: \n'+data);
                            var html  = '';
                            $('#pbody').html(html);
                            console.log('Data Length'+ data.length);
                            if(data.length == 0)
                            {
                                $.ajax({
                                    url: '<?php echo e(route('changestatuspending')); ?>',
                                    type: 'POST',
                                    data: {
                                        _token  :$('input[name=_token]').val(), 
                                        id    : o_id
                                    },
                                    success:function()
                                    {
                                        $("#deleteproductmodal .close").click();
                                        $('.productorders').click();
                                    }
                                })
                            }
                            else
                            {
                                for(var i=0; i<data.length; i++)
                                {
                                    console.log('i')
                                    console.log(i);
                                    html+= '<tr>';
                                    html+= '<td>'+data[i]['name']+'</td>';
                                    html+= '<td>'+data[i]['quantity']+'</td>';
                                    html+= '<td>'+data[i]['amount_pc']+'</td>';
                                // html+= '<td><button class="btn-xs btn-warning updatebtn" data-id="'+ id + '" data-p_id="'+ data[i]['p_id'] +'"> Update </button></td>';
                                html+= '<td><button class="btn-xs btn-danger removebtn" data-id="'+  o_id + '" data-p_id="'+ data[i]['p_id'] +'"> Remove</button></td>';
                                html+= '</tr>';
                            }
                            $('#pbody').append(html);
                            toastr.success('Product Remove From Order','Success Alert', {timeOut: 3000});
                            $("#deleteproductmodal .close").click();
                            console.log('butonclk: '+butonclk);
                            $('#'+butonclk).click();
                        }

                    },
                    });
                })


                $(document).on('click','.addproductmodal',function()
                {
                    $('#order_id').val($(this).data('id'));
                });

                $(document).on('click','.proceedbtn',function()
                {
                    console.log($(this).data('id'));
                    $('#order_id2').val($(this).data('id'));
                });


                $(document).on('click','.proceed',function()
                {

                 console.log($(this).data('id'));
                 $.ajax
                 ({
                    type:'put',
                    url:'proceedorder',
                    data:{
                        '_token': $('input[name=_token]').val(),
                        'O_id1' :$(this).data('id'),
                    },
                    success: function(reponse)
                    {
                        toastr.success('Successfully Updated !', 'Success Alert', {timeOut: 5000});
                        setTimeout(function(){}, 1000);
                        $('.productorders').click();
                    },
                    error : function(error) 
                    {

                      toastr.error('Error Occurred!', 'Error Alert', {timeOut: 5000});
                  }
              });
             });

                $(document).on('submit','#product',function(event)
                {
                    event.preventDefault();
                    var formdata = $('#product').serialize();
                    console.log(formdata);
                    console.log($('#order_id').val()); 
                    console.log($('#p_name').val()); 
                    console.log($('#weight').val()); 
                    console.log($('#dimemsion').val()); 

                    $.ajax
                    ({
                        'type':     'POST',
                        'url':      'AddProduct',
                        'data':     formdata,
                        success: function(reponse)
                        {
                            toastr.success('Product Successfully Added !', 'Success Alert', {timeOut: 5000});
                            setTimeout(function(){}, 1000);
                            $('.productorders').click();
                        },
                        error : function(error)
                        {
                            toastr.error('Server Down!', 'Error Alert', {timeOut: 5000});
                        }
                    });
                });

                $(document).on('click','.citymodal',function()
                {
                    $('#citymodal').modal('show');
                });

                $(document).on('submit','#city',function(event)
                {
                    event.preventDefault();
                    var data = $(this).serialize();
                    console.log(data);
                    $(this).serialize();
                    $.ajax({
                        url: "<?php echo e(route('addcity')); ?>",
                        type: "POST",
                        data: {
                            '_token':$('input[name=_token]').val(),
                            'name':$('#name').val(),
                            'acr':$('#acr').val()
                        },
                        success:function(data)
                        {
                            if (data == 'name')
                            {
                                toastr.error('City With Same Name Already Exist','Error Alert');
                            }
                            else if (data == 'acr')
                            {
                                toastr.error('City With Same Acronym Already Exist','Error Alert');
                            }
                            else
                            {
                                console.log(data);
                                toastr.success('New City Added Successfully','Success Alert');
                                $('#city1').append(' <option value="' + data + ' "> ' + $('#name').val() + ' </option> ');
                                $('#city2').append(' <option value="' + data + ' "> ' + $('#name').val() + ' </option> ');
                            }

                        },
                        error:function()
                        {
                            toastr.error('Server Down','Error Alert');
                        }
                    });
                });

                $(document).on('click', '.deleteorderbtn', function()
                {
                    $('#o_id2').val( $(this).data('id') );
                    $('#mytyped').val( $(this).data('mytype') );
                });

               

                $(document).on('submit','#orderdelete',function(event)
                {
                    event.preventDefault();
                    var formdata = $('#orderdelete').serialize();
                    console.log(formdata);
                    console.log($('#o_id2').val()); 
                    var mytype = $('#mytyped').val();
                    console.log('mytype'+ mytype);
                    $.ajax
                    ({
                        'type':     'GET',
                        'url':      '<?php echo e(route('deleteorder')); ?>',
                        'data':     formdata,
                        success: function(reponse)
                        {
                            toastr.success('Order Successfully Deleted !', 'Success Alert', {timeOut: 5000});
                            setTimeout(function(){}, 1000);
                            $('#deleteorder').modal('hide');
                            if (mytype == 0)
                            {
                                $('.productorders').click();
                            }
                            else if (mytype == 1)
                            {
                                $('.productorders').click();
                            }
                            
                        },
                        error : function(error)
                        {
                            toastr.error('Server Down!', 'Error Alert', {timeOut: 5000});
                        }
                    });
                });

                

                $(document).on('submit','#proceedform',function(event)
                {
                    event.preventDefault();
                    var formdata = $('#proceedform').serialize();
                    console.log(formdata);
                    console.log($('#order_id2').val());
                    $.ajax
                    ({
                        'type':     'POST',
                        'url':      '<?php echo e(route('proceed')); ?>',
                        'data':     formdata,
                        success: function(reponse)
                        {
                            toastr.success('Order Successfully Proceeded !', 'Success Alert', {timeOut: 5000});
                            setTimeout(function(){}, 1000);
                            $('#proceedmodal').modal('hide');
                            $('.productorders').click();
                            
                        },
                        error : function(error)
                        {
                            toastr.error('Server Down!', 'Error Alert', {timeOut: 5000});
                        }
                    });
                });

                
            }); 
        </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>