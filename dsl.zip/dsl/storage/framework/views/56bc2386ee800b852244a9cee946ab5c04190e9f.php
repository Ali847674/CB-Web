<?php $__env->startSection('body'); ?>


            <div class="portlet-body form">
                  <?php echo e(csrf_field()); ?>

                     <div class="form-group">
                        <label class="col-md-3 control-label" >Search</label>
                        <div class="col-md-3">
                            <input type="text" id="myInput"placeholder="Type Date to see report A/c.." data-date-format="DD MMMM YYYY" class="form-control"> </div>
                    </div>

                    <center>
                            <form action="<?php echo e(route('monthly')); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                            <div class="col-md-12">
                                <br>
                                <div class="form-group">
                                    <label class="control-label">Month Year</label>
                                    <input type="month" name="month">
                                    <input type="submit" class="btn btn-primary">
                                </div>
                                <br>
                            </div>
                        </form>
                    </center>
                <form role="form"  method="POST"  class="form-horizontal">
                    <div class="portlet-body" id="items">
                        <div class="table-scrollable">
                            <table class="table table-hover table-light" id="myTable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Orderdate</th>
                                        <th>Customer Name</th>
                                        <th>DeliveryPoint</th>
                                        <th>Destination</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($report != 'empty'): ?>
                                    <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php if($value->order_status != 'pending'): ?>
                                            <a href="" id="btn<?php echo e($key); ?>" class="btn btn-primary showproduct" data-id="<?php echo e($value->id); ?>" data-toggle="modal" data-target="#showmodal" ><?php echo e($value->alpha_id); ?></a>
                                            <?php else: ?>
                                            <h2> <span class="label label-primary showproduct"><?php echo e($value->alpha_id); ?></span></h2>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($value->date); ?></td>
                                        <td><?php echo e($value->sender_name); ?></td>
                                        <td><?php echo e($value->name1); ?></td>
                                        <td><?php echo e($value->name2); ?></td>
                                        <td>
                                            <?php if($value->order_status == 1): ?>
                                            <h2><span class="label label-primary">Picking Up Order</span></h2>
                                            <?php elseif($value->order_status == 2): ?>
                                            <h2><span class="label label-info">At Warehouse</span></h2>
                                            <?php elseif($value->order_status == 3): ?>
                                            <h2><span class="label label-warning">Ready For Delivery</span></h2>
                                            <?php elseif($value->order_status == 4): ?>
                                            <h2><span class="label label-danger">On The Way</span></h2>
                                            <?php elseif($value->order_status == 5): ?>
                                            <h2><span class="label label-success">Delivered</span></h2>
                                            <?php else: ?>
                                            <h2><span class="label label-default"><?php echo e(ucfirst($value->order_status)); ?></span></h2>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    <?php if($report1 != 'empty'): ?>
                                    <?php $__currentLoopData = $report1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php if($value->order_status != 'pending'): ?>
                                            <a href="" id="btn<?php echo e($key); ?>" class="btn btn-primary showproduct" data-id="<?php echo e($value->id); ?>" data-toggle="modal" data-target="#showmodal" ><?php echo e($value->alpha_id); ?></a>
                                            <?php else: ?>
                                            <h2> <span class="label label-primary showproduct"><?php echo e($value->alpha_id); ?></span></h2>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($value->date); ?></td>
                                        <td><?php echo e($value->sender_name); ?></td>
                                        <td><?php echo e($value->origin); ?></td>
                                        <td><?php echo e($value->name2); ?></td>
                                        <td>
                                            <?php if($value->order_status == 1): ?>
                                            <h2><span class="label label-primary">Picking Up Order</span></h2>
                                            <?php elseif($value->order_status == 2): ?>
                                            <h2><span class="label label-info">At Warehouse</span></h2>
                                            <?php elseif($value->order_status == 3): ?>
                                            <h2><span class="label label-warning">Ready For Delivery</span></h2>
                                            <?php elseif($value->order_status == 4): ?>
                                            <h2><span class="label label-danger">On The Way</span></h2>
                                            <?php elseif($value->order_status == 5): ?>
                                            <h2><span class="label label-success">Delivered</span></h2>
                                            <?php else: ?>
                                            <h2><span class="label label-default"><?php echo e(ucfirst($value->order_status)); ?></span></h2>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>  
                    </div>
                </form>
            </div>

             <!--begin::Show Modal-->
                        <div class="modal fade" id="showmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">
                                            Added Products
                                        </h5>
                                    </div>
                                    <div class="modal-body">
                                        <table class="table table-scrollable">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Quantity</th>
                                                    <th>Amount/Piece</th>
                                                </tr>
                                            </thead>
                                            <tbody id="pbody">
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="modal-footer">

                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-offset-3 col-md-9">
                                                            
                                                            <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6"> </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
            <!--end:: Show Modal-->

            <!--begin:: Show Product Detail Modal-->
                        <div class="modal fade" id="detailmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">
                                            Added Products
                                        </h5>
                                    </div>
                                    <div class="modal-body">
                                        <table class="table table-scrollable">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Length</th>
                                                    <th>Width</th>
                                                    <th>Height</th>
                                                    <th>Dimensional Weight</th>
                                                    <th>Quantity</th>
                                                    <th>Amount/Piece</th>
                                                </tr>
                                            </thead>
                                            <tbody id="pdbody">
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="modal-footer">

                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-offset-3 col-md-9">
                                                            
                                                            <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6"> </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
            <!--end:: Show Product Detail Modal-->


<?php $__env->stopSection(); ?>


 <?php $__env->startSection('script'); ?>
    
    <script type="text/javascript">
        $(document).ready(function()
        {
            $("#myInput").on("change", function()
            {
                console.log('Search');
                var value = $(this).val().toLowerCase();
                $("#myTable tr").filter(function() {
                  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });

        $(document).ready(function()
        {
            $(document).on('click','.pname',function()
            {
                console.log('name btn');
                // $('#showmodal').modal('toggle');
                $('#detailmodal').modal('show');
                var p_id = $(this).data('p_id');

                $.ajax({
                    url:"<?php echo e(route('productdetail')); ?>",
                    type:"GET",
                    data:{
                        // "_token":$('input[name=_token]'),
                        "id":p_id
                    },
                    success:function(data)
                    {
                        console.log('Data: \n'+ data);
                        data = JSON.parse(data,true);
                        console.log('Data: \n'+ data);
                        var html  = '';
                        $('#pdbody').html(html);
                            // console.log('i:'+i);
                            html+= '<tr>';
                            html+= '<td>' +data[0]['name']+ '</td>';
                            html+= '<td>' +data[0]['length'] +'</td>';
                            html+= '<td>' +data[0]['width']+ '</td>';
                            html+= '<td>' +data[0]['height'] +'</td>';
                            html+= '<td>' +data[0]['dimensional_weight'] +'</td>';
                            html+= '<td>' +data[0]['quantity'] +'</td>';
                            html+= '<td>' +data[0]['amount_pc'] +'</td>';
                            html+= '</tr>';
                            $('#pdbody').append(html);
                    }
                });
            });
        });

        $(document).ready(function()
        {
            $(document).on('click','.showproduct',function()
            {
                var key = $(this).attr('id');
                console.log('Id'+key);

                var id = $(this).data('id');
                console.log('ID: '+id);
                $.ajax({
                    'type': 'POST',
                    'url' : "<?php echo e(route('showproduct')); ?>",
                    'data': {
                        'id':id,
                        '_token':$('input[name=_token]').val()
                    },
                    success:function(data)
                    {

                        console.log('Data: \n'+data);
                        data = JSON.parse(data,true);
                        console.log('Data: \n'+data);
                        var html  = '';
                        $('#pbody').html(html);
                        for(var i=0; i<data.length; i++)
                        {
                            console.log('i')
                            console.log(i);
                            html+= '<tr>';
                            html+= '<td><button class="btn-xs btn-primary pname" data-p_id="'+ data[i]['p_id'] +'" </button>'+data[i]['name']+'</td>';
                            html+= '<td>'+data[i]['quantity']+'</td>';
                            html+= '<td>'+data[i]['amount_pc']+'</td>';
                            // html+= '<td><button class="btn-xs btn-warning updatebtn" data-id="'+ id + '" data-p_id="'+ data[i]['p_id'] +'"> Update </button></td>';
                            // html+= '<td><button class="btn-xs btn-danger removebtn" data-id="'+  id + '" data-p_id="'+ data[i]['p_id'] +'"> Remove</button></td>';
                            html+= '</tr>';
                        }
                        $('#pbody').append(html);
                        $('#useful').val(key);
                    },
                    error:function()
                    {
                        toastr.error('Server Down!', 'Error Alert', {timeOut: 5000});
                    }
                });
            });
        });
    });

    </script>
                    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>