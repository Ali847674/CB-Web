
<?php $__env->startSection('body'); ?>
    <button type="buton" data-toggle="modal" data-target="#addmodal" class="btn btn-info">Create New Customer</button>

        
            <div class="portlet-body form">
                   
                        <form role="form"  method="POST"  class="form-horizontal">
                              <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label class="col-md-3 control-label" >Search</label>
                                    <div class="col-md-3">
                                        <input type="text" id="myInput"placeholder="Search.." class="form-control">
                                    </div>
                                </div>

                                <div class="portlet-body" id="items">
                                    <div class="table-scrollable">
                                        <table class="table table-hover table-light" id="myTable">
                                            <thead>
                                                <tr>
                                                    <th>Customer Id</th>
                                                    <th>Name</th>
                                                    <th>Origin</th>
                                                    <th>Address</th>
                                                    <th>Contact</th>
                                                    <th>Email</th>
                                                    <th>Member Since</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>  
                                </div>
                        </form>
            </div>
        


        <!--begin::add Modal-->
                <div class="modal fade" id="addmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">
                               New Customer Form
                                </h5>
                            </div>
                            <div class="modal-body">

                                <form  class="form-horizontal" id="addform">

                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-body">
                                        

                                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                            <label for="name" class="col-md-4 control-label">Name</label>
                                            <div class="col-md-4">
                                                <input id="name" type="text" value="<?php echo e(old('name')); ?>" class="form-control" name="name" required autofocus>
                                            </div>
                                        </div>


                                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                            <label for="email" class="col-md-4 control-label">Email</label>
                                            <div class="col-md-4">
                                                <input id="email" type="email" value="<?php echo e(old('email')); ?>" class="form-control" name="email" required >
                                            </div>
                                        </div>

                                        <div class="form-group<?php echo e($errors->has('contact') ? ' has-error' : ''); ?>">
                                            <label for="contact" class="col-md-4 control-label">Contact</label>
                                            <div class="col-md-4">
                                                <input id="contact" type="text" value="<?php echo e(old('contact')); ?>" class="form-control" name="contact" required>
                                            </div>
                                        </div>

                                        <div class="form-group<?php echo e($errors->has('contact') ? ' has-error' : ''); ?>">
                                            <label for="contact" class="col-md-4 control-label">Origin City</label>
                                            <div class="col-md-4">
                                                <select name="city_id" class="form-control">
                                                    <option disabled selected value>Select City</option>
                                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group<?php echo e($errors->has('contact') ? ' has-error' : ''); ?>">
                                            <label for="contact" class="col-md-4 control-label">Address</label>
                                            <div class="col-md-4">
                                                <input id="address" type="text" value="<?php echo e(old('address')); ?>" class="form-control" name="address" required>
                                            </div>
                                        </div>


                                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                            <label for="password" class="col-md-4 control-label">Password</label>
                                            <div class="col-md-4">
                                                <input id="password" minlength="6" maxlength="8" type="password" class="form-control" name="password" required autofocus>
                                            </div>
                                        </div>


                                        <div class="modal-footer">
                                            <div class="form-actions">
                                                <div class="row">
                                                    <div class="col-md-9">
                                                        <div class="row">
                                                            <div class="col-md-offset-3 col-md-9">
                                                                <button type="submit" class="btn green addproduct1">Submit</button>
                                                                <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6"> </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
        <!--end::add  Modal-->

        <!--begin::update Modal-->
                <div class="modal fade" id="updatemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">
                                Edit Information
                                </h5>
                            </div>
                            <div class="modal-body">

                                <form id="customerupdate" class="form-horizontal" style="padding: 20px;" enctype="multipart/form-data">


                                    <?php echo e(csrf_field()); ?>

                                        <div class="form-body">
                                            <div class="form-group">
                                                <div class="col-md-9">
                                                    <?php if(Session::has('fields')): ?>
                                                    <span class="myclass">*<?php echo e(session('fields')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-md-9">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-4">
                                                        Id
                                                    </label>
                                                    <div class="col-md-8">
                                                        <input type="text" class="form-control" name="id" id="idu" required readonly>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-9">
                                                <div class="form-group">
                                                    <label for="name" class="col-md-4 control-label">Name</label>
                                                    <div class="col-md-8">
                                                        <input id="nameu" type="text" value="<?php echo e(old('name')); ?>" class="form-control" name="name" required autofocus>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-9">
                                                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                                    <label for="email" class="col-md-4 control-label">Email</label>
                                                    <div class="col-md-8">
                                                        <input id="emailu" type="email" value="<?php echo e(old('email')); ?>" class="form-control" name="email" required >
                                                        <?php if(Session::has('email')): ?>
                                                        <span class="myclass">*<?php echo e(session('email')); ?></span>
                                                        <?php endif; ?>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-9">
                                                <div class="form-group<?php echo e($errors->has('contact') ? ' has-error' : ''); ?>">
                                                    <label for="contact" class="col-md-4 control-label">Contact</label>
                                                    <div class="col-md-8">
                                                        <input id="contactu" type="text" value="<?php echo e(old('contact')); ?>" class="form-control" name="contact" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-9">
                                                <div class="form-group<?php echo e($errors->has('contact') ? ' has-error' : ''); ?>">
                                                    <label for="contact" class="col-md-4 control-label">Origin City</label>
                                                    <div class="col-md-8">
                                                        <select name="city_id" class="form-control" id="city_idu">
                                                            <option disabled selected value>Select City</option>
                                                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-9">
                                                <div class="form-group<?php echo e($errors->has('contact') ? ' has-error' : ''); ?>">
                                                    <label for="contact" class="col-md-4 control-label">Address</label>
                                                    <div class="col-md-8">
                                                        <input id="addressu" type="text" value="<?php echo e(old('address')); ?>" class="form-control" name="address" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-9">
                                                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                                    <label for="password" class="col-md-4 control-label">Password</label>
                                                    <div class="col-md-8">
                                                        <input id="passwordu" minlength="6" maxlength="8" type="password" class="form-control" name="password" required autofocus>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <div class="modal-footer">
                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-offset-3 col-md-9">
                                                            <button type="submit" class="btn green addproduct1">Submit</button>
                                                            <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6"> </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
        <!--end::update  Modal-->

        <!--begin:: Delete  modal -->
                <div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Delete The Current Order</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <center>
                            <h2>Do You Want To Delete The Current Customer</h2>
                            <h3>Once Proceed Cannot Be Revert</h3>
                        </center>
                      </div>
                      <div class="modal-footer">
                        <form id="customerdelete">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" id="c_id">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-danger"   >Delete</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
        <!--end:: delete  Modal -->

            

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script type="text/javascript">

        <?php if(Session::has('email')): ?>
            toastr.error('Email Already Taken By Other User','Integration Contraint')
        <?php elseif(Session::has('fields')): ?>
            toastr.error('Some Fields Are Missing','All Fields Are Required')
        <?php endif; ?>

        jQuery(document).ready(function() {
            $('#myTable').DataTable().destroy();
            $('#myTable').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": "<?php echo e(route('customerdata')); ?>",
                "columns":[
                    { "data": "alphaid" },
                    { "data": "name" },
                    { "data": "origin" },
                    { "data": "address"},
                    { "data": "contact"},
                    { "data": "email"},
                    { "data": "membersince"},
                    { "data": "action"},
                ]
            });
        });
        
        $(document).ready(function()
        {
            setTimeout(function()
            {
               $(".myclass").remove();
            }, 5000 );

            $(document).on('submit', '#addform', function(event)
            {
                event.preventDefault();
                var formdata = $('#addform').serialize();
                $.ajax({
                    url:'<?php echo e(route('addcustomer')); ?>',
                    type:'POST',
                    data:formdata,
                    success:function(data)
                    {
                        if (data == 'fields') 
                        {
                            toastr.error('Some Fields Are Missing','All Fields Are Required')
                        }
                        else if (data == 'email') 
                        {
                            toastr.error('Email Already Taken By Other User','Integration Contraint')
                        }
                        else if (data == 'success') 
                        {
                            toastr.success('New Customer Added Successfully','Succes Alert');
                            $('#addmodal').modal('hide');
                            $('#myTable').DataTable().ajax.reload();
                        }
                    },
                    error:function(){
                        toastr.error('Coresponding Server Is Down','Error Alert')
                    },
                });
            });

            $(document).on('click','.updatebtn',function()
            {
                $('#idu').val($(this).data('id'));
                $('#nameu').val($(this).data('name'));
                $('#contactu').val($(this).data('contact'));
                $('#addressu').val($(this).data('address'));
                $('#emailu').val($(this).data('email'));
                $('#city_idu').val($(this).data('city_id'));
            });

            $(document).on('submit', '#customerupdate', function(event)
            {
                event.preventDefault();
                var formdata = $('#customerupdate').serialize();
                $.ajax({
                    url:'<?php echo e(route('updatecustomer')); ?>',
                    type:'POST',
                    data:formdata,
                    success:function(data)
                    {
                        if (data == 'fields') 
                        {
                            toastr.error('Some Fields Are Missing','All Fields Are Required')
                        }
                        else if (data == 'email') 
                        {
                            toastr.error('Email Already Taken By Other User','Integration Contraint')
                        }
                        else if (data == 'success') 
                        {
                            toastr.success(" Customer's Information Updated Successfully",'Succes Alert');
                            $('#updatemodal').modal('hide');
                            $('#myTable').DataTable().ajax.reload();
                        }
                    },
                    error:function(){
                        toastr.error('Coresponding Server Is Down','Error Alert')
                    },
                });
            });


            $(document).on('click','.deletebtn',function()
            {
                console.log('Hello')
                $('#c_id').val($(this).data('id'));
            });

            $(document).on('submit', '#customerdelete', function(event)
            {
                event.preventDefault();
                var formdata = $('#customerdelete').serialize();
                $.ajax({
                    url:'<?php echo e(route('deletecustomer')); ?>',
                    type:'GET',
                    data:formdata,
                    success:function(data)
                    {
                        if (data == 'fields') 
                        {
                            toastr.error('Some Fields Are Missing','All Fields Are Required')
                        }
                        else if (data == 'email') 
                        {
                            toastr.error('Email Already Taken By Other User','Integration Contraint')
                        }
                        else if (data == 'success') 
                        {
                            toastr.success('Customer Deleted Successfully','Succes Alert');
                            $('#deletemodal').modal('hide');
                            $('#myTable').DataTable().ajax.reload();
                        }
                    },
                    error:function(){
                        toastr.error('Coresponding Server Is Down','Error Alert')
                    },
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>