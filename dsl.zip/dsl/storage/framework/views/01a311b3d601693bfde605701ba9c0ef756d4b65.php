
<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- banner-text -->
    <!-- ab -->

    <?php echo $__env->yieldContent('headerlinks'); ?>
    <?php echo $__env->yieldContent('sidebar'); ?>
    <?php echo $__env->yieldContent('headernavigations'); ?>
<section class="banner-bottom-w3ls py-lg-5 py-md-5 py-3">
        <div class="container">
            <div class="inner-sec-w3layouts py-lg-5 py-3">
               
                <div class="row mt-lg-5 mt-md-4 mt-4">
                    <div class="col-lg-4 about-in text-left">
                        <div class="card">
                            <div class="card-body">
                               <i class="fas fa-thumbtack mb-2"></i>
                               
                                <h5 class="card-title">Locate US</h5>
                                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                                proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                               
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-4 about-in text-left">
                        <div class="card">
                            <div class="card-body">
<i class="fas fa-truck mb-2"></i>
                             
                                <h5 class="card-title">Schdeule A Pick Up </h5>
                                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                                proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                               
                            </div>
                        </div>

                    </div>

                    <div class="col-lg-4 about-in text-left">
                        <div class="card">
                            <div class="card-body">
                                <i class="fas fa-phone"></i>
                               
                                <h5 class="card-title">Contact US</h5>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                                proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                               
                            </div>
                        </div>
                    </div>
                   
                   
                   

                </div>

            </div>
        </div>
    </section>
    <!-- //ab -->
    <!-- banner-bottom-w3ls -->
    <!-- <section class="banner-bottom-w3ls py-lg-5 py-md-5 py-3">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 about-img">
                </div>
                <div class="col-lg-6 about-right">
                    <h4>Who We Are</h4>
                    <h3>We give you complete control of your shipments.</h3>
                    <p class="my-4">Lorem ipsum dolor sit amet Neque porro quisquam est qui dolorem Lorem int ipsum dolor sit amet when an unknown printer took a galley of type.Vivamus id tempor felis. Cras sagittis mi sit amet malesuada mollis. Mauris porroinit consectetur cursus tortor vel interdum.</p>

                    <ul class="author d-flex">
                        <li><img class="img-fluid" src="images/author.jpg" alt=""></li>
                        <li><span>Admin Name</span>Comany Namer</li>
                    </ul>
                    <div class="log-in mt-md-5 mt-3">
                        <a class="btn text-uppercase" href="single.html">
                                    Read More</a>
                    </div>

                </div>
            </div>
        </div>
    </section> -->
    <!-- //banner-bottom-w3ls -->
    <!-- /services -->
  <!--   <section class="banner-bottom-w3ls py-lg-5 py-md-5 py-3">
        <div class="container">
            <div class="inner-sec-w3layouts py-lg-5 py-3">
                <h3 class="tittle text-center mb-md-5 mb-4">We Offered Services</h3>
                <div class="row middle-grids">
                    <div class="col-lg-4 about-in middle-grid-info text-center">
                        <div class="card">
                            <div class="card-body">
                                <i class="fas fa-archive mb-2"></i>
                                <h5 class="card-title my-3">Storage</h5>
                                <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 about-in middle-grid-info text-center">
                        <div class="card">
                            <div class="card-body">
                                <i class="fas fa-signal mb-2"></i>
                                <h5 class="card-title my-3">Trucking Services</h5>
                                <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 about-in middle-grid-info text-center">
                        <div class="card">
                            <div class="card-body">
                                <i class="fas fa-users mb-2"></i>
                                <h5 class="card-title my-3">Expert Staff</h5>
                                <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- //services -->
    <!--gallery  -->
   <!--  <section class="gallery py-md-5 py-3">
        <div class="gallery-inner pb-md-5 pb-3">
            <h3 class="tittle text-center mb-md-5 mb-4">Gallery</h3>
            <ul class="portfolio-categ filter pb-5 mb-lg-3 text-center">
                <li class="port-filter all active">
                    <a href="#">All</a>
                </li>
                <li class="cat-item-1">
                    <a href="#" title="Category 1">category 1</a>
                </li>
                <li class="cat-item-2">
                    <a href="#" title="Category 2">category 2</a>
                </li>
                <li class="cat-item-3">
                    <a href="#" title="Category 3">category 3</a>
                </li>


            </ul>
            <ul class="portfolio-area clearfix">
                <li class="portfolio-item2" data-id="id-0" data-type="cat-item-3">
                    <span class="image-block img-hover">
                        <a class="image-zoom" href="images/g1.jpg" data-gal="prettyPhoto[gallery]">
                            <img src="images/g1.jpg" class="img-fluid " alt="">
                        </a>
                    </span>
                </li>
                <li class="portfolio-item2" data-id="id-1" data-type="cat-item-2">
                    <span class="image-block">
                       <a class="image-zoom" href="images/g2.jpg" data-gal="prettyPhoto[gallery]">
                            <img src="images/g2.jpg" class="img-fluid " alt="">
                        </a>
                    </span>
                </li>
                <li class="portfolio-item2" data-id="id-2" data-type="cat-item-1">
                    <span class="image-block">
                        <a class="image-zoom" href="images/g3.jpg" data-gal="prettyPhoto[gallery]">
                            <img src="images/g3.jpg" class="img-fluid " alt="">
                        </a>
                    </span>
                </li>
                <li class="portfolio-item2" data-id="id-4" data-type="cat-item-3">
                    <span class="image-block">
                       <a class="image-zoom" href="images/g4.jpg" data-gal="prettyPhoto[gallery]">
                            <img src="images/g4.jpg" class="img-fluid " alt="">
                        </a>
                    </span>
                </li>
                <li class="portfolio-item2" data-id="id-5" data-type="cat-item-2">
                    <span class="image-block">
                       <a class="image-zoom" href="images/g5.jpg" data-gal="prettyPhoto[gallery]">
                            <img src="images/g5.jpg" class="img-fluid " alt="">
                        </a>
                    </span>
                </li>
                <li class="portfolio-item2" data-id="id-7" data-type="cat-item-1">
                    <span class="image-block">
                       <a class="image-zoom" href="images/g6.jpg" data-gal="prettyPhoto[gallery]">
                            <img src="images/g6.jpg" class="img-fluid " alt="">
                        </a>
                    </span>
                </li>
                <li class="portfolio-item2" data-id="id-7" data-type="cat-item-1">
                    <span class="image-block">
                       <a class="image-zoom" href="images/g7.jpg" data-gal="prettyPhoto[gallery]">
                            <img src="images/g7.jpg" class="img-fluid " alt="">
                        </a>
                    </span>
                </li>
                <li class="portfolio-item2" data-id="id-7" data-type="cat-item-1">
                    <span class="image-block">
                        <a class="image-zoom" href="images/g8.jpg" data-gal="prettyPhoto[gallery]">
                            <img src="images/g8.jpg" class="img-fluid " alt="">
                        </a>
                    </span>
                </li>
            </ul>
          
        </div>
      
    </section> -->
    <!-- //gallery -->
    <!--/pricing -->
 <!--    <section class="pricing py-md-5 py-3">
        <div class="container">
            <div class="inner-sec-w3layouts pb-md-5 pb-3">

                <div class="row">
                    <div class="col-lg-6 price-left">
                        <h3 class="tittle text-left mb-md-5 mb-4">Choose your desire price</h3>
                        <p>Lorem ipsum dolor sit amet Neque porro quisquam est qui dolorem Lorem int ipsum dolor sit amet when an unknown printer took a galley of type.Vivamus id tempor felis.ivamus id tempor felis. </p>

                    </div>
                    <div class="col-lg-6 price-right">

                        <div class="tabs">
                            <ul class="nav nav-pills my-4" id="pills-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Weekly</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Monthly</a>
                                </li>

                            </ul>
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                    <div class="menu-grids mt-4">
                                        <div class="row t-in">
                                            <div class="col-md-6 price-main-info text-center">
                                                <div class="price-inner card box-shadow">

                                                    <div class="card-body">
                                                        <h4 class="text-uppercase mb-3">Business</h4>
                                                        <h5 class="card-title pricing-card-title">
                                                            <span class="align-top">$</span>30

                                                        </h5>
                                                        <ul class="list-unstyled mt-3 mb-4">
                                                            <li>Lorem Ipsum is simply</li>
                                                            <li>Lorem Ipsum is simply</li>
                                                            <li>Lorem Ipsum is simply</li>
                                                            <li>Lorem Ipsum is simply</li>
                                                        </ul>
                                                        <div class="log-in mt-md-3 mt-2">
                                                            <a class="btn text-uppercase" href="single.html">
                                                        Read More</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 price-main-info text-center">
                                                <div class="price-inner card box-shadow">

                                                    <div class="card-body">
                                                        <h4 class="text-uppercase mb-3">Business</h4>
                                                        <h5 class="card-title pricing-card-title">
                                                            <span class="align-top">$</span>90

                                                        </h5>
                                                        <ul class="list-unstyled mt-3 mb-4">
                                                            <li>Lorem Ipsum is simply</li>
                                                            <li>Lorem Ipsum is simply</li>
                                                            <li>Lorem Ipsum is simply</li>
                                                            <li>Lorem Ipsum is simply</li>
                                                        </ul>
                                                        <div class="log-in mt-md-3 mt-2">
                                                            <a class="btn text-uppercase" href="single.html">
                                                        Read More</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                                    <div class="menu-grids mt-4">
                                        <div class="row t-in">
                                            <div class="col-md-6 price-main-info text-center">
                                                <div class="price-inner card box-shadow">

                                                    <div class="card-body">
                                                        <h4 class="text-uppercase mb-3">Business</h4>
                                                        <h5 class="card-title pricing-card-title">
                                                            <span class="align-top">$</span>60

                                                        </h5>
                                                        <ul class="list-unstyled mt-3 mb-4">
                                                            <li>Lorem Ipsum is simply</li>
                                                            <li>Lorem Ipsum is simply</li>
                                                            <li>Lorem Ipsum is simply</li>
                                                            <li>Lorem Ipsum is simply</li>
                                                        </ul>
                                                        <div class="log-in mt-md-3 mt-2">
                                                            <a class="btn text-uppercase" href="single.html">
                                                        Read More</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 price-main-info text-center">
                                                <div class="price-inner card box-shadow">

                                                    <div class="card-body">
                                                        <h4 class="text-uppercase mb-3">Business</h4>
                                                        <h5 class="card-title pricing-card-title">
                                                            <span class="align-top">$</span>80

                                                        </h5>
                                                        <ul class="list-unstyled mt-3 mb-4">
                                                            <li>Lorem Ipsum is simply</li>
                                                            <li>Lorem Ipsum is simply</li>
                                                            <li>Lorem Ipsum is simply</li>
                                                            <li>Lorem Ipsum is simply</li>
                                                        </ul>
                                                        <div class="log-in mt-md-3 mt-2">
                                                            <a class="btn text-uppercase" href="single.html">
                                                        Read More</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- //pricing -->
    <!-- /bottom-last -->
    <!-- <section class="bottom-last py-5 text-center">
        <div class="bottom-bg">
            <h3>Imagination… What we can easily see is only a small percentage of what is possible.</h3>

        </div>
    </section> -->
    <!-- //bottom-last -->
    <!--/Blog-Posts-->
    <!-- <section class="banner-bottom-w3ls bg-light py-md-5 py-4">
        <div class="container">
            <div class="inner-sec-w3layouts py-md-5 py-4">
                <h3 class="tittle text-center mb-md-5 mb-4">
                    Blog Posts</h3>
          
                <div class="row blog-sec">
                    <div class="col-lg-4 about-in blog-grid-info text-left">
                        <div class="card img">
                            <div class="card-body img">
                                <img src="images/g7.jpg" alt="" class="img-fluid">
                                <div class="blog-des">
                                    <span class="entry-date">June 18, 2018</span>
                                    <h5 class="card-title text-uppercase mt-2"><a href="single.html">Vivamus id tempor felis. Cras sagittis mi sit amet </a></h5>
                                    <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 about-in blog-grid-info text-left">
                        <div class="card img">
                            <div class="card-body img">
                                <img src="images/g1.jpg" alt="" class="img-fluid">
                                <div class="blog-des">
                                    <span class="entry-date">June 20, 2018</span>
                                    <h5 class="card-title text-uppercase mt-2"><a href="single.html">Vivamus id tempor felis. Cras sagittis mi sit amet </a></h5>
                                    <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 about-in blog-grid-info text-left">
                        <div class="card img">
                            <div class="card-body img">
                                <img src="images/g4.jpg" alt="" class="img-fluid">
                                <div class="blog-des">
                                    <span class="entry-date">June 25, 2018</span>
                                    <h5 class="card-title text-uppercase mt-2"><a href="single.html">Vivamus id tempor felis. Cras sagittis mi sit amet </a></h5>
                                    <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!--//Blog-Posts-->
    <!--/testimonials-->
   <!--  <section class="clients py-md-5 py-3">
        <div class="container">
            <div class="inner-sec-w3layouts py-md-5 py-3">
                <h3 class="tittle text-center mb-md-5 mb-4">Some word from our Clients</h3>
                <div class="owl-carousel owl-theme">
                    <div class="item">
                        <div class="feedback-info text-left">
                            <div class="feedback-top">

                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit sedc dnmo eiusmod tempor incididunt ut labore.</p>
                            </div>
                            <div class="feedback-grids">
                                <div class="feedback-img">
                                    <img src="images/t1.jpg" class="img-fluid rounded-circle" alt="" />
                                </div>
                                <div class="feedback-img-info">
                                    <h5>Mary Jane</h5>
                                    <p>United States
                                        <span>(Company)</span>
                                    </p>
                                </div>
                                <div class="clearfix"> </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="feedback-info text-left">

                            <div class="feedback-top">

                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit sedc dnmo eiusmod tempor incididunt ut labore.</p>
                            </div>
                            <div class="feedback-grids">
                                <div class="feedback-img">
                                    <img src="images/t3.jpg" class="img-fluid rounded-circle" alt="" />
                                </div>
                                <div class="feedback-img-info">
                                    <h5>Steven Wilson</h5>
                                    <p>United States
                                        <span>(Company)</span>
                                    </p>
                                </div>
                                <div class="clearfix"> </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="feedback-info text-left">
                            <div class="feedback-top">
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit sedc dnmo eiusmod tempor incididunt ut labore.</p>
                            </div>
                            <div class="feedback-grids">
                                <div class="feedback-img">
                                    <img src="images/t2.jpg" class="img-fluid rounded-circle" alt="" />
                                </div>
                                <div class="feedback-img-info">
                                    <h5>Peter guptill</h5>
                                    <p>Vestibulum <span>(Company)</span></p>
                                </div>
                                <div class="clearfix"> </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="feedback-info text-left">

                            <div class="feedback-top">

                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit sedc dnmo eiusmod tempor incididunt ut labore.</p>
                            </div>
                            <div class="feedback-grids">
                                <div class="feedback-img">
                                    <img src="images/t3.jpg" class="img-fluid rounded-circle" alt="" />
                                </div>
                                <div class="feedback-img-info">
                                    <h5>Steven Wilson</h5>
                                    <p>United States
                                        <span>(Company)</span>
                                    </p>
                                </div>
                                <div class="clearfix"> </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="feedback-info text-left">
                            <div class="feedback-top">
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit sedc dnmo eiusmod tempor incididunt ut labore.</p>
                            </div>
                            <div class="feedback-grids">
                                <div class="feedback-img">
                                    <img src="images/t2.jpg" class="img-fluid rounded-circle" alt="" />
                                </div>
                                <div class="feedback-img-info">
                                    <h5>Peter guptill</h5>
                                    <p>Vestibulum <span>(Company)</span></p>
                                </div>
                                <div class="clearfix"> </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section> -->
    <!--//testimonials-->


<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    