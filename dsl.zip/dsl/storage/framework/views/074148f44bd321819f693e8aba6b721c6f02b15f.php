
<?php $__env->startSection('body'); ?>


        <div class="portlet-body form">
            <div class="portlet-body" id="items">
                <div class="table-scrollable">
                    <table class="table table-hover table-light" id="myTable">
                        <thead>
                            <tr>
                                <th>User Name</th>
                                <th>Email</th>
                                <th>Subject</th>
                                <th>Message</th>
                            </tr>
                        </thead>
                    </table>
                </div>  
            </div>
        </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    
    <script type="text/javascript">
        jQuery(document).ready(function() {
            $('#myTable').DataTable().destroy();
            $('#myTable').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": "<?php echo e(route('feedbackdata')); ?>",
                "columns":[
                    { "data": "name" },
                    { "data": "email" },
                    { "data": "subject" },
                    { "data": "message"}
                ]
            });
        });
    </script>       
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>