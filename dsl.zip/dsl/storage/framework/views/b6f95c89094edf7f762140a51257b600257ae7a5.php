
<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->yieldContent('headerlinks'); ?>
    <?php echo $__env->yieldContent('headernavigations'); ?>
    <style>
                *
                {

                    font-family: roboto;
                    font-size: 15px;
                }
                table, td, th {
                  border: 1px solid black;
                }

                table {
                  border-collapse: collapse;
                  width: 100%;
                }

                th {
                  text-align: left;
                }

                td
                {
                  text-align: center;
                }

                img.imgbar {
                    width: 314px;
                }

                td.rightside {
                    text-align: right;
                }

                td.leftside {
                    text-align: left;
                }

                td.test {
                    width: 70px;
                }

                p.tac {
                    font-size: 20px;
                    margin-top: 5px;
                    margin-bottom: 5px;
                }
                ul.ultac {
                    padding-left: 18px;
                    margin-top: 0px;
                }
    </style> 
    <!-- /breadcrumb -->
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="/">Home</a>
        </li>
        <li class="breadcrumb-item active">Client Request</li>
    </ol>
    <!-- //breadcrumb -->
    <!-- /Contact-->
    <section class="banner-bottom-w3ls py-lg-5 py-md-5 py-3">
        <div class="container">
            <div class="inner-sec-w3layouts py-lg-5 py-3">	
                <h3 class="tittle text-center mb-md-5 mb-4">Client Request</h3>

                <button class="btn btn-success" id="d">Domestic</button>
                <button class="btn btn-primary" id="i">International</button>

                <div class="contact_grid_right">
                    
                        <div id="domestic">
                            <form id="createorder"  class="form-horizontal">
                <h3 class="tittle text-center mb-md-5 mb-4">Domestic</h3>

                                            <?php echo e(csrf_field()); ?>

                                            <div>
                                                <table>
                                                    <tr>
                                                        <td colspan="4" rowspan="4"  class="test"><img height="100" src="logo2.jpg"></td>               
                                                        <td colspan="5" rowspan="4" ><img height="100" src="bar.png" class="imgbar"></td>
                                                        <td colspan="3">DSL CLIENT A/C # </td>
                                                        <td>DATE</td>
                                                        <td colspan="3">
                                                            <strong><u><?php echo e(\Carbon\Carbon::now()->format('l d-M-Y')); ?></u></strong>
                                                            <input type="hidden" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" name="date">
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="test">For Office Use</td>
                                                        <td colspan="4"><strong>SHIPMENTS DETAIL'S </strong></td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3">TRACKING VIA </td>
                                                        <td colspan="2">ORIGIN </td>
                                                        <td colspan="2">DESTINATION</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="test">For Office Use</td>
                                                        <td colspan="2">
                                                            <select class="form-control"  name="origin">
                                                                <option disabled selected value>Select Destination</option>
                                                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </td>
                                                        <td colspan="2" class="test">
                                                            <select class="form-control"  name="destination">
                                                                <option disabled selected value>Select Destination</option>
                                                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="12" class="leftside"><strong>FROM DETAIL'S</strong></td>               
                                                        <td colspan="2">WEIGHT (KG)</td>
                                                        <td colspan="2">WEIGHT (DIM)</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="rightside">SENDER NAME</td>               
                                                        <td colspan="4" class="test">
                                                            <input class="form-control"  type="text" placeholder="Enter Sender Name" name="sender_name">
                                                        </td>
                                                        <td colspan="2">COMPANY NAME</td>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control"  type="text" placeholder="Enter Company Name" name="sender_company">
                                                        </td>
                                                        <td colspan="2" class="test">
                                                            <input class="form-control"  type="text" placeholder="Weight in KG" name="weight_kg">
                                                        </td>
                                                        <td colspan="2" class="test">
                                                            <input class="form-control"  type="text" placeholder="Weight in Dimension" name="weight_dim">
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="rightside">CELL #</td>               
                                                        <td colspan="5" class="test">
                                                            <input class="form-control"  type="text" placeholder="Enter #" name="sender_cell">
                                                        </td>
                                                        <td>LINE #</td>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control"  type="text" placeholder="Enter LINE#" name="sender_line">
                                                        </td>
                                                        <td colspan="2">PIECES</td>
                                                        <td colspan="2">PACKAGE</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="rightside">ADDRESS</td>               
                                                        <td colspan="9" class="test">
                                                            <input class="form-control"  type="text" name="sender_address" placeholder="Enter Address">
                                                        </td>
                                                        <td colspan="2" class="test"><input placeholder="No Of Pieces" class="form-control" type="text" name="pieces"></td>
                                                        <td colspan="2">
                                                            For Office Use
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="12" class="test"></td>               
                                                        <td colspan="2">SERVICE TYPE </td>
                                                        <td colspan="2">PAYMENT</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="8" class="test"></td>               
                                                        <td colspan="2">POSTAL CODE</td>
                                                        <td colspan="2" class="test">
                                                            <input class="form-control" placeholder="Enter POSTAL Code" type="text" name="sender_postal">
                                                        </td>
                                                        <td colspan="2">
                                                            For Office Use
                                                        </td>
                                                        <td colspan="2">
                                                            <select class="form-control" name="payment_id">
                                                                <option disabled selected value>Select PAYMENT Type</option>
                                                                <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="12" class="leftside"><strong>TO DETAIL'S</strong></td>               
                                                        <td colspan="2">CHARGES </td>
                                                        <td colspan="2">PAK RUPEES</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="rightside">RECEIVER NAME </td>               
                                                        <td colspan="4" class="test">
                                                            <input class="form-control" placeholder="Reciver Name" type="text" name="receiver_name">
                                                        </td>
                                                        <td colspan="2">COMPANY NAME</td>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control" placeholder="Enter Company Name" type="text" name="receiver_company">
                                                        </td>
                                                        <td colspan="2">AMOUNT</td>
                                                        <td colspan="2" class="test">
                                                            For Office Use
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="rightside">CELL# </td>               
                                                        <td colspan="5" class="test">
                                                            <input class="form-control" placeholder="Contact Number" type="text" name="receiver_cell">
                                                        </td>
                                                        <td>LINE #</td>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control" placeholder="Enter Line#" type="text" name="receiver_line">
                                                        </td>
                                                        <td colspan="2">GST%</td>
                                                        <td colspan="2" class="test">
                                                            For Office Use
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="rightside">ADDRESS</td>               
                                                        <td colspan="9" class="test">
                                                            <input class="form-control" placeholder="Enter Address" type="text" name="receiver_address">
                                                        </td>
                                                        <td colspan="2">DISCOUNT</td>
                                                        <td colspan="2" class="test">
                                                            For Office Use
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="12" class="test"></td>               
                                                        <td colspan="2">TOTAL</td>
                                                        <td colspan="2" class="test">
                                                           For Office Use
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="8" class="test"></td>               
                                                        <td colspan="2">POSTAL CODE</td>
                                                        <td colspan="2" class="test">
                                                            <input class="form-control" placeholder="Reciver POSTAL" type="text" name="receiver_postal">
                                                        </td>
                                                        <td colspan="4" rowspan="6" width="1px">"i confirm and affirm that i have understood and agree on all the rates and terms and conditions should hereinafter and that all details given here in are true and correct. This execution of this consignment note is prima facia evidence of the conclusions of contract between shipper & DSL"</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="8"><strong>COMMODITY DESCRIPTION</strong></td>               
                                                        <td colspan="2">DOX / NON DOX </td>
                                                        <td colspan="2">INVOICE</td>              
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control" placeholder="Product Name" type="text" name="name[]">
                                                        </td>               
                                                        <td class="test">
                                                            <input class="form-control" placeholder="Qty" type="text" name="quantity[]">
                                                        </td>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control"  id="c1" placeholder="Product Name" type="text" name="name[]">
                                                        </td>
                                                        <td class="test">
                                                            <input class="form-control" id="c2" placeholder="Qty" type="text" name="quantity[]">
                                                        </td>
                                                        <td colspan="2" class="test">
                                                            For Office Use
                                                        </td>
                                                        <td colspan="2">
                                                            For Office Use
                                                        </td>               

                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control" id="c3" placeholder="Product Name" type="text" name="name[]">
                                                        </td>               
                                                        <td class="test">
                                                            <input class="form-control" id="c4" placeholder="Qty" type="text" name="quantity[]">
                                                        </td>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control" id="c5" placeholder="Product Name" type="text" name="name[]">
                                                        </td>
                                                        <td class="test">
                                                            <input class="form-control" id="c6" placeholder="Qty" type="text" name="quantity[]">
                                                        </td>
                                                        <td colspan="2">TOTAL CONTENTS </td>
                                                        <td colspan="2">VALUE $</td>               
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control" id="c7" placeholder="Product Name" type="text" name="name[]">
                                                        </td>               
                                                        <td class="test">
                                                            <input class="form-control" id="c8" placeholder="Qty" type="text" name="quantity[]">
                                                        </td>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control" id="c9" placeholder="Product Name" type="text" name="name[]">
                                                        </td>
                                                        <td class="test">
                                                            <input class="form-control" id="c10" placeholder="Qty" type="text" name="quantity[]">
                                                        </td>
                                                        <td colspan="2">
                                                            For Office Use
                                                        </td>
                                                        <td colspan="2" class="test">
                                                            For Office Use
                                                        </td>              
                                                    </tr>
                                                    <tr>
                                                        <td colspan="10" width="1px" class="leftside">OFFICE: SHOP 46-A BC-5-6 1ST FLOOR, SASI ARCADE, BLOCK-7 CLIFTON KARACHI- 75600</td>
                                                        <td class="test"></td>               
                                                        <td class="test"></td>               
                                                    </tr>
                                                    <tr>
                                                        <td colspan="7" class="leftside">EMAIL : dailyswipelogistics@gmail.com</td> 
                                                        <td colspan="4" class="leftside">TEL: 021-35879946, CELL:03122699902</td>
                                                        <td class="test"></td>              
                                                        <td colspan="4"><strong>SHIPPER'S SIGNATURE</strong></td>               
                                                    </tr>
                                                </table>
                                            </div>
                                            <div>
                                                
                                            </div>
                                            <div>
                                                <p class="tac">TERMS & CONDITIONS <span style="margin-left: 35px; ">Shipment Via DSL Courier For Documents/Parcels Are Subject To The Following Terms & Conditions</span></p> 
                                                <ul class="ultac">
                                                  <li> DSL courier reserves the rights to inspect the goods to insured that they are capable of carriage to the countries of destination.</li>
                                                  <li> Any Consignments note if not Insured through DSL Courier Service by the Shipper it will be treated ''On Shipper's Risk''</li>
                                                  <li> Any Complained by the shipper should be notified within 24 hours after delivery at destination iin written</li>
                                                  <li> Rates are excusive of any value added tax,duties at destination</li>
                                                  <li> Shipper is liable to provide complete packing list with values of goods</li>
                                              </ul>
                                            </div>
                                                <div class="modal-footer">
                                                    <div class="form-actions">
                                                        <div class="row">
                                                            <div class="col-md-9">
                                                                <div class="row">
                                                                    <div class="col-md-offset-3 col-md-9">
                                                                        <button type="submit" class="btn btn-success addproduct1">Submit</button>                                          
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6"> </div>
                                                        </div>
                                                    </div>
                                                </div>

                            </form>
                        </div>

<!-- End Domestic Form -->


<!-- International Form -->
                        <div id="international">
                            <form id="createorder1"  class="form-horizontal">
                <h3 class="tittle text-center mb-md-5 mb-4">International</h3>

                                            <?php echo e(csrf_field()); ?>

                                                <table>
                                                    <tr>
                                                        <td colspan="4" rowspan="4"  class="test"><img height="100" src="logo2.jpg"></td>               
                                                        <td colspan="5" rowspan="4" ><img height="100" src="bar.png" class="imgbar"></td>
                                                        <td colspan="3">DSL CLIENT A/C # </td>
                                                        <td>DATE</td>
                                                        <td colspan="3">
                                                            <strong><u><?php echo e(\Carbon\Carbon::now()->format('l d-M-Y')); ?></u></strong>
                                                            <input type="hidden" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" name="date">
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="test">For Office Use</td>
                                                        <td colspan="4"><strong>SHIPMENTS DETAIL'S </strong></td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3">TRACKING VIA </td>
                                                        <td colspan="2">ORIGIN </td>
                                                        <td colspan="2">DESTINATION</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="test">For Office Use</td>
                                                        <td colspan="2">
                                                            <input class="form-control" type="text" name="origin" value="PK" readonly>
                                                        </td>
                                                        <td colspan="2" class="test">
                                                            <select class="form-control"  name="destination">
                                                                <option disabled selected value>Select Destination</option>
                                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="12" class="leftside"><strong>FROM DETAIL'S</strong></td>               
                                                        <td colspan="2">WEIGHT (KG)</td>
                                                        <td colspan="2">WEIGHT (DIM)</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="rightside">SENDER NAME</td>               
                                                        <td colspan="4" class="test">
                                                            <input class="form-control"  type="text" placeholder="Enter Sender Name" name="sender_name">
                                                        </td>
                                                        <td colspan="2">COMPANY NAME</td>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control"  type="text" placeholder="Enter Company Name" name="sender_company">
                                                        </td>
                                                        <td colspan="2" class="test">
                                                            <input class="form-control"  type="text" placeholder="Weight in KG" name="weight_kg">
                                                        </td>
                                                        <td colspan="2" class="test">
                                                            <input class="form-control"  type="text" placeholder="Weight in Dimension" name="weight_dim">
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="rightside">CELL #</td>               
                                                        <td colspan="5" class="test">
                                                            <input class="form-control"  type="text" placeholder="Enter #" name="sender_cell">
                                                        </td>
                                                        <td>LINE #</td>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control"  type="text" placeholder="Enter LINE#" name="sender_line">
                                                        </td>
                                                        <td colspan="2">PIECES</td>
                                                        <td colspan="2">PACKAGE</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="rightside">ADDRESS</td>               
                                                        <td colspan="9" class="test">
                                                            <input class="form-control"  type="text" name="sender_address" placeholder="Enter Address">
                                                        </td>
                                                        <td colspan="2" class="test"><input placeholder="No Of Pieces" class="form-control" type="text" name="pieces"></td>
                                                        <td colspan="2">
                                                            <input class="form-control" type="text" name="package_id" value="MEGA" readonly>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="12" class="test"></td>               
                                                        <td colspan="2">SERVICE TYPE </td>
                                                        <td colspan="2">PAYMENT</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="8" class="test"></td>               
                                                        <td colspan="2">POSTAL CODE</td>
                                                        <td colspan="2" class="test">
                                                            <input class="form-control" placeholder="Enter POSTAL Code" type="text" name="sender_postal">
                                                        </td>
                                                        <td colspan="2">
                                                            <input class="form-control" type="text" name="service_type" value="INTL. Priority" readonly>
                                                        </td>
                                                        <td colspan="2">
                                                            <input type="text" readonly value="Cash" class="form-control">
                                                            <input type="hidden" value="2" name="payment_id">
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="12" class="leftside"><strong>TO DETAIL'S</strong></td>               
                                                        <td colspan="2">CHARGES </td>
                                                        <td colspan="2">PAK RUPEES</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="rightside">RECEIVER NAME </td>               
                                                        <td colspan="4" class="test">
                                                            <input class="form-control" placeholder="Reciver Name" type="text" name="receiver_name">
                                                        </td>
                                                        <td colspan="2">COMPANY NAME</td>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control" placeholder="Enter Company Name" type="text" name="receiver_company">
                                                        </td>
                                                        <td colspan="2">AMOUNT</td>
                                                        <td colspan="2" class="test">
                                                            For Office Use
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="rightside">CELL# </td>               
                                                        <td colspan="5" class="test">
                                                            <input class="form-control" placeholder="Contact Number" type="text" name="receiver_cell">
                                                        </td>
                                                        <td>LINE #</td>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control" placeholder="Enter Line#" type="text" name="receiver_line">
                                                        </td>
                                                        <td colspan="2">GST%</td>
                                                        <td colspan="2" class="test">
                                                            For Office Use
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="rightside">ADDRESS</td>               
                                                        <td colspan="9" class="test">
                                                            <input class="form-control" placeholder="Enter Address" type="text" name="receiver_address">
                                                        </td>
                                                        <td colspan="2">DISCOUNT</td>
                                                        <td colspan="2" class="test">For Office Use</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="12" class="test"></td>               
                                                        <td colspan="2">TOTAL</td>
                                                        <td colspan="2" class="test">
                                                            For Office Use
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="8" class="test"></td>               
                                                        <td colspan="2">POSTAL CODE</td>
                                                        <td colspan="2" class="test">
                                                            <input class="form-control" placeholder="Reciver POSTAL" type="text" name="receiver_postal">
                                                        </td>
                                                        <td colspan="4" rowspan="6" width="1px">"i confirm and affirm that i have understood and agree on all the rates and terms and conditions should hereinafter and that all details given here in are true and correct. This execution of this consignment note is prima facia evidence of the conclusions of contract between shipper & DSL"</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="8"><strong>COMMODITY DESCRIPTION</strong></td>               
                                                        <td colspan="2">DOX / NON DOX </td>
                                                        <td colspan="2">INVOICE</td>              
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control" placeholder="Product Name" type="text" name="name[]">
                                                        </td>               
                                                        <td class="test">
                                                            <input class="form-control" placeholder="Qty" type="text" name="quantity[]">
                                                        </td>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control" id="e1" placeholder="Product Name" type="text" name="name[]">
                                                        </td>
                                                        <td class="test">
                                                            <input class="form-control" id="e2" placeholder="Qty" type="text" name="quantity[]">
                                                        </td>
                                                        <td colspan="2" class="test">
                                                            For Office Use
                                                        </td>
                                                        For Office Use</td>               

                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control" id="e3" placeholder="Product Name" type="text" name="name[]">
                                                        </td>               
                                                        <td class="test">
                                                            <input class="form-control" id="e4" placeholder="Qty" type="text" name="quantity[]">
                                                        </td>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control" id="e5" placeholder="Product Name" type="text" name="name[]">
                                                        </td>
                                                        <td class="test">
                                                            <input class="form-control" id="e6" placeholder="Qty" type="text" name="quantity[]">
                                                        </td>
                                                        <td colspan="2">TOTAL CONTENTS </td>
                                                        <td colspan="2">VALUE $</td>               
                                                    </tr>
                                                    <tr>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control" id="e7" placeholder="Product Name" type="text" name="name[]">
                                                        </td>               
                                                        <td class="test">
                                                            <input class="form-control" id="e8" placeholder="Qty" type="text" name="quantity[]">
                                                        </td>
                                                        <td colspan="3" class="test">
                                                            <input class="form-control" id="e9" placeholder="Product Name" type="text" name="name[]">
                                                        </td>
                                                        <td class="test">
                                                            <input class="form-control" id="e10" placeholder="Qty" type="text" name="quantity[]">
                                                        </td>
                                                        <td colspan="2">
                                                            For Office Use
                                                        </td>
                                                        <td colspan="2" class="test">
                                                            For Office Use
                                                        </td>              
                                                    </tr>
                                                    <tr>
                                                        <td colspan="10" width="1px" class="leftside">OFFICE: SHOP 46-A BC-5-6 1ST FLOOR, SASI ARCADE, BLOCK-7 CLIFTON KARACHI- 75600</td>
                                                        <td class="test"></td>               
                                                        <td class="test"></td>               
                                                    </tr>
                                                    <tr>
                                                        <td colspan="7" class="leftside">EMAIL : dailyswipelogistics@gmail.com</td> 
                                                        <td colspan="4" class="leftside">TEL: 021-35879946, CELL:03122699902</td>
                                                        <td class="test"></td>              
                                                        <td colspan="4"><strong>SHIPPER'S SIGNATURE</strong></td>               
                                                    </tr>
                                                </table>
                                            <div>
                                                <p class="tac">TERMS & CONDITIONS <span style="margin-left: 35px; ">Shipment Via DSL Courier For Documents/Parcels Are Subject To The Following Terms & Conditions</span></p> 
                                                <ul class="ultac">
                                                  <li> DSL courier reserves the rights to inspect the goods to insured that they are capable of carriage to the countries of destination.</li>
                                                  <li> Any Consignments note if not Insured through DSL Courier Service by the Shipper it will be treated ''On Shipper's Risk''</li>
                                                  <li> Any Complained by the shipper should be notified within 24 hours after delivery at destination iin written</li>
                                                  <li> Rates are excusive of any value added tax,duties at destination</li>
                                                  <li> Shipper is liable to provide complete packing list with values of goods</li>
                                              </ul>
                                            </div>
                                                <div class="modal-footer">
                                                    <div class="form-actions">
                                                        <div class="row">
                                                            <div class="col-md-9">
                                                                <div class="row">
                                                                    <div class="col-md-offset-3 col-md-9">
                                                                        <button type="submit" class="btn btn-success addproduct1">Submit</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6"> </div>
                                                        </div>
                                                    </div>
                                                </div>

                            </form>
                        </div>
                        <!-- End International -->
                </div>
            </div>
        </div>
    </section>


<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <script type="text/javascript">
        $('input').prop('required',true);
        $('select').prop('required',true);
        for (var i=1 ; i < 11; i++) 
        {
            $('#e'+i).prop('required',false);
            $('#c'+i).prop('required',false);
        }
        $('#domestic').hide();
        $('#international').hide();

        $('#d').on('click',function(){
            $('#domestic').show();
            $('#international').hide();
        });
        $('#i').on('click',function(){
            $('#domestic').hide();
            $('#international').show();
        });

        $(document).on('submit','#createorder',function(event)
        {
            event.preventDefault();
            var formdata = $('#createorder').serialize();
            console.log(formdata); 
            $.ajax
            ({
                'type':     'POST',
                'url':      '<?php echo e(url('/addordercu1')); ?>',
                'data':     formdata,
                success: function(reponse)
                {
                    alert('Order Successfully Added !', 'Success Alert');
                    // $('#createorder').trigger("reset");
                },
                error : function(error)
                {
                    alert('Server Down!', 'Error Alert', {timeOut: 5000});
                }
            });
        });

        $(document).on('submit','#createorder1',function(event)
        {
            event.preventDefault();
            var formdata = $('#createorder1').serialize();
            console.log(formdata); 
            $.ajax
            ({
                'type':     'POST',
                'url':      '<?php echo e(url('/addordercu2')); ?>',
                'data':     formdata,
                success: function(reponse)
                {
                    alert('Order Successfully Added !', 'Success Alert');
                    // $('#createorder1').trigger("reset");
                },
                error : function(error)
                {
                    alert('Server Down!', 'Error Alert', {timeOut: 5000});
                }
            });
        });
        
    </script>
  