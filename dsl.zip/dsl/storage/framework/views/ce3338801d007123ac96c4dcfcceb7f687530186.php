
	<?php $__env->startSection('body'); ?>

		<style>
                *
                {

                    font-family: roboto;
                    font-size: 15px;
                }
                table, td, th {
                  border: 1px solid black;
                }

                table {
                  border-collapse: collapse;
                  width: 100%;
                }

                th {
                  text-align: left;
                }

                td
                {
                  text-align: center;
                }

                img.imgbar {
                    width: 314px;
                }

                td.rightside {
                    text-align: right;
                }

                td.leftside {
                    text-align: left;
                }

                td.test {
                    width: 70px;
                }

                p.tac {
                    font-size: 20px;
                    margin-top: 5px;
                    margin-bottom: 5px;
                }
                ul.ultac {
                    padding-left: 18px;
                    margin-top: 0px;
                }
    	</style>  

    	<table>
    		<tr>
    			<td colspan="4" rowspan="4"  class="test"><img height="100" src="logo2.jpg"></td>               
    			<td colspan="5" rowspan="4" ><img height="100" src="bar.png" class="imgbar"></td>
    			<td colspan="3">DSL CLIENT A/C # </td>
    			<td>DATE</td>
    			<td colspan="3">
    				<strong><u><?php echo e($order[0]->date); ?></u></strong>
    				<input type="hidden" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" name="date">
    			</td>
    		</tr>
    		<tr>
    			<td colspan="3" class="test"><?php echo e($order[0]->account_no); ?></td>
    			<td colspan="4"><strong>SHIPMENTS DETAIL'S </strong></td>
    		</tr>
    		<tr>
    			<td colspan="3">TRACKING VIA </td>
    			<td colspan="2">ORIGIN </td>
    			<td colspan="2">DESTINATION</td>
    		</tr>
    		<tr>
    			<td colspan="3" class="test"><?php echo e($order[0]->ref_no); ?></td>
    			<td colspan="2">
    				<?php echo e($order[0]->origin); ?>

    			</td>
    			<td colspan="2" class="test">
    				<?php echo e($order[0]->destination); ?>

    			</td>
    		</tr>
    		<tr>
    			<td colspan="12" class="leftside"><strong>FROM DETAIL'S</strong></td>               
    			<td colspan="2">WEIGHT (KG)</td>
    			<td colspan="2">WEIGHT (DIM)</td>
    		</tr>
    		<tr>
    			<td colspan="3" class="rightside">SENDER NAME</td>               
    			<td colspan="4" class="test">
    				<?php echo e($order[0]->sender_name); ?>

    			</td>
    			<td colspan="2">COMPANY NAME</td>
    			<td colspan="3" class="test">
    				<?php echo e($order[0]->sender_company); ?>

    			</td>
    			<td colspan="2" class="test">
    				<?php echo e($order[0]->weight_kg); ?>

    			</td>
    			<td colspan="2" class="test">
    				<?php echo e($order[0]->weight_dim); ?>

    			</td>
    		</tr>
    		<tr>
    			<td colspan="3" class="rightside">CELL #</td>               
    			<td colspan="5" class="test">
    				<?php echo e($order[0]->sender_cell); ?>

    			</td>
    			<td>LINE #</td>
    			<td colspan="3" class="test">
    				<?php echo e($order[0]->sender_line); ?>

    			</td>
    			<td colspan="2">PIECES</td>
    			<td colspan="2">PACKAGE</td>
    		</tr>
    		<tr>
    			<td colspan="3" class="rightside">ADDRESS</td>               
    			<td colspan="9" class="test">
    				<?php echo e($order[0]->sender_address); ?>

    			</td>
    			<td colspan="2" class="test">
    				<?php echo e($order[0]->pieces); ?>

    			</td>
    			<td colspan="2">
    				<?php echo e($order[0]->package_id); ?>

    			</td>
    		</tr>
    		<tr>
    			<td colspan="12" class="test"></td>               
    			<td colspan="2">SERVICE TYPE </td>
    			<td colspan="2">PAYMENT</td>
    		</tr>
    		<tr>
    			<td colspan="8" class="test"></td>               
    			<td colspan="2">POSTAL CODE</td>
    			<td colspan="2" class="test">
    				<?php echo e($order[0]->sender_postal); ?>

    			</td>
    			<td colspan="2">
    				<?php echo e($order[0]->service_type); ?>

    			</td>
    			<td colspan="2">
    				<?php echo e($order[0]->payment_id); ?>

    			</td>
    		</tr>
    		<tr>
    			<td colspan="12" class="leftside"><strong>TO DETAIL'S</strong></td>               
    			<td colspan="2">CHARGES </td>
    			<td colspan="2">PAK RUPEES</td>
    		</tr>
    		<tr>
    			<td colspan="3" class="rightside">RECEIVER NAME </td>               
    			<td colspan="4" class="test">
    				<?php echo e($order[0]->receiver_name); ?>

    			</td>
    			<td colspan="2">COMPANY NAME</td>
    			<td colspan="3" class="test">
    				<?php echo e($order[0]->receiver_company); ?>

    			</td>
    			<td colspan="2">AMOUNT</td>
    			<td colspan="2" class="test">
    				<?php echo e($order[0]->amount); ?>

    			</td>
    		</tr>
    		<tr>
    			<td colspan="3" class="rightside">CELL# </td>               
    			<td colspan="5" class="test">
    				<?php echo e($order[0]->receiver_cell); ?>

    			</td>
    			<td>LINE #</td>
    			<td colspan="3" class="test">
    				<?php echo e($order[0]->receiver_line); ?>

    			</td>
    			<td colspan="2">GST%</td>
    			<td colspan="2" class="test">
    				<?php echo e($order[0]->gst); ?>

    			</td>
    		</tr>
    		<tr>
    			<td colspan="3" class="rightside">ADDRESS</td>               
    			<td colspan="9" class="test">
    				<?php echo e($order[0]->receiver_address); ?>

    			</td>
    			<td colspan="2">DISCOUNT</td>
    			<td colspan="2" class="test">
    				<?php echo e($order[0]->discount); ?>

    			</td>
    		</tr>
    		<tr>
    			<td colspan="12" class="test"></td>               
    			<td colspan="2">TOTAL</td>
    			<td colspan="2" class="test">
    				<?php echo e($order[0]->total); ?>

    			</td>
    		</tr>
    		<tr>
    			<td colspan="8" class="test"></td>               
    			<td colspan="2">POSTAL CODE</td>
    			<td colspan="2" class="test">
    				<?php echo e($order[0]->receiver_postal); ?>

    			</td>
    			<td colspan="4" rowspan="6" width="1px">"i confirm and affirm that i have understood and agree on all the rates and terms and conditions should hereinafter and that all details given here in are true and correct. This execution of this consignment note is prima facia evidence of the conclusions of contract between shipper & DSL"</td>
    		</tr>
    		<tr>
    			<td colspan="8"><strong>COMMODITY DESCRIPTION</strong></td>               
    			<td colspan="2">DOX / NON DOX </td>
    			<td colspan="2">INVOICE</td>              
    		</tr>
    		<tr>
    			<td colspan="3" class="test">
    				<?php echo e($product[0]->name ?? '-'); ?>

    			</td>               
    			<td class="test">
    				<?php echo e($product[0]->quantity ?? '-'); ?>

    			</td>
    			<td colspan="3" class="test">
    				<?php echo e($product[1]->name ?? '-'); ?>

    			</td>
    			<td class="test">
    				<?php echo e($product[1]->quantity ?? '-'); ?>

    			</td>
    			<td colspan="2" class="test">
    				<?php echo e($order[0]->dutiable); ?>

    			</td>
    			<td colspan="2">
    				<?php echo e($order[0]->insurance); ?>

    			</td>               

    		</tr>
    		<tr>
    			<td colspan="3" class="test">
    				<?php echo e($product[2]->name ?? '-'); ?>

    			</td>               
    			<td class="test">
    				<?php echo e($product[2]->quantity ?? '-'); ?>

    			</td>
    			<td colspan="3" class="test">
    				<?php echo e($product[3]->name ?? '-'); ?>

    			</td>
    			<td class="test">
    				<?php echo e($product[3]->quantity ?? '-'); ?>

    			</td>
    			<td colspan="2">TOTAL CONTENTS </td>
    			<td colspan="2">VALUE $</td>               
    		</tr>
    		<tr>
    			<td colspan="3" class="test">
    				<?php echo e($product[4]->name ?? '-'); ?>

    			</td>               
    			<td class="test">
    				<?php echo e($product[4]->quantity ?? '-'); ?>

    			</td>
    			<td colspan="3" class="test">
    				<?php echo e($product[5]->name ?? '-'); ?>

    			</td>
    			<td class="test">
    				<?php echo e($product[5]->quantity ?? '-'); ?>

    			</td>
    			<td colspan="2">
    				<?php echo e($order[0]->contents); ?>

    			</td>
    			<td colspan="2" class="test">
    				<?php echo e($order[0]->value); ?>

    			</td>              
    		</tr>
    		<tr>
    			<td colspan="10" width="1px" class="leftside">OFFICE: SHOP 46-A BC-5-6 1ST FLOOR, SASI ARCADE, BLOCK-7 CLIFTON KARACHI- 75600</td>
    			<td class="test"></td>               
    			<td class="test"></td>               
    		</tr>
    		<tr>
    			<td colspan="7" class="leftside">EMAIL : dailyswipelogistics@gmail.com</td> 
    			<td colspan="4" class="leftside">TEL: 021-35879946, CELL:03122699902</td>
    			<td class="test"></td>              
    			<td colspan="4"><strong>SHIPPER'S SIGNATURE</strong></td>               
    		</tr>
    	</table>
    	<div>
    		<p class="tac">TERMS & CONDITIONS <span style="margin-left: 35px; ">Shipment Via DSL Courier For Documents/Parcels Are Subject To The Following Terms & Conditions</span></p> 
    		<ul class="ultac">
    			<li> DSL courier reserves the rights to inspect the goods to insured that they are capable of carriage to the countries of destination.</li>
    			<li> Any Consignments note if not Insured through DSL Courier Service by the Shipper it will be treated ''On Shipper's Risk''</li>
    			<li> Any Complained by the shipper should be notified within 24 hours after delivery at destination iin written</li>
    			<li> Rates are excusive of any value added tax,duties at destination</li>
    			<li> Shipper is liable to provide complete packing list with values of goods</li>
    		</ul>
    	</div>
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('script'); ?>
	<script type="text/javascript">
		window.print();
	</script>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>