
<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- banner-text -->
    <!-- ab -->
    <?php echo $__env->yieldContent('headerlinks'); ?>
    <?php echo $__env->yieldContent('headernavigations'); ?>
    <!-- /breadcrumb -->
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="/">Home</a>
        </li>
        <li class="breadcrumb-item active">Services</li>
    </ol>
    <section class="banner-bottom-w3ls py-lg-5 py-md-5 py-3">
        <fieldset>
            <legend>Sender Details</legend>
            <div class="form-group">
                <label class="control-label">Sender Name: <?php echo e($order[0]->sender_name); ?></label>
            </div>
            <div class="form-group">
                <label class="control-label">Sender Cell: 0<?php echo e($order[0]->sender_cell); ?></label>
            </div>
            <div class="form-group">
                <label class="control-label">Sender Company: <?php echo e($order[0]->sender_company); ?></label>
            </div>
            <div class="form-group">
                <label class="control-label">Sender Address: <?php echo e($order[0]->sender_address); ?></label>
            </div>
        </fieldset>
        <fieldset>
            <legend>Receiver Details</legend>
            <div class="form-group">
                <label class="control-label">Receiver Name: <?php echo e($order[0]->receiver_name); ?></label>
            </div>
            <div class="form-group">
                <label class="control-label">Receiver Cell: <?php echo e($order[0]->receiver_cell); ?></label>
            </div>
            <div class="form-group">
                <label class="control-label">Receiver Company: <?php echo e($order[0]->receiver_company); ?></label>
            </div>
            <div class="form-group">
                <label class="control-label">Receiver Address: <?php echo e($order[0]->receiver_address); ?></label>
            </div>
        </fieldset>
        <fieldset>
            <legend>Track Details</legend>
            <div class="form-group">
                <label class="control-label">BOOKED Time: <?php echo e(\Carbon\Carbon::parse($order[0]->booked_date)->format('l d F Y h:i A ') ?? 'NULL'); ?></label>
            </div>
            <div class="form-group">
                <label class="control-label">RECEIVED At DSL: <?php echo e(\Carbon\Carbon::parse($order[0]->dsl_date)->format('l d F Y h:i A ') ?? 'NULL'); ?></label>
            </div>
            <div class="form-group">
                <label class="control-label">In TRANSIT: <?php echo e(\Carbon\Carbon::parse($order[0]->transit_date)->format('l d F Y h:i A ') ?? 'NULL'); ?></label>
            </div>
            <div class="form-group">
                <label class="control-label">Out For DELIVERY: <?php echo e(\Carbon\Carbon::parse($order[0]->out_date)->format('l d F Y h:i A ') ?? 'NULL'); ?></label>
            </div>
            <div class="form-group">
                <label class="control-label">DELIVERED: <?php echo e(\Carbon\Carbon::parse($order[0]->deliever_date)->format('l d F Y h:i A ') ?? 'NULL'); ?></label>
            </div>
        </fieldset>
    </section>
    



    <section class="banner-bottom-w3ls bg-dark py-lg-5 py-md-5 py-3">
        <div class="container">
            <div class="inner-sec-w3layouts py-lg-5 py-3">
                <h3 class="tittle text-center text-white mb-md-5 mb-4">DSL KARACHI SERVICES</h3>
                <div class="row">
                    <div class="col-lg-6 about-in text-left">
                        <div class="card">
                            <div class="card-body">
                                <i class="fab fa-docker mb-2"></i>
                                <h5 class="card-title ctcolor">COURIERS SERVICE</h5>
                                <p class="card-text">OVERNIGHT</p>
                                <p class="card-text">2ND DAY</p>
                                <p class="card-text">SAME DAY</p>
                                <p class="card-text">TIME PAY</p>
                                <p class="card-text">UNOFFICAL TIME</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 about-in text-left">
                        <div class="card">
                            <div class="card-body">
                                <i class="far fa-clock mb-2"></i>
                                <h5 class="card-title ctcolor">COD SERVICE</h5>
                                <p class="card-text">OVERNIGHT</p>
                                <p class="card-text">2ND DAY</p>
                                <p class="card-text">SAME DAY</p>
                                <p class="card-text">TIME PAY</p>
                                <p class="card-text">UNOFFICAL TIME</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="banner-bottom-w3ls py-md-5 py-4">
        <div class="container">
            <div class="inner-sec-w3layouts py-md-5 py-4">
                <h3 class="tittle text-center mb-md-5 mb-4">
                    DSL KARACHI DELIVERIES</h3>
                <!--/services-grids-->
                <div class="row blog-sec">
                                        <div class="col-lg-3 about-in text-left">
                        <div class="card">
                            <div class="card-body">
                                <i class="fab fa-docker mb-2"></i>
                                <h5 class="card-title ">PARCEL PICKNDROP</h5>
                                <p class="card-text">SAME DAY</p>
                                <p class="card-text">TIME PAY</p>
                                <p class="card-text">UNOFFICAL TIME</p>
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-3 about-in text-left">
                        <div class="card">
                            <div class="card-body">
                                <i class="far fa-clock mb-2"></i>

                                <h5 class="card-title ">CAKE DELIVERY</h5>
                                <p class="card-text">SAME DAY</p>
                                <p class="card-text">TIME PAY</p>
                                <p class="card-text">UNOFFICAL TIME</p>                            
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 about-in text-left">
                        <div class="card">
                            <div class="card-body">
                                <i class="far fa-money-bill-alt mb-2"></i>
                                <h5 class="card-title ">FOOD DELIVERY</h5>
                                <p class="card-text">SAME DAY</p>
                                <p class="card-text">TIME PAY</p>
                                <p class="card-text">UNOFFICAL TIME</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 about-in text-left">
                        <div class="card">
                            <div class="card-body">
                                <i class="far fa-money-bill-alt mb-2"></i>
                                <h5 class="card-title ">SURPRISE DELIVERY</h5>
                                <p class="card-text">SAME DAY</p>
                                <p class="card-text">TIME PAY</p>
                                <p class="card-text">UNOFFICAL TIME</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
