
<?php $__env->startSection('body'); ?>
<br><br>

<div class="portlet-body form">
  <?php echo e(csrf_field()); ?>

  <div class="form-group">
    <div class="portlet-body" id="items">
        <div class="table-scrollable">
            <table class="table table-hover table-light" id="myTable">
                <thead>
                    <tr>
                        <th>Order Code</th>
                        <th>Orderdate</th>
                        <th>Customer Name</th>
                        <th>DeliveryPoint</th>
                        <th>Destination</th>
                        <th>Order Type</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>  
    </div>
</div>

             <!--begin::Show Modal-->
                        <div class="modal fade" id="showmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">
                                            Added Products
                                        </h5>
                                    </div>
                                    <div class="modal-body">
                                        <table class="table table-scrollable">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Quantity</th>
                                                    <th>Amount/Piece</th>
                                                </tr>
                                            </thead>
                                            <tbody id="pbody">
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="modal-footer">

                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-offset-3 col-md-9">
                                                            
                                                            <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6"> </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
            <!--end:: Show Modal-->

            <!--begin:: Show Product Detail Modal-->
                        <div class="modal fade" id="detailmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">
                                            Added Products
                                        </h5>
                                    </div>
                                    <div class="modal-body">
                                        <table class="table table-scrollable">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Length</th>
                                                    <th>Width</th>
                                                    <th>Height</th>
                                                    <th>Dimensional Weight</th>
                                                    <th>Quantity</th>
                                                    <th>Amount/Piece</th>
                                                </tr>
                                            </thead>
                                            <tbody id="pdbody">
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="modal-footer">

                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-offset-3 col-md-9">
                                                            
                                                            <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6"> </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
            <!--end:: Show Product Detail Modal-->


<?php $__env->stopSection(); ?>


 <?php $__env->startSection('script'); ?>
    
    <script type="text/javascript">
        $(document).ready(function()
            {
                $('#myTable').DataTable().destroy();
                $('#myTable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "ajax": "<?php echo e(route('creditorders')); ?>",
                    "columns":[
                        { "data": "ordercode" },
                        { "data": "date" },
                        { "data": "sender_name" },
                        { "data": "name1"},
                        { "data": "name2"},
                        { "data": "stname"},
                        { "data": "status"},
                        { "data": "action"},
                    ]
                });
            });

        $(document).ready(function()
        {
            $(document).on('click','.pname',function()
            {
                console.log('name btn');
                // $('#showmodal').modal('toggle');
                $('#detailmodal').modal('show');
                var p_id = $(this).data('p_id');

                $.ajax({
                    url:"<?php echo e(route('productdetail')); ?>",
                    type:"GET",
                    data:{
                        // "_token":$('input[name=_token]'),
                        "id":p_id
                    },
                    success:function(data)
                    {
                        console.log('Data: \n'+ data);
                        data = JSON.parse(data,true);
                        console.log('Data: \n'+ data);
                        var html  = '';
                        $('#pdbody').html(html);
                            // console.log('i:'+i);
                            html+= '<tr>';
                            html+= '<td>' +data[0]['name']+ '</td>';
                            html+= '<td>' +data[0]['length'] +'</td>';
                            html+= '<td>' +data[0]['width']+ '</td>';
                            html+= '<td>' +data[0]['height'] +'</td>';
                            html+= '<td>' +data[0]['dimensional_weight'] +'</td>';
                            html+= '<td>' +data[0]['quantity'] +'</td>';
                            html+= '<td>' +data[0]['amount_pc'] +'</td>';
                            html+= '</tr>';
                            $('#pdbody').append(html);
                    }
                });
            });
        });

        $(document).ready(function()
        {
            $(document).on('click','.showproduct',function(){
                var key = $(this).attr('id');
                console.log('Id'+key);

                var id = $(this).data('id');
                console.log('ID: '+id);
                $.ajax({
                    'type': 'POST',
                    'url' : "<?php echo e(route('showproduct')); ?>",
                    'data': {
                        'id':id,
                        '_token':$('input[name=_token]').val()
                    },
                    success:function(data)
                    {

                        console.log('Data: \n'+data);
                        data = JSON.parse(data,true);
                        console.log('Data: \n'+data);
                        var html  = '';
                        $('#pbody').html(html);
                        for(var i=0; i<data.length; i++)
                        {
                            console.log('i')
                            console.log(i);
                            html+= '<tr>';
                            html+= '<td><button class="btn-xs btn-primary pname" data-p_id="'+ data[i]['p_id'] +'" </button>'+data[i]['name']+'</td>';
                            html+= '<td>'+data[i]['quantity']+'</td>';
                            html+= '<td>'+data[i]['amount_pc']+'</td>';
                            // html+= '<td><button class="btn-xs btn-warning updatebtn" data-id="'+ id + '" data-p_id="'+ data[i]['p_id'] +'"> Update </button></td>';
                            html+= '<td><button class="btn-xs btn-danger removebtn" data-id="'+  id + '" data-p_id="'+ data[i]['p_id'] +'"> Remove</button></td>';
                            html+= '</tr>';
                        }
                        $('#pbody').append(html);
                        $('#useful').val(key);
                    },
                    error:function()
                    {
                        toastr.error('Server Down!', 'Error Alert', {timeOut: 5000});
                    }
                });
            });
        });

    </script>
                    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>