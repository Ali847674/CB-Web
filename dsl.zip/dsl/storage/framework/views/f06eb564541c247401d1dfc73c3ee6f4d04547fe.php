
<?php $__env->startSection('body'); ?>
<button type="button" class="btn btn-warning" data-target="#trans" data-toggle="modal">Transaction</button>
<button type="button" class="btn btn-danger" data-target="#pc" data-toggle="modal">Pitty Cash</button>
<br><br>
<style type="text/css">
    select { width: 400px; text-align-last:center; }
</style>

            <div class="portlet-body form">
                <div class="portlet-body" id="items">
                    <div class="table-scrollable">
                        <table class="table-responsive table table-hover table-light" id="myTable">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>DSL</th>
                                    <th>KN</th>
                                    <th>Fuel</th>
                                    <th>Purch</th>
                                    <th>Bilty</th>
                                    <th>Entity</th>
                                    <th>Sales</th>
                                    <th>Total (DSL+KN )T1</th>
                                    <th>Total (F+P+B+E+S) T2</th>
                                    <th>Pitty Cash</th>
                                    <th>(T1-T2) GRAND_TOTAL</th>
                                </tr>
                            </thead>
                        </table>
                    </div>  
                </div>
            </div>

            <!--begin::Transaction Modal-->
                        <div class="modal fade" id="trans" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Create Transaction</h5>
                                    </div>
                                    <div class="modal-body">
                                        <center>
                                            <form id="thisform">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="form-group" style="width: 50%;">
                                                    <label class="control-label">Transaction Date</label>
                                                    <input class="form-control" placeholder="Transaction Amount" type="text" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" style="text-align:center;" readonly name="transaction_date" required>
                                                </div>
                                                <div class="form-group" style="width: 50%;">
                                                    <label class="control-label">Amount</label>
                                                    <input class="form-control" style="text-align:center;" placeholder="Transaction Amount" type="number" name="amount" required>
                                                </div>
                                                <div class="form-group" style="width: 50%;">
                                                    <label class="control-label">Amount Type</label>
                                                    <select class="form-control" style="text-align:center;" name="amount_type" required>
                                                        <option selected disabled value>Select Transaction Type</option>
                                                        <?php $__currentLoopData = $acc_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($value->name); ?>"><?php echo e($value->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="col-md-offset-2 col-md-9">
                                                    <button type="submit" class="btn green addproduct1">Submit</button>
                                                    <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                </form>
                                            </div>
                                        </center>
                                    </div>
                                    <div class="modal-footer">
                                        
                                    </div>

                                </div>

                            </div>
                        </div>
            <!--end:: Transaction Modal-->

            <!--begin::Pitty Cash Modal-->
                        <div class="modal fade" id="pc" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h3 class="modal-title" id="exampleModalLabel">Today's Amount Of Pitty Cash</h3>
                                    </div>
                                    <div class="modal-body">
                                        <center>
                                            <form id="pcform">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="form-group" style="width: 50%;">
                                                    <label class="control-label">Transaction Date</label>
                                                    <input class="form-control" placeholder="Transaction Amount" type="text" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" style="text-align:center;" readonly name="transaction_date" required>
                                                </div>
                                                <div class="form-group" style="width: 50%;">
                                                    <label class="control-label">Amount</label>
                                                    <input class="form-control" style="text-align:center;" placeholder="Pitty Cash Amount" type="number" name="amount" required>
                                                </div>
                                                
                                                <div class="col-md-offset-2 col-md-9">
                                                    <button type="submit" class="btn green addproduct1">Submit</button>
                                                    <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                </form>
                                            </div>
                                        </center>
                                    </div>
                                    <div class="modal-footer">
                                        
                                    </div>

                                </div>

                            </div>
                        </div>
            <!--end:: Pitty Cash Modal-->


<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>    
    <script type="text/javascript">
        jQuery(document).ready(function()
        {
            $('#myTable').DataTable().destroy();
            $('#myTable').DataTable({
                "processing":true,
                "serverside":true,
                "ajax":"<?php echo e(route('accountsdata')); ?>",
                "columns":
                [
                    {"data":"transaction_date"},
                    {"data":"DSL"},
                    {"data":"KN"},
                    {"data":"FUEL"},
                    {"data":"PURCH"},
                    {"data":"BILTY"},
                    {"data":"ENTITY"},
                    {"data":"SALES"},
                    {"data":"T1"},
                    {"data":"T2"},
                    {"data":"PC"},
                    {"data":"GRAND_TOTAL"},
                ]
            });
        });
        $(document).on('submit', '#thisform', function(event)
        {
            event.preventDefault();
            var formdata = $('#thisform').serialize();
            $.ajax({
                url: '<?php echo e(route('submitamount')); ?>',
                type: 'POST',
                data: formdata,
                success:function(data){
                    toastr.success('Amount Updated Successfully','Succes Alert');
                    $('#thisform')[0].reset();
                    $('thisform').trigger("reset");
                    $('#myTable').DataTable().ajax.reload();
                },
                error:function(){
                    toastr.error('Coresponding Server Is Down','Error Alert')
                }
            });
            
        });
        $(document).on('submit', '#pcform', function(event)
        {
            event.preventDefault();
            var formdata = $('#pcform').serialize();
            $.ajax({
                url: '<?php echo e(route('submitpittycash')); ?>',
                type: 'POST',
                data: formdata,
                success:function(data){
                    toastr.success('Pitty Cash Updated Successfully','Succes Alert');
                    $('#thisform')[0].reset();
                    $('pcform').trigger("reset");
                    $('#myTable').DataTable().ajax.reload();
                },
                error:function(){
                    toastr.error('Coresponding Server Is Down','Error Alert')
                }
            });
            
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>