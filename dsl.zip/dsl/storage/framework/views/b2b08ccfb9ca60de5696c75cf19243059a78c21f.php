<?php $__env->startSection('body'); ?>
<button type="button" data-toggle="modal" data-target="#addmodal" class="btn btn-info">Add New Branch</button><br><br>

        
        <div class="portlet-body form">

            <div class="portlet-body" id="items">
                <div class="table-scrollable">
                    <table class="table table-hover table-light" id="myTable">
                        <thead>
                            <tr>
                                <th>Office Id</th>
                                <th>Origin</th>
                                <th>Address</th>
                                <th>Contact</th>
                                <th>Exist Since</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>  
            </div>
        </div>
        

        <!--begin::add Modal-->
                <div class="modal fade" id="addmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">
                               New Office Form
                                </h5>
                            </div>
                            <div class="modal-body">

                                <form  class="form-horizontal" id="addform">

                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-body">


                                            <div class="form-group<?php echo e($errors->has('contact') ? ' has-error' : ''); ?>">
                                                <label for="contact" class="col-md-4 control-label">Contact</label>
                                                <div class="col-md-4">
                                                    <input id="contact" type="text" value="<?php echo e(old('contact')); ?>" class="form-control" name="contact" required>
                                                </div>
                                            </div>

                                            <div class="form-group<?php echo e($errors->has('contact') ? ' has-error' : ''); ?>">
                                                <label for="contact" class="col-md-4 control-label">Origin City</label>
                                                <div class="col-md-4">
                                                    <select name="city_id" class="form-control">
                                                        <option disabled selected value>Select City</option>
                                                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="form-group<?php echo e($errors->has('contact') ? ' has-error' : ''); ?>">
                                                <label for="contact" class="col-md-4 control-label">Address</label>
                                                <div class="col-md-4">
                                                    <input id="contact" type="text" value="<?php echo e(old('address')); ?>" class="form-control" name="address" required>
                                                </div>
                                            </div>


                                        <div class="modal-footer">
                                            <div class="form-actions">
                                                <div class="row">
                                                    <div class="col-md-9">
                                                        <div class="row">
                                                            <div class="col-md-offset-3 col-md-9">
                                                                <button type="submit" class="btn green addproduct1">Submit</button>
                                                                <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6"> </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
        <!--end::add  Modal-->

         <!--begin::update Modal-->
                <div class="modal fade" id="updatemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">
                                Edit Information
                                </h5>
                            </div>
                            <div class="modal-body">

                                <form id="officeupdate" class="form-horizontal"  style="padding: 20px;" enctype="multipart/form-data">


                                    <?php echo e(csrf_field()); ?>

                                        <div class="form-body">
                                            <div class="form-group">
                                                <div class="col-md-9">
                                                    <?php if(Session::has('fields')): ?>
                                                    <span class="myclass">*<?php echo e(session('fields')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-md-9">
                                                <div class="form-group ">
                                                    <label class="control-label col-md-4">
                                                        Id
                                                    </label>
                                                    <div class="col-md-8">
                                                        <input type="text" class="form-control" name="id" id="id" required readonly>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            
                                            <div class="col-md-9">
                                                <div class="form-group<?php echo e($errors->has('contact') ? ' has-error' : ''); ?>">
                                                    <label for="contact" class="col-md-4 control-label">Contact</label>
                                                    <div class="col-md-8">
                                                        <input id="contactu" type="text" value="<?php echo e(old('contact')); ?>" class="form-control" name="contact" required>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-9">
                                                <div class="form-group<?php echo e($errors->has('contact') ? ' has-error' : ''); ?>">
                                                    <label for="contact" class="col-md-4 control-label">Address</label>
                                                    <div class="col-md-8">
                                                        <input id="addressu" type="text" value="<?php echo e(old('address')); ?>" class="form-control" name="address" required>
                                                    </div>
                                                </div>
                                            </div>
                                           
                                        </div>
                                    <div class="modal-footer">
                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-offset-3 col-md-9">
                                                            <button type="submit" class="btn green addproduct1">Submit</button>
                                                            <button type="button" class="btn default" data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6"> </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
        <!--end::update  Modal-->

        <!--begin:: Delete  modal -->
                <div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Delete The Current Order</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <center>
                            <h2>Do You Want To Delete The Current Office</h2>
                            <h3>Once Proceed Cannot Be Revert</h3>
                        </center>
                      </div>
                      <div class="modal-footer">
                        <form id="officedelete">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" id="o_id">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-danger"   >Delete</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
            <!--end:: delete  Modal -->
    
            

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script type="text/javascript">

        jQuery(document).ready(function() {
            $('#myTable').DataTable().destroy();
            $('#myTable').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": "<?php echo e(route('officedata')); ?>",
                "columns":[
                    { "data": "alphaid" },
                    { "data": "origin" },
                    { "data": "address"},
                    { "data": "contact"},
                    { "data": "membersince"},
                    { "data": "action"},
                ]
            });
        });
        $(document).ready(function()
        {

            $(document).on('submit', '#addform', function(event)
            {
                event.preventDefault();
                var formdata = $('#addform').serialize();
                $.ajax({
                    url:'<?php echo e(url('/addoffice')); ?>',
                    type:'POST',
                    data:formdata,
                    success:function(data)
                    {
                        if (data == 'fields') 
                        {
                            toastr.error('Some Fields Are Missing','All Fields Are Required')
                        }
                        else if (data == 'email') 
                        {
                            toastr.error('Email Already Taken By Other User','Integration Contraint')
                        }
                        else if (data == 'success') 
                        {
                            toastr.success('New Office Added Successfully','Succes Alert');
                            $('#addmodal').modal('hide');
                            $('#myTable').DataTable().ajax.reload();
                        }
                    },
                    error:function(){
                        toastr.error('Coresponding Server Is Down','Error Alert')
                    },
                });
            });

            $(document).on('click','.updatebtn',function()
            {
                $('#id').val($(this).data('id'));
                $('#contactu').val($(this).data('contact'));
                $('#addressu').val($(this).data('address'));
            });

            $(document).on('submit', '#officeupdate', function(event)
            {
                event.preventDefault();
                var formdata = $('#officeupdate').serialize();
                $.ajax({
                    url:'<?php echo e(route('updateoffice')); ?>',
                    type:'POST',
                    data:formdata,
                    success:function(data)
                    {
                        if (data == 'fields') 
                        {
                            toastr.error('Some Fields Are Missing','All Fields Are Required')
                        }
                        else if (data == 'email') 
                        {
                            toastr.error('Email Already Taken By Other User','Integration Contraint')
                        }
                        else if (data == 'success') 
                        {
                            toastr.success(" Office's Information Updated Successfully",'Succes Alert');
                            $('#updatemodal').modal('hide');
                            $('#myTable').DataTable().ajax.reload();
                        }
                    },
                    error:function(){
                        toastr.error('Coresponding Server Is Down','Error Alert')
                    },
                });
            });

            $(document).on('click','.deletebtn',function()
            {
                console.log('Hello')
                $('#o_id').val($(this).data('id'));
            });

            $(document).on('submit', '#officedelete', function(event)
            {
                event.preventDefault();
                var formdata = $('#officedelete').serialize();
                $.ajax({
                    url:'<?php echo e(route('deleteoffice')); ?>',
                    type:'GET',
                    data:formdata,
                    success:function(data)
                    {
                        if (data == 'fields') 
                        {
                            toastr.error('Some Fields Are Missing','All Fields Are Required')
                        }
                        else if (data == 'email') 
                        {
                            toastr.error('Email Already Taken By Other User','Integration Contraint')
                        }
                        else if (data == 'success') 
                        {
                            toastr.success('Office Deleted Successfully','Succes Alert');
                            $('#deletemodal').modal('hide');
                            $('#myTable').DataTable().ajax.reload();
                        }
                    },
                    error:function(){
                        toastr.error('Coresponding Server Is Down','Error Alert')
                    },
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>