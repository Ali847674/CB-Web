<?php $__env->startSection('headerlinks'); ?>

<!DOCTYPE html>
<html lang="zxx">

<head>
<style> 
input[type=text] {
    width: 180px;
    box-sizing: border-box;
    border: 2px solid #fff;
    border-radius: 4px;
    color: #fff !important;
    font-size: 16px;
    background-color: transparent;
    /*background-image: url("assets/site/images/searchicon.png");*/
    /*background-size: 10px;*/
    background-position: 10px 10px;
    background-repeat: no-repeat;
    padding: 3px 0px 3px 7px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;

}
button.searchicon {
    background: transparent;
    border: 2px solid #fff;
    border-radius: 4px;
    padding: 3px 7px 3px 7px;
    color: #fff;
    /*width: 40%;*/
    font-weight: bold;
    cursor: pointer;
}

input::placeholder { color: #fff; }
input[type=text]:focus {
  /*width: 80%;*/
}
</style>
    <title>DSL</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <meta name="keywords" content="Shipment a Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script>
        addEventListener("load", function() {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <link href="<?php echo e(URL::asset('assets/site/css/bootstrap.css')); ?>" rel='stylesheet' type='text/css' />
    <link href="<?php echo e(URL::asset('assets/site/css/style.css')); ?>" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/site/css/owl.theme.css')); ?>" type="text/css" media="all">
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/site/css/owl.carousel.css')); ?>" type="text/css" media="screen" property="" />
    <link href="<?php echo e(URL::asset('assets/site/css/contact.css')); ?>" rel='stylesheet' type='text/css' />
    <link href="<?php echo e(URL::asset('assets/site/css/fontawesome-all.css')); ?>" rel="stylesheet">
    
    <link href="<?php echo e(URL::asset('assets/site/css/prettyPhoto.css')); ?>" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/site/css/minimal-slider.css')); ?>" type="text/css" media="all" />
    <link href="<?php echo e(URL::asset('assets/site/css/fontawesome-all.css')); ?>" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Josefin+Sans:100,100i,300,300i,400,400i,600,600i,700,700i" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800" rel="stylesheet">
</head>

<body>
    <div class="mian-content inner-page">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('sidebar'); ?>
        <!-- main image slider container -->

        <div class="slide-window">
            <div class="slide-wrapper" style="width: 300%;">
                <div class="slide">
                    <div class="slide-caption">
                        <p>The right choice</p>
                        <h3>Propel <span>yourself</span> into the future.</h3>

                    </div>
                </div>
                <div class="slide slide2">
                    <div class="slide-caption">
                        <p>Ready to go</p>
                        <h3>Premium Worldwide <span>Logistics</span> Network </h3>


                    </div>
                </div>
                <div class="slide slide3">
                    <div class="slide-caption">
                        <p>The right choice.</p>
                        <h3>Propel <span>yourself</span> into the future.</h3>

                    </div>
                </div>
            </div>
            <div class="slide-controller">
                <div class="slide-control-left">
                    <div class="slide-control-line"></div>
                    <div class="slide-control-line"></div>
                </div>
                <div class="slide-control-right">
                    <div class="slide-control-line"></div>
                    <div class="slide-control-line"></div>
                </div>
            </div>
        </div>
        <!-- main image slider container -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('headernavigations'); ?>
       <div class="header-top-w3layouts">
            <div class="container-fluid">

                <header>
                    <div class="top-head-w3-agile text-left">
                        <div class="row top-content-info-wthree">
                            <div class="col-lg-5 top-content-left">
                                <h6>Call Us : <span>03323486878</span></h6>
                            </div>
                            <div class="col-lg-7 top-content-right">
                                <div class="row">
                                    <div class="col-md-10 callnumber text-left">
                                        <form action="<?php echo e(route('track')); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                           <input type="text" name="search" placeholder="Track Your Cargo.." required>
                                           <button type="submit" class="searchicon"><i class="fas fa-search"></i></button>
                                        </form>
                                    </div>
                                    <div class="col-md-2 top-social-icons p-0">
                                        <ul class="social-icons d-flex justify-content-end">
<!--                                         <li class="mr-1">
                                           <button class="searchicon">TRACK</button>
                                            
                                        </li> -->
                                            <li class="mr-1"><a href="#"><span class="fab fa-facebook-f"></span></a></li>
                                            <li class="mx-1"><a href="#"><span class="fab fa-twitter"></span></a></li>
                                            <li class="mx-1"><a href="#"><span class="fab fa-google-plus-g"></span></a></li>
                                            <li class="mx-1"><a href="#"><span class="fab fa-linkedin-in"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="clearfix"></div>

                    <nav class="navbar navbar-expand-lg navbar-light" id="navbar">
                        <div class="logo text-left">
                            <h1>
                                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                            DSL</a>
                            </h1>
                        </div>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon">
                              
                            </span>

                        </button>

                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ml-lg-auto text-right">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('/')); ?>">Home
                                        <span class="sr-only">(current)</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('/about')); ?>">About</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('/services')); ?>">Services</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('#')); ?>">Rate Calculator</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('/client_request')); ?>"> Request</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('/careers')); ?>"> Careers</a>
                                </li>         
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('/contact')); ?>">Contact</a>
                                </li>
                            </ul>
<!--                             <div class="log-in">
                                <a class="btn text-uppercase" href="#" data-toggle="modal" data-target="#exampleModalCenter">
                                    Sign In</a>
                            </div> -->
                        </div>
                    </nav>
                </header>
            </div>
        </div>
    </div>
    <!-- end of main image slider container -->

    <?php $__env->stopSection(); ?>