-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 25, 2019 at 01:24 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dsl`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `transaction_date` date NOT NULL,
  `DSL` int(11) NOT NULL DEFAULT '0',
  `KN` int(11) NOT NULL DEFAULT '0',
  `FUEL` int(11) NOT NULL DEFAULT '0',
  `PURCH` int(11) NOT NULL DEFAULT '0',
  `BILTY` int(11) NOT NULL DEFAULT '0',
  `ENTITY` int(11) NOT NULL DEFAULT '0',
  `SALES` int(11) NOT NULL DEFAULT '0',
  `T1` int(11) NOT NULL DEFAULT '0',
  `T2` int(11) NOT NULL DEFAULT '0',
  `PC` int(11) NOT NULL DEFAULT '0',
  `GRAND_TOTAL` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `transaction_date`, `DSL`, `KN`, `FUEL`, `PURCH`, `BILTY`, `ENTITY`, `SALES`, `T1`, `T2`, `PC`, `GRAND_TOTAL`, `created_at`, `updated_at`) VALUES
(1, '2019-02-22', 500, 500, 750, 500, 500, 650, 850, 1000, 3250, 20000, 17750, '2019-02-22 13:33:06', '2019-02-22 08:33:06'),
(2, '2019-02-23', 6500, 500, 1500, 10000, 5000, 0, 0, 7000, 16500, 100000, 90500, '2019-02-23 12:10:57', '2019-02-23 07:10:57');

-- --------------------------------------------------------

--
-- Table structure for table `account_types`
--

CREATE TABLE `account_types` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account_types`
--

INSERT INTO `account_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'DSL', '2019-02-22 11:45:43', '2019-02-22 11:45:43'),
(2, 'KN', '2019-02-22 11:45:43', '2019-02-22 11:45:43'),
(3, 'FUEL', '2019-02-22 11:45:57', '2019-02-22 11:45:57'),
(4, 'PURCH', '2019-02-22 11:45:57', '2019-02-22 11:45:57'),
(5, 'BILTY', '2019-02-22 11:46:15', '2019-02-22 11:46:15'),
(6, 'ENTITY', '2019-02-22 11:46:15', '2019-02-22 11:46:15'),
(7, 'SALES', '2019-02-22 11:46:29', '2019-02-22 11:46:29');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `created_at` varchar(50) NOT NULL,
  `updated_at` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `contact`, `image`, `type`, `created_at`, `updated_at`) VALUES
(6, 'waqas', 'waqas@gmail.com', '0123421343', 'public/mainweb/images/gal5.jpg', 'transport', '2019-01-31 09:34:03', '2019-01-31 09:34:03'),
(7, 'faraz', 'faraz', '01341141', 'public/mainweb/images/gal1.jpg', 'Transport', '2019-01-31 09:43:03', '2019-01-31 09:43:03'),
(8, 'ali', 'ali@gmail.com', '0123123123', 'public/mainweb/images/gal3.jpg', 'transport', '2019-01-31 09:43:31', '2019-01-31 09:43:31'),
(9, 'waqas', 'waqas@gmail.com', '90123123', 'public/mainweb/images/ser1.jpg', 'transport', '2019-01-31 09:44:01', '2019-01-31 09:44:01'),
(10, 'Saad', 'saad@gmail.com', '021312312', 'public/mainweb/images/p1.jpg', 'asd', '2019-01-31 10:18:31', '2019-01-31 10:18:31');

-- --------------------------------------------------------

--
-- Table structure for table `careers`
--

CREATE TABLE `careers` (
  `id` int(11) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `about` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `careers`
--

INSERT INTO `careers` (`id`, `file_path`, `about`, `created_at`, `updated_at`) VALUES
(1, 'assets/uploads/1550934345my proposal.docx.docx', 'K', '2019-02-23 15:05:45', '2019-02-23 15:05:45'),
(2, 'assets/uploads/1550939355my proposal.docx.docx', 'Hello', '2019-02-23 16:29:15', '2019-02-23 16:29:15'),
(3, 'assets/uploads/1550939409my proposal.docx.docx', 'Hello', '2019-02-23 16:30:09', '2019-02-23 16:30:09');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `acr` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `acr`, `created_at`, `updated_at`) VALUES
(1, 'Karachi', 'KHI', '2019-02-09 09:58:01', '2019-02-09 09:58:01'),
(2, 'Lahore', 'LHR', '2019-02-09 09:58:01', '2019-02-09 09:58:01'),
(3, 'Islamabad', 'ISL', '2019-02-09 09:58:23', '2019-02-09 09:58:23'),
(4, 'Multan', 'MLT', '2019-02-09 09:58:23', '2019-02-09 09:58:23'),
(5, 'Hyderabad', 'HYD', '2019-02-09 09:58:50', '2019-02-09 09:58:50'),
(6, 'Peshawar', 'PSH', '2019-02-09 09:58:50', '2019-02-09 09:58:50'),
(7, 'Quetta', 'QET', '2019-02-09 09:59:09', '2019-02-09 09:59:09'),
(8, 'Larakana', 'LRK', '2019-02-09 09:59:09', '2019-02-12 10:00:44'),
(9, 'Sukkur', 'SKR', '2019-02-12 11:35:01', '2019-02-12 12:16:47'),
(10, 'Bukkar', 'BKR', '2019-02-12 12:08:01', '2019-02-12 12:08:01'),
(11, 'Kharadr', 'KHR', '2019-02-12 12:15:51', '2019-02-12 12:15:51'),
(12, 'Kashmir', 'KMR', '2019-02-12 12:18:55', '2019-02-12 12:18:55'),
(13, 'Hunza', 'HNZ', '2019-02-12 12:27:15', '2019-02-12 12:27:15'),
(14, 'Sahiwal', 'SWL', '2019-02-14 09:10:00', '2019-02-14 09:10:00');

-- --------------------------------------------------------

--
-- Table structure for table `cn_table`
--

CREATE TABLE `cn_table` (
  `CN` int(11) NOT NULL,
  `detail` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cn_table`
--

INSERT INTO `cn_table` (`CN`, `detail`) VALUES
(1, 'details about cn'),
(2, 'abc'),
(3, 'xyz'),
(4, 'dell'),
(5, 'lenovo'),
(6, 'HP'),
(7, 'ksjldfl');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(11) NOT NULL,
  `acr` varchar(2) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `acr`, `name`) VALUES
(1, 'AF', 'Afghanistan'),
(2, 'AL', 'Albania'),
(3, 'DZ', 'Algeria'),
(4, 'DS', 'American Samoa'),
(5, 'AD', 'Andorra'),
(6, 'AO', 'Angola'),
(7, 'AI', 'Anguilla'),
(8, 'AQ', 'Antarctica'),
(9, 'AG', 'Antigua and Barbuda'),
(10, 'AR', 'Argentina'),
(11, 'AM', 'Armenia'),
(12, 'AW', 'Aruba'),
(13, 'AU', 'Australia'),
(14, 'AT', 'Austria'),
(15, 'AZ', 'Azerbaijan'),
(16, 'BS', 'Bahamas'),
(17, 'BH', 'Bahrain'),
(18, 'BD', 'Bangladesh'),
(19, 'BB', 'Barbados'),
(20, 'BY', 'Belarus'),
(21, 'BE', 'Belgium'),
(22, 'BZ', 'Belize'),
(23, 'BJ', 'Benin'),
(24, 'BM', 'Bermuda'),
(25, 'BT', 'Bhutan'),
(26, 'BO', 'Bolivia'),
(27, 'BA', 'Bosnia and Herzegovina'),
(28, 'BW', 'Botswana'),
(29, 'BV', 'Bouvet Island'),
(30, 'BR', 'Brazil'),
(31, 'IO', 'British Indian Ocean Territory'),
(32, 'BN', 'Brunei Darussalam'),
(33, 'BG', 'Bulgaria'),
(34, 'BF', 'Burkina Faso'),
(35, 'BI', 'Burundi'),
(36, 'KH', 'Cambodia'),
(37, 'CM', 'Cameroon'),
(38, 'CA', 'Canada'),
(39, 'CV', 'Cape Verde'),
(40, 'KY', 'Cayman Islands'),
(41, 'CF', 'Central African Republic'),
(42, 'TD', 'Chad'),
(43, 'CL', 'Chile'),
(44, 'CN', 'China'),
(45, 'CX', 'Christmas Island'),
(46, 'CC', 'Cocos (Keeling) Islands'),
(47, 'CO', 'Colombia'),
(48, 'KM', 'Comoros'),
(49, 'CG', 'Congo'),
(50, 'CK', 'Cook Islands'),
(51, 'CR', 'Costa Rica'),
(52, 'HR', 'Croatia (Hrvatska)'),
(53, 'CU', 'Cuba'),
(54, 'CY', 'Cyprus'),
(55, 'CZ', 'Czech Republic'),
(56, 'DK', 'Denmark'),
(57, 'DJ', 'Djibouti'),
(58, 'DM', 'Dominica'),
(59, 'DO', 'Dominican Republic'),
(60, 'TP', 'East Timor'),
(61, 'EC', 'Ecuador'),
(62, 'EG', 'Egypt'),
(63, 'SV', 'El Salvador'),
(64, 'GQ', 'Equatorial Guinea'),
(65, 'ER', 'Eritrea'),
(66, 'EE', 'Estonia'),
(67, 'ET', 'Ethiopia'),
(68, 'FK', 'Falkland Islands (Malvinas)'),
(69, 'FO', 'Faroe Islands'),
(70, 'FJ', 'Fiji'),
(71, 'FI', 'Finland'),
(72, 'FR', 'France'),
(73, 'FX', 'France, Metropolitan'),
(74, 'GF', 'French Guiana'),
(75, 'PF', 'French Polynesia'),
(76, 'TF', 'French Southern Territories'),
(77, 'GA', 'Gabon'),
(78, 'GM', 'Gambia'),
(79, 'GE', 'Georgia'),
(80, 'DE', 'Germany'),
(81, 'GH', 'Ghana'),
(82, 'GI', 'Gibraltar'),
(83, 'GK', 'Guernsey'),
(84, 'GR', 'Greece'),
(85, 'GL', 'Greenland'),
(86, 'GD', 'Grenada'),
(87, 'GP', 'Guadeloupe'),
(88, 'GU', 'Guam'),
(89, 'GT', 'Guatemala'),
(90, 'GN', 'Guinea'),
(91, 'GW', 'Guinea-Bissau'),
(92, 'GY', 'Guyana'),
(93, 'HT', 'Haiti'),
(94, 'HM', 'Heard and Mc Donald Islands'),
(95, 'HN', 'Honduras'),
(96, 'HK', 'Hong Kong'),
(97, 'HU', 'Hungary'),
(98, 'IS', 'Iceland'),
(99, 'IN', 'India'),
(100, 'IM', 'Isle of Man'),
(101, 'ID', 'Indonesia'),
(102, 'IR', 'Iran (Islamic Republic of)'),
(103, 'IQ', 'Iraq'),
(104, 'IE', 'Ireland'),
(105, 'IL', 'Israel'),
(106, 'IT', 'Italy'),
(107, 'CI', 'Ivory Coast'),
(108, 'JE', 'Jersey'),
(109, 'JM', 'Jamaica'),
(110, 'JP', 'Japan'),
(111, 'JO', 'Jordan'),
(112, 'KZ', 'Kazakhstan'),
(113, 'KE', 'Kenya'),
(114, 'KI', 'Kiribati'),
(115, 'KP', 'Korea, Democratic People\'s Republic of'),
(116, 'KR', 'Korea, Republic of'),
(117, 'XK', 'Kosovo'),
(118, 'KW', 'Kuwait'),
(119, 'KG', 'Kyrgyzstan'),
(120, 'LA', 'Lao People\'s Democratic Republic'),
(121, 'LV', 'Latvia'),
(122, 'LB', 'Lebanon'),
(123, 'LS', 'Lesotho'),
(124, 'LR', 'Liberia'),
(125, 'LY', 'Libyan Arab Jamahiriya'),
(126, 'LI', 'Liechtenstein'),
(127, 'LT', 'Lithuania'),
(128, 'LU', 'Luxembourg'),
(129, 'MO', 'Macau'),
(130, 'MK', 'Macedonia'),
(131, 'MG', 'Madagascar'),
(132, 'MW', 'Malawi'),
(133, 'MY', 'Malaysia'),
(134, 'MV', 'Maldives'),
(135, 'ML', 'Mali'),
(136, 'MT', 'Malta'),
(137, 'MH', 'Marshall Islands'),
(138, 'MQ', 'Martinique'),
(139, 'MR', 'Mauritania'),
(140, 'MU', 'Mauritius'),
(141, 'TY', 'Mayotte'),
(142, 'MX', 'Mexico'),
(143, 'FM', 'Micronesia, Federated States of'),
(144, 'MD', 'Moldova, Republic of'),
(145, 'MC', 'Monaco'),
(146, 'MN', 'Mongolia'),
(147, 'ME', 'Montenegro'),
(148, 'MS', 'Montserrat'),
(149, 'MA', 'Morocco'),
(150, 'MZ', 'Mozambique'),
(151, 'MM', 'Myanmar'),
(152, 'NA', 'Namibia'),
(153, 'NR', 'Nauru'),
(154, 'NP', 'Nepal'),
(155, 'NL', 'Netherlands'),
(156, 'AN', 'Netherlands Antilles'),
(157, 'NC', 'New Caledonia'),
(158, 'NZ', 'New Zealand'),
(159, 'NI', 'Nicaragua'),
(160, 'NE', 'Niger'),
(161, 'NG', 'Nigeria'),
(162, 'NU', 'Niue'),
(163, 'NF', 'Norfolk Island'),
(164, 'MP', 'Northern Mariana Islands'),
(165, 'NO', 'Norway'),
(166, 'OM', 'Oman'),
(167, 'PK', 'Pakistan'),
(168, 'PW', 'Palau'),
(169, 'PS', 'Palestine'),
(170, 'PA', 'Panama'),
(171, 'PG', 'Papua New Guinea'),
(172, 'PY', 'Paraguay'),
(173, 'PE', 'Peru'),
(174, 'PH', 'Philippines'),
(175, 'PN', 'Pitcairn'),
(176, 'PL', 'Poland'),
(177, 'PT', 'Portugal'),
(178, 'PR', 'Puerto Rico'),
(179, 'QA', 'Qatar'),
(180, 'RE', 'Reunion'),
(181, 'RO', 'Romania'),
(182, 'RU', 'Russian Federation'),
(183, 'RW', 'Rwanda'),
(184, 'KN', 'Saint Kitts and Nevis'),
(185, 'LC', 'Saint Lucia'),
(186, 'VC', 'Saint Vincent and the Grenadines'),
(187, 'WS', 'Samoa'),
(188, 'SM', 'San Marino'),
(189, 'ST', 'Sao Tome and Principe'),
(190, 'SA', 'Saudi Arabia'),
(191, 'SN', 'Senegal'),
(192, 'RS', 'Serbia'),
(193, 'SC', 'Seychelles'),
(194, 'SL', 'Sierra Leone'),
(195, 'SG', 'Singapore'),
(196, 'SK', 'Slovakia'),
(197, 'SI', 'Slovenia'),
(198, 'SB', 'Solomon Islands'),
(199, 'SO', 'Somalia'),
(200, 'ZA', 'South Africa'),
(201, 'GS', 'South Georgia South Sandwich Islands'),
(202, 'SS', 'South Sudan'),
(203, 'ES', 'Spain'),
(204, 'LK', 'Sri Lanka'),
(205, 'SH', 'St. Helena'),
(206, 'PM', 'St. Pierre and Miquelon'),
(207, 'SD', 'Sudan'),
(208, 'SR', 'Suriname'),
(209, 'SJ', 'Svalbard and Jan Mayen Islands'),
(210, 'SZ', 'Swaziland'),
(211, 'SE', 'Sweden'),
(212, 'CH', 'Switzerland'),
(213, 'SY', 'Syrian Arab Republic'),
(214, 'TW', 'Taiwan'),
(215, 'TJ', 'Tajikistan'),
(216, 'TZ', 'Tanzania, United Republic of'),
(217, 'TH', 'Thailand'),
(218, 'TG', 'Togo'),
(219, 'TK', 'Tokelau'),
(220, 'TO', 'Tonga'),
(221, 'TT', 'Trinidad and Tobago'),
(222, 'TN', 'Tunisia'),
(223, 'TR', 'Turkey'),
(224, 'TM', 'Turkmenistan'),
(225, 'TC', 'Turks and Caicos Islands'),
(226, 'TV', 'Tuvalu'),
(227, 'UG', 'Uganda'),
(228, 'UA', 'Ukraine'),
(229, 'AE', 'United Arab Emirates'),
(230, 'GB', 'United Kingdom'),
(231, 'US', 'United States'),
(232, 'UM', 'United States minor outlying islands'),
(233, 'UY', 'Uruguay'),
(234, 'UZ', 'Uzbekistan'),
(235, 'VU', 'Vanuatu'),
(236, 'VA', 'Vatican City State'),
(237, 'VE', 'Venezuela'),
(238, 'VN', 'Vietnam'),
(239, 'VG', 'Virgin Islands (British)'),
(240, 'VI', 'Virgin Islands (U.S.)'),
(241, 'WF', 'Wallis and Futuna Islands'),
(242, 'EH', 'Western Sahara'),
(243, 'YE', 'Yemen'),
(244, 'ZR', 'Zaire'),
(245, 'ZM', 'Zambia'),
(246, 'ZW', 'Zimbabwe');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `alpha_id` varchar(191) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `contact` varchar(191) DEFAULT NULL,
  `address` varchar(191) NOT NULL,
  `city_id` int(11) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `alpha_id`, `name`, `email`, `contact`, `address`, `city_id`, `password`, `created_at`, `updated_at`) VALUES
(1, 'KHI/C0001', 'Ali', 'ali@gmail.com', '0310-2310557', 'House No 830 Shah Faisal Colony Block 4 Near Khokar Club', 1, 'eyJpdiI6InNHRVNTbzJNTUdtSURFY3hHMzJ4M1E9PSIsInZhbHVlIjoiYlU5YjFlVXBhcHFsWThVZ29IVlArZz09IiwibWFjIjoiZjg5NGQzODA0NmUzNWFiYWFlZGU3YjIxMGJhNDZjNDUxYTNhMmUzMGQyNGQ3MDRkMjAzNDdhZDdhNzQ5YTlkZCJ9', '2019-02-18 12:36:47', '2019-02-14 04:10:17'),
(3, 'KHI/C0003', 'Zohaib Faruqui', 'zohaibfaruqui@gmail.com', '03422111221', 'SFC Block No 4', 1, 'eyJpdiI6ImhSMDB4MytGNW5UZjMzNmI0Zng4WkE9PSIsInZhbHVlIjoiWlB3ZzJpTVd6RTdQM3NPaU1OdnBUUT09IiwibWFjIjoiY2IyNmVmM2VkMWU3Y2VkNWU3NWRjYjlmZjZmMWI4MmIxN2VkNzgzNGQ4ODBlOTBkNmQxZDRhYzE0M2E1MjI4ZSJ9', '2019-02-20 08:47:52', '2019-02-20 08:58:48');

-- --------------------------------------------------------

--
-- Table structure for table `customerorderdetail`
--

CREATE TABLE `customerorderdetail` (
  `id` int(11) NOT NULL,
  `C_id` int(11) NOT NULL,
  `O_id` int(11) NOT NULL,
  `C_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cust_orderdetails`
--

CREATE TABLE `cust_orderdetails` (
  `id` int(11) NOT NULL,
  `order_Id` int(11) DEFAULT NULL,
  `product_Id` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cust_orderdetails`
--

INSERT INTO `cust_orderdetails` (`id`, `order_Id`, `product_Id`, `updated_at`, `created_at`) VALUES
(1, 1, 1, '2019-02-21 11:30:14', '2019-02-21 11:30:14'),
(2, 1, 2, '2019-02-21 11:30:14', '2019-02-21 11:30:14'),
(3, 1, 3, '2019-02-21 11:30:14', '2019-02-21 11:30:14'),
(4, 2, 4, '2019-02-23 09:37:13', '2019-02-23 09:37:13'),
(5, 2, 5, '2019-02-23 09:37:13', '2019-02-23 09:37:13'),
(6, 2, 6, '2019-02-23 09:37:13', '2019-02-23 09:37:13'),
(7, 2, 7, '2019-02-23 09:37:13', '2019-02-23 09:37:13'),
(8, 2, 8, '2019-02-23 09:37:14', '2019-02-23 09:37:14'),
(9, 2, 9, '2019-02-23 09:37:14', '2019-02-23 09:37:14'),
(10, 3, 10, '2019-02-23 10:02:48', '2019-02-23 10:02:48'),
(11, 3, 11, '2019-02-23 10:02:48', '2019-02-23 10:02:48'),
(12, 3, 12, '2019-02-23 10:02:48', '2019-02-23 10:02:48'),
(13, 3, 13, '2019-02-23 10:02:48', '2019-02-23 10:02:48'),
(14, 3, 14, '2019-02-23 10:02:49', '2019-02-23 10:02:49'),
(15, 3, 15, '2019-02-23 10:02:49', '2019-02-23 10:02:49'),
(16, 4, 16, '2019-02-23 10:27:02', '2019-02-23 10:27:02'),
(17, 4, 17, '2019-02-23 10:27:02', '2019-02-23 10:27:02'),
(18, 4, 18, '2019-02-23 10:27:02', '2019-02-23 10:27:02'),
(19, 4, 19, '2019-02-23 10:27:02', '2019-02-23 10:27:02'),
(20, 4, 20, '2019-02-23 10:27:02', '2019-02-23 10:27:02'),
(21, 4, 21, '2019-02-23 10:27:02', '2019-02-23 10:27:02'),
(22, 5, 22, '2019-02-23 10:32:25', '2019-02-23 10:32:25'),
(23, 5, 23, '2019-02-23 10:32:25', '2019-02-23 10:32:25'),
(24, 5, 24, '2019-02-23 10:32:25', '2019-02-23 10:32:25'),
(25, 5, 25, '2019-02-23 10:32:25', '2019-02-23 10:32:25'),
(26, 5, 26, '2019-02-23 10:32:26', '2019-02-23 10:32:26'),
(27, 5, 27, '2019-02-23 10:32:26', '2019-02-23 10:32:26'),
(28, 7, 28, '2019-02-23 14:25:13', '2019-02-23 14:25:13'),
(29, 8, 29, '2019-02-23 14:26:25', '2019-02-23 14:26:25'),
(30, 12, 30, '2019-02-23 14:32:13', '2019-02-23 14:32:13'),
(31, 13, 31, '2019-02-23 14:34:59', '2019-02-23 14:34:59'),
(32, 13, 32, '2019-02-23 14:34:59', '2019-02-23 14:34:59'),
(33, 13, 33, '2019-02-23 14:34:59', '2019-02-23 14:34:59'),
(34, 14, 34, '2019-02-23 14:36:54', '2019-02-23 14:36:54'),
(35, 14, 35, '2019-02-23 14:36:54', '2019-02-23 14:36:54'),
(36, 14, 36, '2019-02-23 14:36:54', '2019-02-23 14:36:54');

-- --------------------------------------------------------

--
-- Table structure for table `dutiable`
--

CREATE TABLE `dutiable` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dutiable`
--

INSERT INTO `dutiable` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Dox', '2019-02-21 09:59:07', '2019-02-21 09:59:07'),
(2, 'Non-Dox', '2019-02-21 09:59:07', '2019-02-21 09:59:07');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `alpha_id` varchar(50) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(191) NOT NULL,
  `address` varchar(191) NOT NULL,
  `city_id` int(11) DEFAULT NULL,
  `office_id` int(11) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `alpha_id`, `name`, `email`, `contact`, `address`, `city_id`, `office_id`, `password`, `created_at`, `updated_at`) VALUES
(1, 'KHI/E0001', 'Employee Name', 'Employee@em.com', 'Employee', 'Employee', 1, 1, 'eyJpdiI6IllOSjZSRXJmVTVmNGhjZWNXSGlhTnc9PSIsInZhbHVlIjoibGhaRVVTZ01Jb1AyQWo1UzhjZ0JCQT09IiwibWFjIjoiYzUwMjk2M2JkM2UxOGNiNTAzM2JiZGRlM2JkMDhlYjc1ZTgwNTZkNjAxM2Y4N2M1N2ZlOTE1Y2Q3OWMxZjc5YyJ9', '2019-02-15 13:19:50', '2019-02-18 13:08:55');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(75) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `subject`, `message`, `created_at`, `updated_at`) VALUES
(1, 'Zohaib Faruqui', 'zohaibfaruqui@gmail.com', 'A Good Step Towards Success', 'Message', '2019-02-25 10:08:04', '2019-02-25 10:08:04');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `office`
--

CREATE TABLE `office` (
  `id` int(11) NOT NULL,
  `alpha_id` varchar(191) DEFAULT NULL,
  `address` varchar(191) NOT NULL,
  `city_id` int(11) NOT NULL,
  `contact` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `office`
--

INSERT INTO `office` (`id`, `alpha_id`, `address`, `city_id`, `contact`, `created_at`, `updated_at`) VALUES
(1, 'KHI/B0001', 'House No 830 ', 1, '0342256544', '2019-02-15 13:36:14', '2019-02-15 13:37:21'),
(3, 'KHI/B0003', 'Faryal Paradise', 1, '03422111221', '2019-02-20 09:47:09', '2019-02-20 09:47:09');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetail`
--

CREATE TABLE `orderdetail` (
  `id` int(50) NOT NULL,
  `alpha_id` varchar(50) DEFAULT NULL,
  `created_id` int(11) DEFAULT NULL,
  `account_no` int(11) DEFAULT NULL,
  `ref_no` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `sender_name` varchar(255) DEFAULT NULL,
  `sender_company` varchar(255) DEFAULT NULL,
  `sender_cell` varchar(255) DEFAULT NULL,
  `sender_line` varchar(255) DEFAULT NULL,
  `sender_address` text,
  `sender_postal` varchar(255) DEFAULT NULL,
  `origin` varchar(50) DEFAULT NULL,
  `receiver_name` varchar(255) DEFAULT NULL,
  `receiver_company` varchar(255) DEFAULT NULL,
  `receiver_cell` varchar(255) DEFAULT NULL,
  `receiver_line` varchar(255) DEFAULT NULL,
  `receiver_address` text,
  `receiver_postal` varchar(255) DEFAULT NULL,
  `destination` int(11) DEFAULT NULL,
  `weight_kg` float(100,2) DEFAULT NULL,
  `weight_dim` float(100,2) DEFAULT NULL,
  `pieces` int(11) DEFAULT NULL,
  `package_id` varchar(50) DEFAULT NULL,
  `service_type` varchar(50) DEFAULT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `gst` float(100,2) DEFAULT NULL,
  `discount` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `dutiable` int(11) DEFAULT NULL,
  `insurance` varchar(191) DEFAULT NULL,
  `contents` varchar(191) DEFAULT NULL,
  `value` varchar(191) DEFAULT NULL,
  `order_status` varchar(50) DEFAULT NULL,
  `booked_date` datetime DEFAULT NULL,
  `dsl_date` datetime DEFAULT NULL,
  `transit_date` datetime DEFAULT NULL,
  `out_date` datetime DEFAULT NULL,
  `deliever_date` datetime DEFAULT NULL,
  `region` varchar(50) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderdetail`
--

INSERT INTO `orderdetail` (`id`, `alpha_id`, `created_id`, `account_no`, `ref_no`, `date`, `customer_id`, `sender_name`, `sender_company`, `sender_cell`, `sender_line`, `sender_address`, `sender_postal`, `origin`, `receiver_name`, `receiver_company`, `receiver_cell`, `receiver_line`, `receiver_address`, `receiver_postal`, `destination`, `weight_kg`, `weight_dim`, `pieces`, `package_id`, `service_type`, `payment_id`, `amount`, `gst`, `discount`, `total`, `dutiable`, `insurance`, `contents`, `value`, `order_status`, `booked_date`, `dsl_date`, `transit_date`, `out_date`, `deliever_date`, `region`, `updated_at`, `created_at`) VALUES
(1, '2019-02-21/CH/0001', 1, 0, 0, '2019-02-21', NULL, 'Sender Name', 'Zia ud din Hospital', '3422717348', '786001', 'House No 830 Shah Faisal Colony Block 4 Near Khokar Club', '75230', '14', 'Zohaib Faruqui', 'Zia ud din Hospital', '03422717348', '985266', 'House No 830 Shah Faisal Colony Block 4 Near Khokar Club', '75230', 13, 25.00, 25.00, 50, '1', '3', 2, 50, 50.00, 50, 50, 1, '50', '50', '50', '5', NULL, NULL, NULL, NULL, NULL, 'DOMESTIC', '2019-02-21 06:30:14', '2019-02-23 15:34:52'),
(2, '2019-02-23/CH/0002', 1, 123456, 123456, '2019-02-23', NULL, 'Zohaib', 'Zia ud din Hospital', '3422717348', '786001', 'House No 830 Shah Faisal Colony Block 4 Near Khokar Club', '75230', '1', 'Zohaib Faruqui', 'Zia ud din Hospital', '03127287663', '985266', 'Physioterapy Deaprtment Zia ud din Hospital Clifton Karachi Near Bilawal Chowrangi', '75230', 1, 25.00, 25.00, 50, '1', '1', 2, 500, 10.00, 50, 500, 1, '50', '50', '50', 'product', NULL, NULL, NULL, NULL, NULL, 'DOMESTIC', '2019-02-23 04:37:13', '2019-02-23 10:18:54'),
(3, '2019-02-23/CH/0003', 1, 123456, 123456, '2019-02-23', NULL, 'Zohaib', 'Zia ud din Hospital', '3127287663', '786001', 'Physioterapy Deaprtment Zia ud din Hospital Clifton Karachi Near Bilawal Chowrangi', '75230', '1', 'Dr. Zuhaira Faruqui', 'Zia ud din Hospital', '03127287663', '985266', 'Physioterapy Deaprtment Zia ud din Hospital Clifton Karachi Near Bilawal Chowrangi', '75230', 2, 25.00, 25.00, 50, '1', '6', 2, 6500, 20.00, 500, 7300, 1, '500', '50', '50', '5', NULL, NULL, NULL, NULL, NULL, 'DOMESTIC', '2019-02-23 05:02:48', '2019-02-23 12:53:56'),
(4, '2019-02-23/CR/0004', 1, 123456, 123456, '2019-02-23', NULL, 'Zohaib', 'Zia ud din Hospital', '3422717348', '786001', 'House No 830 Shah Faisal Colony Block 4 Near Khokar Club', '75230', '1', 'Zohaib Faruqui', 'Zia ud din Hospital', '03127287663', '985266', 'Physioterapy Deaprtment Zia ud din Hospital Clifton Karachi Near Bilawal Chowrangi', '75230', 2, 25.00, 25.00, 50, '6', '1', 1, 6500, 20.00, 50, 7750, 1, '500', '50', '50', '1', '2019-02-25 11:21:36', NULL, NULL, NULL, NULL, 'DOMESTIC', '2019-02-23 05:27:01', '2019-02-25 11:21:36'),
(5, '2019-02-23/CH/0005', 1, 789456, 123987, '2019-02-23', NULL, 'Zohaib', 'Zia ud din Hospital', '3422717348', '786001', 'House No 830 Shah Faisal Colony Block 4 Near Khokar Club', '75230', 'PK', 'Zohaib Faruqui', 'Zia ud din Hospital', '03127287663', '985266', 'Physioterapy Deaprtment Zia ud din Hospital Clifton Karachi Near Bilawal Chowrangi', '75230', 1, 25.00, 25.00, 50, 'MEGA', 'INTL. Priority', 2, 100000, 10.00, 0, 90000, 1, '500', '50', '50', '5', '2019-02-25 11:06:54', '2019-02-25 11:17:59', '2019-02-25 11:19:51', '2019-02-25 11:19:58', '2019-02-25 11:20:50', 'INTERNATIONAL', '2019-02-23 05:32:25', '2019-02-25 11:20:50'),
(14, '2019-02-23/CH/0014', 0, NULL, NULL, '2019-02-23', NULL, 'Zohaib', 'Zia ud din Hospital', '3127287663', '786001', 'Physioterapy Deaprtment Zia ud din Hospital Clifton Karachi Near Bilawal Chowrangi', '75230', '1', 'Dr. Zuhaira Faruqui', 'Zia ud din Hospital', '03127287663', '985266', 'Physioterapy Deaprtment Zia ud din Hospital Clifton Karachi Near Bilawal Chowrangi', '75230', 4, 25.00, 25.00, 50, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'product', NULL, NULL, NULL, NULL, NULL, 'DOMESTIC', '2019-02-23 09:36:54', '2019-02-23 14:36:54');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'DSL Letter', '2019-02-21 08:40:18', '2019-02-21 08:40:18'),
(2, 'DSL Flyer', '2019-02-21 08:40:18', '2019-02-21 08:40:18'),
(3, 'DSL B2', '2019-02-21 08:40:42', '2019-02-21 08:40:42'),
(4, 'DSL B5', '2019-02-21 08:40:42', '2019-02-21 08:40:42'),
(5, 'DSL B10', '2019-02-21 08:41:02', '2019-02-21 08:41:02'),
(6, 'DSL B20', '2019-02-21 08:41:02', '2019-02-21 08:41:02'),
(7, 'DSL B30', '2019-02-21 08:41:18', '2019-02-21 08:41:18');

-- --------------------------------------------------------

--
-- Table structure for table `payment_types`
--

CREATE TABLE `payment_types` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_types`
--

INSERT INTO `payment_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Credit', '2019-02-21 09:46:55', '2019-02-21 09:46:55'),
(2, 'Cash', '2019-02-21 09:46:55', '2019-02-21 09:46:55');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `alpha_id` int(11) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `quantity` int(11) NOT NULL,
  `type` varchar(191) DEFAULT NULL,
  `length` int(11) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `dimensional_weight` float(255,3) DEFAULT NULL,
  `dimensional_length` int(11) DEFAULT NULL,
  `totaldimension` int(11) DEFAULT NULL,
  `amount_pc` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `created_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `alpha_id`, `name`, `quantity`, `type`, `length`, `width`, `height`, `dimensional_weight`, `dimensional_length`, `totaldimension`, `amount_pc`, `customer_id`, `created_id`, `updated_at`) VALUES
(1, NULL, 'P1', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-21 11:30:14', '2019-02-21 11:30:14'),
(2, NULL, 'P2', 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-21 11:30:14', '2019-02-21 11:30:14'),
(3, NULL, 'P3', 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-21 11:30:14', '2019-02-21 11:30:14'),
(4, NULL, 'P1', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 09:37:13', '2019-02-23 09:37:13'),
(5, NULL, 'P4', 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 09:37:13', '2019-02-23 09:37:13'),
(6, NULL, 'P2', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 09:37:13', '2019-02-23 09:37:13'),
(7, NULL, 'P5', 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 09:37:13', '2019-02-23 09:37:13'),
(8, NULL, 'P3', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 09:37:13', '2019-02-23 09:37:13'),
(9, NULL, 'P6', 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 09:37:14', '2019-02-23 09:37:14'),
(10, NULL, 'P2', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:02:48', '2019-02-23 10:02:48'),
(11, NULL, 'N1', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:02:48', '2019-02-23 10:02:48'),
(12, NULL, 'P3', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:02:48', '2019-02-23 10:02:48'),
(13, NULL, 'N2', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:02:48', '2019-02-23 10:02:48'),
(14, NULL, 'P1', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:02:49', '2019-02-23 10:02:49'),
(15, NULL, 'N3', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:02:49', '2019-02-23 10:02:49'),
(16, NULL, 'P2', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:27:01', '2019-02-23 10:27:01'),
(17, NULL, 'N1', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:27:02', '2019-02-23 10:27:02'),
(18, NULL, 'P3', 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:27:02', '2019-02-23 10:27:02'),
(19, NULL, 'N2', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:27:02', '2019-02-23 10:27:02'),
(20, NULL, 'P1', 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:27:02', '2019-02-23 10:27:02'),
(21, NULL, 'N3', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:27:02', '2019-02-23 10:27:02'),
(22, NULL, 'P2', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:32:25', '2019-02-23 10:32:25'),
(23, NULL, 'N1', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:32:25', '2019-02-23 10:32:25'),
(24, NULL, 'P1', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:32:25', '2019-02-23 10:32:25'),
(25, NULL, 'N2', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:32:25', '2019-02-23 10:32:25'),
(26, NULL, 'P3', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:32:26', '2019-02-23 10:32:26'),
(27, NULL, 'N3', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:32:26', '2019-02-23 10:32:26'),
(28, NULL, 'Dr. Zuhaira Faruqui', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 14:25:13', '2019-02-23 14:25:13'),
(29, NULL, 'Dr. Zuhaira Faruqui', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 14:26:25', '2019-02-23 14:26:25'),
(30, NULL, 'Dr. Zuhaira Faruqui', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 14:32:13', '2019-02-23 14:32:13'),
(31, NULL, 'Dr. Zuhaira Faruqui', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 14:34:59', '2019-02-23 14:34:59'),
(32, NULL, 'Zohaib Faruqui', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 14:34:59', '2019-02-23 14:34:59'),
(33, NULL, 'Dr. Zuhaira Faruqui', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 14:34:59', '2019-02-23 14:34:59'),
(34, NULL, 'Dr. Zuhaira Faruqui', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 14:36:54', '2019-02-23 14:36:54'),
(35, NULL, 'Zohaib Faruqui', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 14:36:54', '2019-02-23 14:36:54'),
(36, NULL, 'Dr. Zuhaira Faruqui', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 14:36:54', '2019-02-23 14:36:54');

-- --------------------------------------------------------

--
-- Table structure for table `service_types`
--

CREATE TABLE `service_types` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_types`
--

INSERT INTO `service_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Overnight', '2019-02-21 08:23:07', '2019-02-21 08:23:07'),
(2, 'Overland', '2019-02-21 08:23:07', '2019-02-21 08:23:07'),
(3, 'Detained', '2019-02-21 08:23:28', '2019-02-21 08:23:28'),
(4, 'Same-Day', '2019-02-21 08:23:28', '2019-02-21 08:23:28'),
(5, 'Cash On Delivery', '2019-02-21 08:24:06', '2019-02-21 08:24:06'),
(6, 'Time Pay', '2019-02-21 08:24:06', '2019-02-21 08:24:06');

-- --------------------------------------------------------

--
-- Table structure for table `tracking`
--

CREATE TABLE `tracking` (
  `T_no` int(11) NOT NULL,
  `O_id` int(11) NOT NULL,
  `C_id` int(11) NOT NULL,
  `orderdetail` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `contact`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'cb', 'codebucketz@gmail.com', '$2y$10$qey8jcqfVPhtRIqpR.4/LOSmvJCG/.CC5mZFwx6/8CnvoyHPv0eU6', '031123111123213', 'PlzDfeGn77hnCgU531euvCo1Lz2yfKBPsVLaxjSbzaMXwx4hEyvyoC72XrhU', '2019-02-07 04:06:55', '2019-02-07 04:06:55'),
(2, 'Zohaib Faruqui', 'superadmin@ecric.com', '$2y$10$qe0TGd2lZabHqeLbwQmNv.Z9NUW5ASGrzRK0hBLSOd3itjtPQRDcq', '03422717348', 'rMJTUgEENpTPH4ZZy4fQ2EsmPZQpfIZWII9H9TakqjidtWOsSpVTa7lir6W3', '2019-02-20 05:55:00', '2019-02-20 05:55:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transaction_date` (`transaction_date`);

--
-- Indexes for table `account_types`
--
ALTER TABLE `account_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `careers`
--
ALTER TABLE `careers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cn_table`
--
ALTER TABLE `cn_table`
  ADD PRIMARY KEY (`CN`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customerorderdetail`
--
ALTER TABLE `customerorderdetail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cust_orderdetails`
--
ALTER TABLE `cust_orderdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dutiable`
--
ALTER TABLE `dutiable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `office`
--
ALTER TABLE `office`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderdetail`
--
ALTER TABLE `orderdetail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deliverypoint` (`origin`),
  ADD KEY `destination` (`destination`),
  ADD KEY `package_id` (`package_id`),
  ADD KEY `service_type` (`service_type`),
  ADD KEY `payment_id` (`payment_id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_types`
--
ALTER TABLE `payment_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `service_types`
--
ALTER TABLE `service_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tracking`
--
ALTER TABLE `tracking`
  ADD PRIMARY KEY (`T_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `account_types`
--
ALTER TABLE `account_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `careers`
--
ALTER TABLE `careers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `cn_table`
--
ALTER TABLE `cn_table`
  MODIFY `CN` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=247;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customerorderdetail`
--
ALTER TABLE `customerorderdetail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cust_orderdetails`
--
ALTER TABLE `cust_orderdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `dutiable`
--
ALTER TABLE `dutiable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `office`
--
ALTER TABLE `office`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orderdetail`
--
ALTER TABLE `orderdetail`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `payment_types`
--
ALTER TABLE `payment_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `service_types`
--
ALTER TABLE `service_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tracking`
--
ALTER TABLE `tracking`
  MODIFY `T_no` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
