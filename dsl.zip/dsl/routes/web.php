<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/test', function () {
    return view('auth.login');
});

Route::get('/admin','AdminController@index');



Route::get('/home', 'HomeController@index')->name('home');
Route::get('/adminreg', 'AdminController@adminreg')->middleware('auth');

Route::post('/admincreate1', 'AdminController@admincreate');

Route::get('/showimg', 'AdminController@getimg');


Route::get('/index', 'IndexController@index');
Route::get('/getcn', 'IndexController@getcn');






Route::post('/AddProduct', 'AdminController@AddProduct_order')->middleware('auth');
Route::get('/neworder_admin', 'AdminController@showorder_Admin')->middleware('auth');


Route::put('/Acceptbyadmin', 'AdminController@Acceptbyadmin')->middleware('auth');
Route::put('/Rejectbyadmin', 'AdminController@Rejectbyadmin')->middleware('auth');
Route::put('/deliverbyadmin', 'AdminController@deliverbyadmin')->middleware('auth');



//

Route::put('/proceedorderbycustomer', 'AdminController@proceedorderbycustomer')->middleware('auth');












//check Request 
Route::post('checkrequest','AdminController@checkrequest')->name('checkreq');
//





//order routes
Route::get('/neworder', 'AdminController@neworder')->name('neworder')->middleware('auth');
Route::POST('addcity','AdminController@addcity')->middleware('auth')->name('addcity');
// domestic order submit
Route::post('/addorder', 'AdminController@addorder')->middleware('auth');
// international order submit
Route::post('/addorder1', 'AdminController@addorder1')->middleware('auth');

Route::get('/showorder', 'AdminController@showorder')->middleware('auth');
Route::get('/productorders', 'AdminController@productorders')->middleware('auth')->name('productorders');
Route::get('/pendingorders', 'AdminController@pendingorders')->middleware('auth')->name('pendingorders');

Route::post('/updateorder', 'AdminController@updateorder')->name('updateorder');
Route::get('/deleteorder', 'AdminController@deleteorder')->name('deleteorder');
Route::post('showproduct','AdminController@showproduct')->name('showproduct');

Route::post('proceedorder','AdminController@proceed')->name('proceed');

Route::get('proceedorder1','AdminController@proceedorder1')->name('proceedorder1');
Route::get('proceedorder2','AdminController@proceedorder2')->name('proceedorder2');
Route::get('proceedorder3','AdminController@proceedorder3')->name('proceedorder3');
Route::get('proceedorder4','AdminController@proceedorder4')->name('proceedorder4');

Route::get('proceeded_order','AdminController@proceeded')->name('proceeded');

Route::get('completed','AdminController@completed')->name('completed');
Route::get('completed1','AdminController@completed1')->name('completed1');
Route::get('completedorders','AdminController@completedorders')->name('completedorders');
Route::get('completedorders2','AdminController@completedorders2')->name('completedorders2');


Route::post('deleteproduct','AdminController@deleteproduct')->name('deleteproduct');
Route::GET('productdetail','AdminController@productdetail')->name('productdetail');
Route::POST('/changestatus','AdminController@changestatus');
Route::POST('/changestatuspending','AdminController@changestatuspending')->name('changestatuspending');

Route::GET('/yearlyreport', 'AdminController@yearlyreport')->middleware('auth');
Route::POST('/yearlyreport1', 'AdminController@yearly')->middleware('auth')->name('yearly');

Route::GET('/dailyreport', 'AdminController@dailyreport')->middleware('auth');
Route::POST('/dailyreport1', 'AdminController@daily')->middleware('auth')->name('daily');

Route::GET('/monthlyreport', 'AdminController@monthlyreport')->middleware('auth');
Route::POST('/monthlyreport1', 'AdminController@monthly')->middleware('auth')->name('monthly');
Route::POST('/printorder1','AdminController@printorder1')->name('printorder1');
Route::POST('/printorder2','AdminController@printorder2')->name('printorder2');
//domestic
Route::POST('/detailsoforder1','AdminController@detailsoforder1')->name('detailsoforder1');
// international
Route::POST('/detailsoforder2','AdminController@detailsoforder2')->name('detailsoforder2');

//domestic
Route::GET('/domesticreq','AdminController@domesticreq')->name('domesticreq');
Route::GET('/domesticorders','AdminController@domesticorders')->name('domesticorders');
// international
Route::GET('/internationalreq','AdminController@internationalreq')->name('internationalreq');
Route::GET('/internationalorders','AdminController@internationalorders')->name('internationalorders');
//end order routes


// begin credit orders routes
// Route::get('/customercreditordershow/','AdminController@customercreditordershow')->name('customercreditordershow');
// Route::get('/customercreditorders/{id}','AdminController@customercreditorders')->name('customercreditorders');
Route::get('/creditorders','AdminController@creditorders')->name('creditorders');
Route::get('/creditordershow','AdminController@creditordershow')->name('creditordershow');
Route::post('/changetocash','AdminController@changetocash')->name('changetocash');
// end   credit orders routes


//cutomer routes
Route::get('/newcustomer', 'AdminController@newcustomer')->name('newcustomer');
Route::post('/addcustomer', 'AdminController@addcustomer')->name('addcustomer');
Route::get('/viewcustomer', 'AdminController@viewcustomer')->name('viewcustomer');
Route::get('/customerdata', 'AdminController@customerdata')->name('customerdata');
Route::post('/updatecustomer', 'AdminController@updatecustomer')->name('updatecustomer');
Route::get('/deletecustomer', 'AdminController@deletecustomer')->name('deletecustomer');
//end customer routes


// employee routes
Route::get('/newemployee', 'AdminController@newemployee')->name('newemployee');
Route::post('/addemployee', 'AdminController@addemployee')->name('addemployee');
Route::get('/viewemployee', 'AdminController@viewemployee')->name('viewemployee');
Route::get('/employeesdata','AdminController@employeesdata')->name('employeesdata');
Route::post('/updateemployee', 'AdminController@updateemployee')->name('updateemployee');
Route::get('/deleteemployee', 'AdminController@deleteemployee')->name('deleteemployee');
//end employee routes


// office routes
Route::get('/newoffice', 'AdminController@newoffice')->name('newoffice');
Route::post('/addoffice', 'AdminController@addoffice')->name('addoffice');
Route::get('/viewoffice', 'AdminController@viewoffice')->name('viewoffice');
Route::get('/officedata', 'AdminController@officedata')->name('officedata');
Route::post('/updateoffice', 'AdminController@updateoffice')->name('updateoffice');
Route::get('/deleteoffice', 'AdminController@deleteoffice')->name('deleteoffice');
//end office routes

//accounts routes
Route::get('/accountsview','AdminController@accountsview')->name('accountsview');
Route::get('/accountsdata','AdminController@accountsdata')->name('accountsdata');
Route::POST('/submitamount','AdminController@submitamount')->name('submitamount');
Route::POST('/submitpittycash','AdminController@submitpittycash')->name('submitpittycash');
//end accounts routes

Route::get('/viewfeedback','AdminController@viewfeedback')->name('viewfeedback');
Route::get('/feedbackdata','AdminController@feedbackdata')->name('feedbackdata');


Auth::routes();






// Main Website
Route::get('/', 'WebController@index');
Route::POST('track','WebController@track')->name('track');

Route::get('/about', 'WebController@about');
Route::get('/services', 'WebController@services');

Route::get('/contact', 'WebController@contact')->name('contact');
Route::POST('/contact','WebController@contacted')->name('contacted');

Route::get('/client_request', 'WebController@client_request');
// domestic order submit
Route::POST('/addordercu1', 'WebController@addorder');
// international order submit
Route::post('/addordercu2', 'WebController@addorder1');

Route::get('/careers', 'WebController@careers');
Route::post('/submitcv','WebController@submitcv')->name('submitcv');

